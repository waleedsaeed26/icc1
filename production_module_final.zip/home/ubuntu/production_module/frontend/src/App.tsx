import React, { useState } from 'react';
import './App.css';
import QrScanner from './QrScanner';
import ProductionOrderList from './ProductionOrderList';
import WorkshopPanel from './WorkshopPanel'; // Import the workshop panel component
import { Html5QrcodeResult } from 'html5-qrcode';

// Define an interface for the piece data expected from the API
interface PieceData {
  piece_id: string;
  production_order_id: number;
  product_id: string;
  description: string | null;
  current_stage_id: string | null;
  current_workshop_id: string | null;
  status: string;
  customization_details: any; // Or a more specific type
  created_at: string;
  updated_at: string;
  // Add other fields as needed based on schema.sql
}

function App() {
  const [scannedData, setScannedData] = useState<PieceData | null>(null);
  const [scanError, setScanError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Define the success handler for the QR scanner
  const handleScanSuccess = async (decodedText: string, result: Html5QrcodeResult) => {
    console.log(`QR Code Scanned: ${decodedText}`, result);
    setScannedData(null); // Clear previous data
    setScanError(null); // Clear previous error
    setIsLoading(true);

    let pieceId: string | null = null;
    try {
      const qrData = JSON.parse(decodedText);
      if (qrData && qrData.pieceId) {
        pieceId = qrData.pieceId;
      } else {
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[4][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
        if (uuidRegex.test(decodedText)) {
          pieceId = decodedText;
        }
      }
    } catch (e) {
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[4][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
      if (uuidRegex.test(decodedText)) {
        pieceId = decodedText;
      }
    }

    if (!pieceId) {
      setScanError(`خطأ: رمز QR غير صالح أو لا يحتوي على معرف القطعة (pieceId). المحتوى: ${decodedText}`);
      setIsLoading(false);
      return;
    }

    const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:3001';
    try {
      // TODO: Add authToken to headers if API requires authentication
      const response = await fetch(`${backendUrl}/api/pieces/${pieceId}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      const data: PieceData = await response.json();
      setScannedData(data);
    } catch (error: any) {
      console.error("Error fetching piece data:", error);
      setScanError(`فشل في جلب بيانات القطعة: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleScanFailure = (error: string) => {
    // console.error(`QR Scan Error: ${error}`);
  };

  // TODO: Make workshop selection dynamic later
  const currentWorkshopId = "WS-METAL"; // Example workshop ID

  // TODO: Implement login and store token
  const authToken = null; // Placeholder for authentication token

  return (
    <div className="App">
      <header className="App-header">
        <h1>ICC - نظام إدارة الإنتاج</h1> {/* Updated Branding */}
        {/* Maybe add navigation later */}
      </header>
      <main>
        {/* Section for Workshop Panel */}
        <section className="module-section">
          <WorkshopPanel workshopId={currentWorkshopId} authToken={authToken} /> {/* Pass token */}
        </section>

        {/* Divider */}
        <hr className="section-divider" />

        {/* Section for Production Order List */}
        <section className="module-section">
          <ProductionOrderList authToken={authToken} /> {/* Pass token */}
        </section>

        {/* Divider */}
        <hr className="section-divider" />

        {/* Section for QR Scanning */}
        <section className="module-section">
          <h2>ماسح QR Code</h2>
          <p>وجه الكاميرا نحو رمز QR الخاص بالقطعة.</p>
          <QrScanner 
            onScanSuccess={handleScanSuccess} 
            onScanFailure={handleScanFailure} 
          />
          {isLoading && <p>جاري تحميل بيانات القطعة...</p>}
          {scanError && <p className="scan-error">خطأ: {scanError}</p>}
          {scannedData && (
            <div className="scanned-data">
              <h3>بيانات القطعة الممسوحة</h3>
              <p><strong>معرف القطعة:</strong> {scannedData.piece_id}</p>
              <p><strong>معرف المنتج:</strong> {scannedData.product_id}</p>
              <p><strong>الوصف:</strong> {scannedData.description || 'لا يوجد'}</p>
              <p><strong>الحالة الحالية:</strong> {scannedData.status}</p>
              {/* Display other relevant data */}
            </div>
          )}
        </section>

        {/* TODO: Add User Management Panel (conditionally rendered for admins) */}
        {/* Example: {userRole === 'admin' && <UserManagementPanel authToken={authToken} />} */}

      </main>
      <footer className="App-footer">
        <p>&copy; {new Date().getFullYear()} ICC Production System</p> {/* Updated Branding */}
      </footer>
    </div>
  );
}

export default App;

