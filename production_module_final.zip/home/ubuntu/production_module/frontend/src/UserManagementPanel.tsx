import React, { useState, useEffect, useCallback } from 'react';
import './UserManagementPanel.css';

// Define the User type based on backend response
interface User {
  user_id: number;
  username: string;
  full_name: string | null;
  role: 'worker' | 'qc_inspector' | 'production_manager' | 'sales_rep' | 'admin';
  is_active: boolean;
  created_at: string;
}

// Define props, including the auth token
interface UserManagementPanelProps {
  authToken: string | null;
}

const UserManagementPanel: React.FC<UserManagementPanelProps> = ({ authToken }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // --- Form State ---
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newFullName, setNewFullName] = useState('');
  const [newRole, setNewRole] = useState<User['role']>('worker');

  const fetchUsers = useCallback(async () => {
    if (!authToken) {
      setError("Authentication token is missing.");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/users', {
        headers: {
          'Authorization': `Bearer ${authToken}`,
        },
      });
      if (!response.ok) {
        throw new Error(`Failed to fetch users: ${response.statusText}`);
      }
      const data: User[] = await response.json();
      setUsers(data);
    } catch (err: any) {
      setError(err.message || 'An error occurred while fetching users.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [authToken]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const handleAddUser = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!authToken) return;
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`,
        },
        body: JSON.stringify({ 
          username: newUsername, 
          password: newPassword, 
          fullName: newFullName || null, 
          role: newRole 
        }),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to add user: ${response.statusText}`);
      }
      // Reset form and refresh list
      setNewUsername('');
      setNewPassword('');
      setNewFullName('');
      setNewRole('worker');
      setShowAddForm(false);
      fetchUsers(); 
    } catch (err: any) {
      setError(err.message || 'An error occurred while adding the user.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateUser = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!authToken || !editingUser) return;
    setIsLoading(true);
    setError(null);
    try {
      const updates: any = {
        fullName: newFullName || null,
        role: newRole,
        isActive: editingUser.is_active // Keep current active status unless changed via specific action
      };
      if (newPassword) { // Only include password if a new one is provided
        updates.password = newPassword;
      }

      const response = await fetch(`/api/users/${editingUser.user_id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`,
        },
        body: JSON.stringify(updates),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to update user: ${response.statusText}`);
      }
      // Reset form and refresh list
      setEditingUser(null);
      setNewPassword(''); // Clear password field
      fetchUsers();
    } catch (err: any) {
      setError(err.message || 'An error occurred while updating the user.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleActive = async (user: User) => {
    if (!authToken) return;
    const confirmToggle = window.confirm(
      `Are you sure you want to ${user.is_active ? 'deactivate' : 'activate'} user '${user.username}'?`
    );
    if (!confirmToggle) return;

    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`/api/users/${user.user_id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`,
        },
        body: JSON.stringify({ isActive: !user.is_active }), // Toggle active status
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to update user status: ${response.statusText}`);
      }
      fetchUsers(); // Refresh list
    } catch (err: any) {
      setError(err.message || 'An error occurred while updating user status.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const startEditing = (user: User) => {
    setEditingUser(user);
    setShowAddForm(false); // Close add form if open
    setNewUsername(user.username); // Pre-fill username (though not editable here)
    setNewFullName(user.full_name || '');
    setNewRole(user.role);
    setNewPassword(''); // Clear password for update form
  };

  const cancelEditing = () => {
    setEditingUser(null);
    // Clear form fields
    setNewUsername('');
    setNewPassword('');
    setNewFullName('');
    setNewRole('worker');
  };

  const cancelAdding = () => {
    setShowAddForm(false);
    // Clear form fields
    setNewUsername('');
    setNewPassword('');
    setNewFullName('');
    setNewRole('worker');
  };

  const roles: User['role'][] = ['worker', 'qc_inspector', 'production_manager', 'sales_rep', 'admin'];

  return (
    <div className="user-management-panel">
      <h2>User Management</h2>

      {error && <p className="error-message">Error: {error}</p>}
      {isLoading && <p>Loading...</p>}

      {!editingUser && !showAddForm && (
        <button onClick={() => { setShowAddForm(true); setEditingUser(null); }} className="add-user-btn">
          Add New User
        </button>
      )}

      {(showAddForm || editingUser) && (
        <form onSubmit={editingUser ? handleUpdateUser : handleAddUser} className="user-form">
          <h3>{editingUser ? `Edit User: ${editingUser.username}` : 'Add New User'}</h3>
          
          {!editingUser && (
             <div className="form-group">
              <label htmlFor="username">Username:</label>
              <input 
                type="text" 
                id="username" 
                value={newUsername} 
                onChange={(e) => setNewUsername(e.target.value)} 
                required 
              />
            </div>
          )}
          
          <div className="form-group">
            <label htmlFor="password">Password:</label>
            <input 
              type="password" 
              id="password" 
              value={newPassword} 
              onChange={(e) => setNewPassword(e.target.value)} 
              placeholder={editingUser ? "Leave blank to keep current password" : ""}
              required={!editingUser} // Required only when adding
            />
          </div>
          <div className="form-group">
            <label htmlFor="fullName">Full Name:</label>
            <input 
              type="text" 
              id="fullName" 
              value={newFullName} 
              onChange={(e) => setNewFullName(e.target.value)} 
            />
          </div>
          <div className="form-group">
            <label htmlFor="role">Role:</label>
            <select 
              id="role" 
              value={newRole} 
              onChange={(e) => setNewRole(e.target.value as User['role'])} 
              required
            >
              {roles.map(role => (
                <option key={role} value={role}>{role}</option>
              ))}
            </select>
          </div>
          <div className="form-actions">
            <button type="submit" disabled={isLoading}>
              {editingUser ? 'Update User' : 'Add User'}
            </button>
            <button type="button" onClick={editingUser ? cancelEditing : cancelAdding} disabled={isLoading} className="button-cancel">
              Cancel
            </button>
          </div>
        </form>
      )}

      {!showAddForm && !editingUser && (
        <table className="users-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Username</th>
              <th>Full Name</th>
              <th>Role</th>
              <th>Status</th>
              <th>Created At</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.user_id}>
                <td>{user.user_id}</td>
                <td>{user.username}</td>
                <td>{user.full_name || '-'}</td>
                <td>{user.role}</td>
                <td>
                  <span className={`status ${user.is_active ? 'active' : 'inactive'}`}>
                    {user.is_active ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td>{new Date(user.created_at).toLocaleString()}</td>
                <td>
                  <button onClick={() => startEditing(user)} className="action-btn edit-btn" disabled={isLoading}>Edit</button>
                  <button 
                    onClick={() => handleToggleActive(user)} 
                    className={`action-btn ${user.is_active ? 'deactivate-btn' : 'activate-btn'}`} 
                    disabled={isLoading}
                  >
                    {user.is_active ? 'Deactivate' : 'Activate'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default UserManagementPanel;

