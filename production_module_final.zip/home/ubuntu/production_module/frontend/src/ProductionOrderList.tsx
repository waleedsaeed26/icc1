import React, { useState, useEffect, useCallback } from 'react'; // Added useCallback
import './ProductionOrderList.css'; // We'll create this CSS file

// Define the structure of a Production Order based on backend API
interface ProductionOrder {
  order_id: number;
  sales_order_id: string | null;
  order_type: 'standard' | 'partially_customized' | 'fully_customized';
  status: string;
  customer_name: string | null;
  approval_status: string;
  created_at: string;
}

// Define props interface to accept authToken
interface ProductionOrderListProps {
  authToken?: string | null;
}

const ProductionOrderList: React.FC<ProductionOrderListProps> = ({ authToken }) => {
  const [orders, setOrders] = useState<ProductionOrder[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // TODO: Replace with actual backend URL
  const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:3001';

  const fetchOrders = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const headers: HeadersInit = {};
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }
      const response = await fetch(`${backendUrl}/api/orders`, { headers }); // Pass headers
      if (!response.ok) {
        // Handle specific auth errors
        if (response.status === 401 || response.status === 403) {
          throw new Error(`خطأ في المصادقة (${response.status})`);
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: ProductionOrder[] = await response.json();
      setOrders(data);
    } catch (error: any) {
      console.error("Error fetching production orders:", error);
      setError(`فشل في جلب أوامر الإنتاج: ${error.message}`);
    } finally {
      setLoading(false);
    }
  }, [backendUrl, authToken]); // Added authToken dependency

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  const getOrderTypeColor = (type: ProductionOrder['order_type']): string => {
    switch (type) {
      case 'standard':
        return 'blue';
      case 'partially_customized':
        return 'green';
      case 'fully_customized':
        return 'orange';
      default:
        return 'grey'; // Fallback color
    }
  };

  const getOrderTypeArabic = (type: ProductionOrder['order_type']): string => {
    switch (type) {
      case 'standard':
        return 'قياسي';
      case 'partially_customized':
        return 'مخصص جزئيًا';
      case 'fully_customized':
        return 'مخصص بالكامل';
      default:
        return type;
    }
  };

  return (
    <div className="production-order-list-container">
      <h2>قائمة أوامر الإنتاج</h2>
      {loading && <p>جاري تحميل الأوامر...</p>}
      {error && <p className="error-message">خطأ: {error}</p>}
      {!loading && !error && orders.length === 0 && <p>لا توجد أوامر إنتاج لعرضها.</p>}
      {!loading && !error && orders.length > 0 && (
        <ul className="order-list">
          {orders.map((order) => (
            <li key={order.order_id} className={`order-item order-type-${getOrderTypeColor(order.order_type)}`}>
              <div className="order-header">
                <span className="order-id">أمر #{order.order_id}</span>
                <span className={`order-type-badge order-type-${getOrderTypeColor(order.order_type)}`}>
                  {getOrderTypeArabic(order.order_type)}
                </span>
              </div>
              <div className="order-details">
                <p><strong>أمر البيع:</strong> {order.sales_order_id || 'N/A'}</p>
                <p><strong>العميل:</strong> {order.customer_name || 'N/A'}</p>
                <p><strong>الحالة:</strong> {order.status}</p>
                <p><strong>حالة الموافقة:</strong> {order.approval_status}</p>
                <p><strong>تاريخ الإنشاء:</strong> {new Date(order.created_at).toLocaleString('ar-EG')}</p>
              </div>
              {(order.order_type === 'partially_customized' || order.order_type === 'fully_customized') && (
                <div className="order-warning">
                  ⚠️ يرجى مراجعة جميع تفاصيل هذا الأمر المخصص بعناية قبل البدء في الإنتاج.
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
      {/* TODO: Add button/form to create new orders */}
    </div>
  );
};

export default ProductionOrderList;

