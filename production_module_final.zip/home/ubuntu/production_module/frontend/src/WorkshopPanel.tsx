import React, { useState, useEffect, useCallback } from 'react';
import './WorkshopPanel.css';
import QualityCheckModal from './QualityCheckModal'; // Import the modal component

// Interfaces based on backend API and schema
interface ProductionOperation {
  operation_id: number;
  piece_id: string;
  stage_id: string;
  workshop_id: string;
  status: 'pending' | 'in_progress' | 'paused' | 'completed' | 'qc_pending' | 'qc_passed' | 'qc_failed' | 'rework'; // Updated status enum
  start_time: string | null;
  pause_time: string | null;
  total_paused_duration_seconds: number;
  end_time: string | null;
  actual_duration_seconds: number | null;
  standard_time_minutes: number | null;
  created_at: string;
  // Joined data
  piece_description: string | null;
  product_id: string;
  sales_order_id: string | null;
  // TODO: Add assigned workers array here later
  assigned_workers?: { user_id: number; username: string }[];
}

interface WorkshopPanelProps {
  workshopId: string; // Passed as prop to determine which workshop's panel this is
  authToken?: string | null; // Added authToken prop
}

const WorkshopPanel: React.FC<WorkshopPanelProps> = ({ workshopId, authToken }) => {
  const [operations, setOperations] = useState<ProductionOperation[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  // State for QC Modal
  const [isQcModalOpen, setIsQcModalOpen] = useState<boolean>(false);
  const [qcOperation, setQcOperation] = useState<ProductionOperation | null>(null);

  // TODO: Replace with actual backend URL
  const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:3001';

  const fetchOperations = useCallback(async () => {
    // Keep loading true if it's already true, otherwise set to true
    setLoading(prev => prev || true);
    setError(null);
    try {
      const headers: HeadersInit = {};
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }
      const response = await fetch(`${backendUrl}/api/workshops/${workshopId}/operations`, { headers });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: ProductionOperation[] = await response.json();
      setOperations(data);
    } catch (error: any) {
      console.error(`Error fetching operations for workshop ${workshopId}:`, error);
      setError(`فشل في جلب عمليات الورشة: ${error.message}`);
    } finally {
      setLoading(false);
    }
  }, [workshopId, backendUrl, authToken]); // Added authToken dependency

  useEffect(() => {
    fetchOperations();
  }, [fetchOperations]);

  // --- Timer Logic ---
  const getElapsedTime = (op: ProductionOperation): number => {
    if (!op.start_time || op.status !== 'in_progress') return op.actual_duration_seconds || 0;
    const startTime = new Date(op.start_time).getTime();
    const now = Date.now();
    const elapsedSeconds = Math.round((now - startTime) / 1000) - (op.total_paused_duration_seconds || 0);
    return elapsedSeconds > 0 ? elapsedSeconds : 0;
  };

  const formatTime = (totalSeconds: number): string => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  // --- API Call Handlers ---
  const handleOperationAction = async (operation: ProductionOperation, action: 'start' | 'pause' | 'resume' | 'complete') => {
    setError(null); // Clear previous errors
    if (action === 'complete') {
      // Open QC modal instead of calling API directly
      setQcOperation(operation);
      setIsQcModalOpen(true);
    } else {
      // Handle start, pause, resume actions
      try {
        const headers: HeadersInit = { 'Content-Type': 'application/json' };
        if (authToken) {
          headers['Authorization'] = `Bearer ${authToken}`;
        }
        const response = await fetch(`${backendUrl}/api/operations/${operation.operation_id}/${action}`, {
          method: 'POST',
          headers: headers,
        });
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || `Failed to ${action} operation`);
        }
        // Refresh the operations list after successful action
        fetchOperations();
      } catch (error: any) {
        console.error(`Error performing action ${action} on operation ${operation.operation_id}:`, error);
        setError(`فشل في ${action} العملية: ${error.message}`);
      }
    }
  };

  // Handler for submitting QC results from the modal
  const handleQcSubmit = async (formData: FormData) => {
    setError(null);
    try {
      const headers: HeadersInit = {};
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }
      // Note: Don't set Content-Type header when using FormData, browser does it
      const response = await fetch(`${backendUrl}/api/quality-checks`, {
        method: 'POST',
        headers: headers,
        body: formData, 
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to submit quality check');
      }
      // Refresh operations after successful QC submission
      fetchOperations(); 
      // Modal will close itself on success
    } catch (error: any) {
      console.error("Error submitting QC:", error);
      // Re-throw the error so the modal can display it
      throw error; 
    }
  };

  // TODO: Implement worker assignment/removal handlers

  return (
    <div className="workshop-panel-container">
      <h3>عمليات ورشة: {workshopId}</h3>
      {loading && <p>جاري تحميل العمليات...</p>}
      {error && <p className="error-message">خطأ: {error}</p>}
      {!loading && !error && operations.length === 0 && <p>لا توجد عمليات حالية لهذه الورشة.</p>}
      {!loading && !error && operations.length > 0 && (
        <div className="operations-grid">
          {operations.map((op) => (
            <div key={op.operation_id} className={`operation-card status-${op.status}`}>
              <h4>عملية #{op.operation_id} (قطعة: {op.piece_id.substring(0, 8)}...)</h4>
              <p><strong>المنتج:</strong> {op.product_id} ({op.piece_description || 'لا يوجد وصف'})</p>
              <p><strong>أمر البيع:</strong> {op.sales_order_id || 'N/A'}</p>
              <p><strong>المرحلة:</strong> {op.stage_id}</p>
              <p><strong>الحالة:</strong> {op.status}</p>

              {/* Timer Display */}
              {(op.status === 'in_progress' || op.status === 'paused' || op.actual_duration_seconds) && (
                 <p className="timer">
                   <strong>الوقت المنقضي:</strong>
                   {formatTime(op.status === 'in_progress' ? getElapsedTime(op) : (op.actual_duration_seconds || 0))}
                   {op.standard_time_minutes && ` / ${formatTime(op.standard_time_minutes * 60)} (المعياري)`}
                 </p>
              )}

              {/* Action Buttons */}
              <div className="action-buttons">
                {op.status === 'pending' && (
                  <button onClick={() => handleOperationAction(op, 'start')} className="button-start">
                    بدء
                  </button>
                )}
                {op.status === 'in_progress' && (
                  <>
                    <button onClick={() => handleOperationAction(op, 'pause')} className="button-pause">
                      إيقاف مؤقت
                    </button>
                    <button onClick={() => handleOperationAction(op, 'complete')} className="button-complete">
                      إنهاء (فحص جودة)
                    </button>
                  </>
                )}
                {op.status === 'paused' && (
                  <button onClick={() => handleOperationAction(op, 'resume')} className="button-resume">
                    استئناف
                  </button>
                )}
                {/* Add button for completed/qc_pending if needed? */}
              </div>

              {/* TODO: Worker Assignment Section */}
              <div className="worker-assignment">
                <p><strong>العمال المعينون:</strong> (قيد التنفيذ)</p>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* Render the QC Modal */}
      <QualityCheckModal
        isOpen={isQcModalOpen}
        onRequestClose={() => setIsQcModalOpen(false)}
        onSubmit={handleQcSubmit}
        operationId={qcOperation?.operation_id || null}
        pieceId={qcOperation?.piece_id || null}
        stageId={qcOperation?.stage_id || null}
        authToken={authToken} // Pass token to modal if needed
      />
    </div>
  );
};

export default WorkshopPanel;

