import React, { useState, useRef } from 'react';
import Modal from 'react-modal';
import './QualityCheckModal.css'; // We'll create this CSS file

// Set the app element for accessibility
// Make sure to call this in your main App component or index.tsx
// Modal.setAppElement('#root'); // Or your app's root element ID

interface QualityCheckModalProps {
  isOpen: boolean;
  onRequestClose: () => void;
  onSubmit: (formData: FormData) => Promise<void>; // Expects FormData for file upload
  operationId: number | null;
  pieceId: string | null;
  stageId: string | null;
  // Add qcUserId later based on authentication
}

const QualityCheckModal: React.FC<QualityCheckModalProps> = ({
  isOpen,
  onRequestClose,
  onSubmit,
  operationId,
  pieceId,
  stageId,
}) => {
  const [result, setResult] = useState<'accepted' | 'rejected' | ''>('');
  const [notes, setNotes] = useState<string>('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setImageFile(event.target.files[0]);
    }
  };

  const resetForm = () => {
    setResult('');
    setNotes('');
    setImageFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = ''; // Clear file input
    }
    setError(null);
    setIsSubmitting(false);
  };

  const handleClose = () => {
    resetForm();
    onRequestClose();
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!result || !pieceId || !operationId || !stageId) {
      setError('خطأ: بيانات العملية غير مكتملة أو لم يتم تحديد نتيجة الفحص.');
      return;
    }
    // TODO: Get qcUserId from auth context later
    const qcUserId = 1; // Placeholder user ID

    setError(null);
    setIsSubmitting(true);

    const formData = new FormData();
    formData.append('pieceId', pieceId);
    formData.append('operationId', String(operationId));
    formData.append('stageId', stageId);
    formData.append('qcUserId', String(qcUserId));
    formData.append('result', result);
    formData.append('notes', notes);
    if (imageFile) {
      formData.append('qcImage', imageFile); // 'qcImage' must match multer field name
    }

    try {
      await onSubmit(formData);
      handleClose(); // Close modal on successful submission
    } catch (err: any) {
      console.error("Error submitting QC:", err);
      setError(`فشل في إرسال فحص الجودة: ${err.message || 'حدث خطأ غير متوقع'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={handleClose}
      contentLabel="Quality Check Submission"
      className="qc-modal"
      overlayClassName="qc-modal-overlay"
      ariaHideApp={false} // Temporarily disable for easier setup, setAppElement properly later
    >
      <h2>تسجيل نتيجة فحص الجودة</h2>
      <p>العملية: #{operationId} | القطعة: {pieceId ? pieceId.substring(0, 8) + '...' : 'N/A'}</p>
      <form onSubmit={handleSubmit} className="qc-form">
        <div className="form-group">
          <label>النتيجة *</label>
          <div className="radio-group">
            <label className={result === 'accepted' ? 'selected' : ''}>
              <input
                type="radio"
                name="qcResult"
                value="accepted"
                checked={result === 'accepted'}
                onChange={() => setResult('accepted')}
                required
              />
              مقبول ✅
            </label>
            <label className={result === 'rejected' ? 'selected' : ''}>
              <input
                type="radio"
                name="qcResult"
                value="rejected"
                checked={result === 'rejected'}
                onChange={() => setResult('rejected')}
                required
              />
              مرفوض ❌
            </label>
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="qcNotes">ملاحظات</label>
          <textarea
            id="qcNotes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={4}
            placeholder="أضف ملاحظات حول الفحص (اختياري)"
          />
        </div>

        <div className="form-group">
          <label htmlFor="qcImage">رفع صورة (اختياري)</label>
          <input
            type="file"
            id="qcImage"
            accept="image/*" // Accept only image files
            onChange={handleFileChange}
            ref={fileInputRef}
          />
          {imageFile && <p className="file-name">الملف المحدد: {imageFile.name}</p>}
        </div>

        {error && <p className="error-message">{error}</p>}

        <div className="form-actions">
          <button type="submit" disabled={isSubmitting || !result}>
            {isSubmitting ? 'جاري الإرسال...' : 'إرسال النتيجة'}
          </button>
          <button type="button" onClick={handleClose} disabled={isSubmitting} className="button-cancel">
            إلغاء
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default QualityCheckModal;

