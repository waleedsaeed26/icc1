import React, { useEffect, useRef, useState } from 'react';
import { Html5QrcodeScanner, Html5QrcodeResult, QrcodeErrorCallback, QrcodeSuccessCallback } from 'html5-qrcode';
import './QrScanner.css'; // We'll create this CSS file for styling

interface QrScannerProps {
  onScanSuccess: (decodedText: string, result: Html5QrcodeResult) => void;
  onScanFailure?: (error: string) => void;
}

const QrScanner: React.FC<QrScannerProps> = ({ onScanSuccess, onScanFailure }) => {
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const scannerRegionId = "qr-scanner-region";

  useEffect(() => {
    // Ensure this runs only once
    if (!scannerRef.current) {
      const config = {
        fps: 10,
        qrbox: { width: 250, height: 250 }, // Adjust size as needed
        rememberLastUsedCamera: true,
        // Only support camera scan type for mobile-first approach
        supportedScanTypes: [] // Let library decide based on environment
      };

      const qrCodeScanner = new Html5QrcodeScanner(
        scannerRegionId,
        config,
        /* verbose= */ false
      );

      const successCallback: QrcodeSuccessCallback = (decodedText, result) => {
        console.log(`Scan successful: ${decodedText}`, result);
        setScanResult(decodedText);
        setError(null);
        onScanSuccess(decodedText, result);
        // Optionally stop scanning after success
        // qrCodeScanner.clear().catch(err => console.error("Failed to clear scanner", err));
      };

      const errorCallback: QrcodeErrorCallback = (errorMessage) => {
        // console.warn(`Scan error: ${errorMessage}`);
        // Don't set error state for common errors like "QR code not found"
        // setError(errorMessage);
      };

      qrCodeScanner.render(successCallback, errorCallback);
      scannerRef.current = qrCodeScanner;
    }

    // Cleanup function to clear the scanner on component unmount
    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear().catch(err => {
          console.error("Failed to clear html5-qrcode scanner on unmount.", err);
        });
        scannerRef.current = null;
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onScanSuccess]); // Dependency array includes onScanSuccess

  return (
    <div className="qr-scanner-container">
      {/* This div will be replaced by the scanner UI */}
      <div id={scannerRegionId} />
      {scanResult && (
        <div className="scan-result">
          <p>آخر نتيجة مسح:</p>
          <code>{scanResult}</code>
        </div>
      )}
      {error && (
        <div className="scan-error">
          <p>خطأ في المسح:</p>
          <code>{error}</code>
        </div>
      )}
    </div>
  );
};

export default QrScanner;

