import React, { useState, useEffect, useCallback } from 'react';
import Modal from 'react-modal';
import './MaterialConsumptionModal.css'; // We'll create this CSS file

// Interface for BOM items fetched from backend
interface BomItem {
  bom_item_id: number;
  product_id: string;
  stage_id: string | null;
  material_id: string;
  standard_quantity: number;
  unit_of_measure: string;
  material_name: string;
}

// Interface for the data to be submitted
interface ConsumptionLogItem {
  materialId: string;
  quantity: number;
  unit: string;
  userId: number; // Placeholder
  notes?: string;
}

interface MaterialConsumptionModalProps {
  isOpen: boolean;
  onRequestClose: () => void;
  onSubmit: (items: ConsumptionLogItem[]) => Promise<void>;
  operationId: number | null;
  pieceId: string | null;
  productId: string | null;
  stageId: string | null;
}

const MaterialConsumptionModal: React.FC<MaterialConsumptionModalProps> = ({
  isOpen,
  onRequestClose,
  onSubmit,
  operationId,
  pieceId,
  productId,
  stageId,
}) => {
  const [bomItems, setBomItems] = useState<BomItem[]>([]);
  const [consumedQuantities, setConsumedQuantities] = useState<{ [materialId: string]: string }>({});
  const [loadingBom, setLoadingBom] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:3001';

  const fetchBom = useCallback(async () => {
    if (!productId) return;
    setLoadingBom(true);
    setError(null);
    try {
      // Construct query params, including stageId if available
      const queryParams = new URLSearchParams();
      if (stageId) {
        queryParams.append('stageId', stageId);
      }
      const response = await fetch(`${backendUrl}/api/products/${productId}/bom?${queryParams.toString()}`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: BomItem[] = await response.json();
      setBomItems(data);
      // Initialize consumed quantities based on BOM
      const initialQuantities = data.reduce((acc, item) => {
        acc[item.material_id] = String(item.standard_quantity); // Default to standard quantity
        return acc;
      }, {} as { [materialId: string]: string });
      setConsumedQuantities(initialQuantities);
    } catch (err: any) {
      console.error(`Error fetching BOM for product ${productId}:`, err);
      setError(`فشل في جلب قائمة المواد: ${err.message}`);
    } finally {
      setLoadingBom(false);
    }
  }, [productId, stageId, backendUrl]);

  useEffect(() => {
    if (isOpen && productId) {
      fetchBom();
    }
  }, [isOpen, productId, fetchBom]);

  const handleQuantityChange = (materialId: string, value: string) => {
    // Allow only numbers and a single decimal point
    if (/^\d*\.?\d*$/.test(value)) {
      setConsumedQuantities(prev => ({ ...prev, [materialId]: value }));
    }
  };

  const resetForm = () => {
    setBomItems([]);
    setConsumedQuantities({});
    setError(null);
    setIsSubmitting(false);
    setLoadingBom(false);
  };

  const handleClose = () => {
    resetForm();
    onRequestClose();
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!operationId) {
        setError('خطأ: معرف العملية غير متوفر.');
        return;
    }
    setError(null);
    setIsSubmitting(true);

    const itemsToSubmit: ConsumptionLogItem[] = [];
    let validationError = false;

    for (const bomItem of bomItems) {
      const consumedQtyStr = consumedQuantities[bomItem.material_id];
      const consumedQty = parseFloat(consumedQtyStr);

      if (isNaN(consumedQty) || consumedQty < 0) {
        setError(`خطأ: الكمية المستهلكة للمادة ${bomItem.material_name} غير صالحة.`);
        validationError = true;
        break;
      }

      // TODO: Get actual userId from auth context
      const userId = 1; // Placeholder

      itemsToSubmit.push({
        materialId: bomItem.material_id,
        quantity: consumedQty,
        unit: bomItem.unit_of_measure,
        userId: userId,
        // notes: // Add notes field if needed
      });
    }

    if (validationError) {
      setIsSubmitting(false);
      return;
    }

    try {
      await onSubmit(itemsToSubmit);
      handleClose(); // Close modal on successful submission
    } catch (err: any) {
      console.error("Error submitting material consumption:", err);
      setError(`فشل في تسجيل استهلاك المواد: ${err.message || 'حدث خطأ غير متوقع'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onRequestClose={handleClose}
      contentLabel="Material Consumption Log"
      className="mc-modal" // Use different class name
      overlayClassName="mc-modal-overlay"
      ariaHideApp={false} // Temporarily disable for easier setup
    >
      <h2>تسجيل استهلاك المواد</h2>
      <p>العملية: #{operationId} | القطعة: {pieceId ? pieceId.substring(0, 8) + '...' : 'N/A'} | المنتج: {productId}</p>

      {loadingBom && <p>جاري تحميل قائمة المواد...</p>}
      {error && <p className="error-message">{error}</p>}

      {!loadingBom && !error && (
        <form onSubmit={handleSubmit} className="mc-form">
          {bomItems.length === 0 ? (
            <p>لم يتم العثور على قائمة مواد لهذا المنتج/المرحلة.</p>
          ) : (
            <table className="bom-table">
              <thead>
                <tr>
                  <th>المادة</th>
                  <th>الكمية المعيارية</th>
                  <th>الوحدة</th>
                  <th>الكمية المستهلكة *</th>
                </tr>
              </thead>
              <tbody>
                {bomItems.map((item) => (
                  <tr key={item.material_id}>
                    <td>{item.material_name} ({item.material_id})</td>
                    <td>{item.standard_quantity}</td>
                    <td>{item.unit_of_measure}</td>
                    <td>
                      <input
                        type="text" // Use text to allow decimal input easily
                        inputMode="decimal" // Hint for mobile keyboards
                        value={consumedQuantities[item.material_id] || ''}
                        onChange={(e) => handleQuantityChange(item.material_id, e.target.value)}
                        required
                        className="quantity-input"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          <div className="form-actions">
            <button type="submit" disabled={isSubmitting || loadingBom || bomItems.length === 0}>
              {isSubmitting ? 'جاري التسجيل...' : 'تسجيل الاستهلاك'}
            </button>
            <button type="button" onClick={handleClose} disabled={isSubmitting} className="button-cancel">
              إلغاء
            </button>
          </div>
        </form>
      )}
    </Modal>
  );
};

export default MaterialConsumptionModal;

