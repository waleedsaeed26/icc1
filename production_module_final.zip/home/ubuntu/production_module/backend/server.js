const express = require("express");
const { Pool } = require("pg");
const redis = require("redis");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcrypt"); // Added for password hashing
const jwt = require("jsonwebtoken"); // Added for JWT

// --- Configuration ---
const PORT = process.env.PORT || 3001;
const PG_CONNECTION_STRING = process.env.DATABASE_URL || "postgresql://user:password@host:port/database"; // Replace
const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379"; // Replace
const JWT_SECRET = process.env.JWT_SECRET || "your_very_secret_key_here"; // Replace with a strong secret, ideally from env vars
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "1h"; // Token expiration time
const BCRYPT_SALT_ROUNDS = 10;
const MAX_WORKERS_PER_OPERATION = 3;
const PRODUCTION_EVENT_STREAM = "production_events";
const SALES_EVENT_STREAM = "sales_events";
const SALES_EVENT_CONSUMER_GROUP = "production_module_group";
const SALES_EVENT_CONSUMER_NAME = "production_consumer_1";
const UPLOAD_DIR = "/home/ubuntu/production_module/uploads/qc_images";

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const app = express();

// --- Middleware ---
app.use(cors());
app.use(express.json());
app.use("/uploads/qc_images", express.static(UPLOAD_DIR));

// --- Multer Setup ---
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: function (req, file, cb) {
    const filetypes = /jpeg|jpg|png|gif/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error("Error: File upload only supports the following filetypes - " + filetypes));
  }
});

// --- PostgreSQL Setup ---
let pool;
try {
  pool = new Pool({ connectionString: PG_CONNECTION_STRING });
  console.log("Attempting to connect to PostgreSQL...");
  pool.connect((err, client, release) => {
    if (err) return console.error("Error acquiring client", err.stack);
    console.log("Successfully connected to PostgreSQL database.");
    release();
  });
  app.set("dbPool", pool);
} catch (error) {
  console.error("Failed to initialize PostgreSQL pool:", error);
  process.exit(1);
}

// --- Redis Setup ---
let redisClient;
(async () => {
  try {
    redisClient = redis.createClient({ url: REDIS_URL });
    redisClient.on("error", (err) => console.error("Redis Client Error", err));
    console.log("Attempting to connect to Redis...");
    await redisClient.connect();
    console.log("Successfully connected to Redis.");
    app.set("redisClient", redisClient);
    listenForSalesEvents(); 
  } catch (error) {
    console.error("Failed to initialize Redis client:", error);
  }
})();

// --- Event Publishing Function ---
async function publishEvent(eventData) {
  const currentRedisClient = app.get("redisClient");
  if (!currentRedisClient || !currentRedisClient.isReady) {
    console.error("Redis client not ready, cannot publish event.");
    return;
  }
  try {
    const stringEventData = Object.entries(eventData).reduce((acc, [key, value]) => {
      if (typeof value === "object" && value !== null) {
        try { acc[key] = JSON.stringify(value); } catch (e) { acc[key] = "[Unstringifiable Object]"; }
      } else { acc[key] = value === null || value === undefined ? "" : String(value); }
      return acc;
    }, {});
    const eventId = await currentRedisClient.xAdd(PRODUCTION_EVENT_STREAM, "*", stringEventData);
    console.log(`Event published to stream ${PRODUCTION_EVENT_STREAM} with ID: ${eventId}`);
    return eventId;
  } catch (error) {
    console.error(`Error publishing event to stream ${PRODUCTION_EVENT_STREAM}:`, error);
  }
}

// --- Sales Event Listener Function ---
async function listenForSalesEvents() {
  const currentRedisClient = app.get("redisClient");
  const dbPool = app.get("dbPool");
  if (!currentRedisClient || !currentRedisClient.isReady || !dbPool) {
    console.error("Redis client or DB Pool not ready, cannot start sales event listener.");
    setTimeout(listenForSalesEvents, 5000); 
    return;
  }
  console.log(`Attempting to create consumer group ${SALES_EVENT_CONSUMER_GROUP} for stream ${SALES_EVENT_STREAM}...`);
  try {
    await currentRedisClient.xGroupCreate(SALES_EVENT_STREAM, SALES_EVENT_CONSUMER_GROUP, "0", { MKSTREAM: true });
    console.log(`Consumer group ${SALES_EVENT_CONSUMER_GROUP} created or already exists.`);
  } catch (err) {
    if (err.message.includes("BUSYGROUP")) { console.log(`Consumer group ${SALES_EVENT_CONSUMER_GROUP} already exists.`); }
    else { console.error(`Error creating consumer group ${SALES_EVENT_CONSUMER_GROUP}:`, err); setTimeout(listenForSalesEvents, 5000); return; }
  }
  console.log(`Starting to listen for events on stream ${SALES_EVENT_STREAM} with group ${SALES_EVENT_CONSUMER_GROUP}...`);
  while (true) {
    try {
      const response = await currentRedisClient.xReadGroup(
        redis.commandOptions({ isolated: true }),
        SALES_EVENT_CONSUMER_GROUP,
        SALES_EVENT_CONSUMER_NAME,
        { key: SALES_EVENT_STREAM, id: ">".toString() },
        { BLOCK: 0, COUNT: 1 }
      );
      if (response && response.length > 0) {
        const stream = response[0];
        const messages = stream.messages;
        for (const message of messages) {
          const eventId = message.id;
          const eventData = message.message;
          console.log(`Received event ${eventId} from ${SALES_EVENT_STREAM}:`, eventData);
          if (eventData.type === "sales_order_created") {
            await handleSalesOrderCreated(eventData, dbPool);
          }
          await currentRedisClient.xAck(SALES_EVENT_STREAM, SALES_EVENT_CONSUMER_GROUP, eventId);
          console.log(`Acknowledged event ${eventId}`);
        }
      } else { console.log("No new messages, continuing to listen..."); }
    } catch (err) {
      console.error("Error reading from Redis stream:", err);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
}

// --- Handler for sales_order_created Event ---
async function handleSalesOrderCreated(eventData, dbPool) {
  const { salesOrderId, customerName, orderType, items } = eventData;
  if (!salesOrderId || !orderType || !items) { console.error("Invalid sales_order_created event data:", eventData); return; }
  let parsedItems;
  try {
    parsedItems = JSON.parse(items);
    if (!Array.isArray(parsedItems)) throw new Error("Items field is not an array");
  } catch (e) { console.error("Failed to parse items JSON in sales_order_created event:", items, e); return; }
  const client = await dbPool.connect();
  try {
    await client.query("BEGIN");
    const orderResult = await client.query(
      "INSERT INTO production_orders (sales_order_id, order_type, customer_name, status, approval_status) VALUES ($1, $2, $3, \'pending\', \'pending\') ON CONFLICT (sales_order_id) DO NOTHING RETURNING *",
      [salesOrderId, orderType, customerName || null]
    );
    if (orderResult.rows.length === 0) { console.warn(`Production order for sales order ${salesOrderId} already exists. Skipping.`); await client.query("COMMIT"); return; }
    const newProductionOrder = orderResult.rows[0];
    console.log(`Created production order ${newProductionOrder.order_id} for sales order ${salesOrderId}`);
    publishEvent({ type: "production_order_created_from_sales", productionOrderId: newProductionOrder.order_id, salesOrderId: salesOrderId, timestamp: new Date().toISOString() });
    for (const item of parsedItems) {
      if (!item.productId || !item.quantity || isNaN(parseInt(item.quantity)) || parseInt(item.quantity) <= 0) { console.warn(`Skipping invalid item in sales order ${salesOrderId}:`, item); continue; }
      const quantity = parseInt(item.quantity);
      for (let i = 0; i < quantity; i++) {
        const qrData = { pieceId: null, productId: item.productId, salesOrderId: salesOrderId, sequence: i + 1, total: quantity };
        const pieceResult = await client.query(
          "INSERT INTO production_pieces (production_order_id, product_id, description, customization_details, status) VALUES ($1, $2, $3, $4, \'pending\') RETURNING piece_id",
          [newProductionOrder.order_id, item.productId, item.description || null, item.customizationDetails ? JSON.stringify(item.customizationDetails) : null]
        );
        const newPieceId = pieceResult.rows[0].piece_id;
        qrData.pieceId = newPieceId;
        await client.query("UPDATE production_pieces SET qr_code_data = $1 WHERE piece_id = $2", [JSON.stringify(qrData), newPieceId]);
        console.log(`Created piece ${newPieceId} for product ${item.productId} (Order ${salesOrderId})`);
        publishEvent({ type: "piece_created", pieceId: newPieceId, productionOrderId: newProductionOrder.order_id, productId: item.productId, timestamp: new Date().toISOString() });
        // TODO: Generate initial operations based on workflow definition
      }
    }
    await client.query("COMMIT");
    console.log(`Successfully processed sales_order_created event for ${salesOrderId}`);
  } catch (err) {
    await client.query("ROLLBACK");
    console.error(`Error processing sales_order_created event for ${salesOrderId}:`, err);
  } finally {
    client.release();
  }
}

// --- Helper Function for DB Interaction ---
const getDbPool = (req) => req.app.get("dbPool");

// --- Authentication Middleware (New) ---
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1]; // Bearer TOKEN

  if (token == null) return res.sendStatus(401); // if there isn't any token

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      console.error("JWT Verification Error:", err.message);
      return res.sendStatus(403); // Invalid token
    }
    req.user = user; // Add user payload to request object
    next(); // pass the execution off to whatever request the user intended
  });
};

// --- Authorization Middleware (New) ---
// Example: Check if user has a specific role
const authorizeRole = (requiredRole) => {
  return (req, res, next) => {
    if (!req.user || req.user.role !== requiredRole) {
      return res.status(403).json({ error: `Forbidden: Requires ${requiredRole} role` });
    }
    next();
  };
};

// Example: Check if user has one of the allowed roles
const authorizeRoles = (allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: `Forbidden: Requires one of the following roles: ${allowedRoles.join(", ")}` });
    }
    next();
  };
};

// --- API Routes ---

app.get("/", (req, res) => res.send("ICC Production Module Backend is running!"));

// --- Authentication Routes (New) ---
app.post("/api/auth/login", async (req, res) => {
  const { username, password } = req.body;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  if (!username || !password) return res.status(400).json({ error: "Username and password are required" });

  try {
    const result = await dbPool.query("SELECT user_id, username, password_hash, role, is_active FROM users WHERE username = $1", [username]);
    if (result.rows.length === 0) return res.status(401).json({ error: "Invalid credentials" });

    const user = result.rows[0];
    if (!user.is_active) return res.status(403).json({ error: "User account is inactive" });

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return res.status(401).json({ error: "Invalid credentials" });

    // Generate JWT
    const userPayload = { userId: user.user_id, username: user.username, role: user.role };
    const accessToken = jwt.sign(userPayload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    res.json({ accessToken, user: userPayload });

  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// --- User Management Routes (New - Admin Only) ---
const adminOnly = authorizeRole("admin");

app.post("/api/users", authenticateToken, adminOnly, async (req, res) => {
  const { username, password, fullName, role } = req.body;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  if (!username || !password || !role) return res.status(400).json({ error: "Username, password, and role are required" });
  // TODO: Add validation for role enum

  try {
    const hashedPassword = await bcrypt.hash(password, BCRYPT_SALT_ROUNDS);
    const result = await dbPool.query(
      "INSERT INTO users (username, password_hash, full_name, role) VALUES ($1, $2, $3, $4) RETURNING user_id, username, full_name, role, is_active, created_at",
      [username, hashedPassword, fullName, role]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("Error creating user:", err);
    if (err.code === "23505") return res.status(409).json({ error: "Username already exists" });
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/api/users", authenticateToken, adminOnly, async (req, res) => {
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    const result = await dbPool.query("SELECT user_id, username, full_name, role, is_active, created_at FROM users ORDER BY user_id");
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching users:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/api/users/:userId", authenticateToken, adminOnly, async (req, res) => {
  const { userId } = req.params;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    const result = await dbPool.query("SELECT user_id, username, full_name, role, is_active, created_at FROM users WHERE user_id = $1", [userId]);
    if (result.rows.length === 0) return res.status(404).json({ error: "User not found" });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(`Error fetching user ${userId}:`, err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.put("/api/users/:userId", authenticateToken, adminOnly, async (req, res) => {
  const { userId } = req.params;
  const { fullName, role, isActive, password } = req.body; // Allow updating these fields
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });

  const updates = [];
  const values = [];
  let valueIndex = 1;

  if (fullName !== undefined) { updates.push(`full_name = $${valueIndex++}`); values.push(fullName); }
  if (role !== undefined) { updates.push(`role = $${valueIndex++}`); values.push(role); }
  if (isActive !== undefined) { updates.push(`is_active = $${valueIndex++}`); values.push(isActive); }
  if (password) { 
    const hashedPassword = await bcrypt.hash(password, BCRYPT_SALT_ROUNDS);
    updates.push(`password_hash = $${valueIndex++}`); 
    values.push(hashedPassword); 
  }

  if (updates.length === 0) return res.status(400).json({ error: "No update fields provided" });

  values.push(userId); // Add userId for the WHERE clause

  try {
    const query = `UPDATE users SET ${updates.join(", ")}, updated_at = NOW() WHERE user_id = $${valueIndex} RETURNING user_id, username, full_name, role, is_active, updated_at`;
    const result = await dbPool.query(query, values);
    if (result.rows.length === 0) return res.status(404).json({ error: "User not found" });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(`Error updating user ${userId}:`, err);
    // TODO: Add validation for role enum
    res.status(500).json({ error: "Internal server error" });
  }
});

// Deactivate user instead of deleting
app.delete("/api/users/:userId", authenticateToken, adminOnly, async (req, res) => {
  const { userId } = req.params;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    const result = await dbPool.query("UPDATE users SET is_active = false, updated_at = NOW() WHERE user_id = $1 RETURNING user_id", [userId]);
    if (result.rows.length === 0) return res.status(404).json({ error: "User not found" });
    res.status(200).json({ message: "User deactivated successfully" });
  } catch (err) {
    console.error(`Error deactivating user ${userId}:`, err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// --- Protected Routes (Apply Middleware) ---
// Example: Protect all subsequent routes
// app.use(authenticateToken);

// Example: Protect specific routes
// app.get("/api/some-admin-data", authenticateToken, adminOnly, (req, res) => { ... });

// --- Product Routes ---
app.get("/api/products/:productId/bom", authenticateToken, async (req, res) => { // Added auth
  const { productId } = req.params;
  const { stageId } = req.query;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    let query = `SELECT bi.*, m.name as material_name FROM bom_items bi JOIN materials m ON bi.material_id = m.material_id WHERE bi.product_id = $1`;
    const params = [productId];
    if (stageId) { query += " AND bi.stage_id = $2"; params.push(stageId); }
    query += " ORDER BY bi.material_id";
    const result = await dbPool.query(query, params);
    res.json(result.rows);
  } catch (err) { console.error(`Error fetching BOM for product ${productId}:`, err); res.status(500).json({ error: "Internal server error" }); }
});

// --- Production Order Routes ---
app.get("/api/orders", authenticateToken, authorizeRoles(["admin", "production_manager", "sales_rep"]), async (req, res) => { // Added auth + roles
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    const result = await dbPool.query("SELECT order_id, sales_order_id, order_type, status, customer_name, approval_status, created_at FROM production_orders ORDER BY created_at DESC");
    res.json(result.rows);
  } catch (err) { console.error("Error fetching production orders:", err); res.status(500).json({ error: "Internal server error" }); }
});

// Manual order creation - restricted to admin/manager?
app.post("/api/orders", authenticateToken, authorizeRoles(["admin", "production_manager"]), async (req, res) => { // Added auth + roles
  const { sales_order_id, order_type, customer_name } = req.body;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  if (!order_type || !["standard", "partially_customized", "fully_customized"].includes(order_type)) return res.status(400).json({ error: "Invalid or missing order_type" });
  try {
    const result = await dbPool.query("INSERT INTO production_orders (sales_order_id, order_type, customer_name, status, approval_status) VALUES ($1, $2, $3, \'pending\', \'pending\') RETURNING *", [sales_order_id, order_type, customer_name]);
    const newOrder = result.rows[0];
    publishEvent({ type: "order_created", orderId: newOrder.order_id, orderType: newOrder.order_type, salesOrderId: newOrder.sales_order_id, userId: req.user.userId, timestamp: new Date().toISOString() });
    res.status(201).json(newOrder);
  } catch (err) {
    console.error("Error creating production order:", err);
    if (err.code === "23505") return res.status(409).json({ error: `Order with sales_order_id \'${sales_order_id}\' already exists.` });
    res.status(500).json({ error: "Internal server error" });
  }
});

// --- Production Piece Routes ---
app.get("/api/pieces/:pieceId", authenticateToken, async (req, res) => { // Added auth
  const { pieceId } = req.params;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[4][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  if (!uuidRegex.test(pieceId)) return res.status(400).json({ error: "Invalid Piece ID format" });
  try {
    const result = await dbPool.query("SELECT pp.*, po.sales_order_id, p.name as product_name FROM production_pieces pp JOIN production_orders po ON pp.production_order_id = po.order_id JOIN products p ON pp.product_id = p.product_id WHERE pp.piece_id = $1", [pieceId]);
    if (result.rows.length === 0) return res.status(404).json({ error: "Piece not found" });
    const pieceData = result.rows[0];
    res.json(pieceData);
    publishEvent({ type: "piece_scanned", pieceId: pieceId, userId: req.user.userId, timestamp: new Date().toISOString() });
  } catch (err) { console.error("Error fetching piece data:", err); res.status(500).json({ error: "Internal server error" }); }
});

// --- Workshop Panel Operation Routes ---
const workerOrManager = authorizeRoles(["worker", "production_manager", "admin"]);

app.get("/api/workshops/:workshopId/operations", authenticateToken, workerOrManager, async (req, res) => { // Added auth + roles
  const { workshopId } = req.params;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    const result = await dbPool.query(
      `SELECT op.*, p.description as piece_description, p.product_id, po.sales_order_id
       FROM production_operations op
       JOIN production_pieces p ON op.piece_id = p.piece_id
       JOIN production_orders po ON p.production_order_id = po.order_id
       WHERE op.workshop_id = $1 AND op.status IN ('pending', 'in_progress', 'paused', 'qc_pending', 'qc_failed', 'rework')
       ORDER BY op.created_at ASC`,
      [workshopId]
    );
    res.json(result.rows);
  } catch (err) { console.error(`Error fetching operations for workshop ${workshopId}:`, err); res.status(500).json({ error: "Internal server error" }); }
});

app.post("/api/operations/:operationId/start", authenticateToken, workerOrManager, async (req, res) => { // Added auth + roles
  const { operationId } = req.params;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    const now = new Date();
    await dbPool.query("BEGIN");
    const result = await dbPool.query("UPDATE production_operations SET status = \'in_progress\', start_time = $1 WHERE operation_id = $2 AND status = \'pending\' RETURNING *", [now, operationId]);
    if (result.rows.length === 0) { await dbPool.query("ROLLBACK"); return res.status(404).json({ error: "Operation not found or not in pending state" }); }
    const operation = result.rows[0];
    await dbPool.query("UPDATE production_pieces SET status = \'in_progress\' WHERE piece_id = $1", [operation.piece_id]);
    await dbPool.query("COMMIT");
    publishEvent({ type: "operation_started", operationId: operation.operation_id, pieceId: operation.piece_id, stageId: operation.stage_id, workshopId: operation.workshop_id, userId: req.user.userId, timestamp: now.toISOString() });
    res.json(operation);
  } catch (err) { await dbPool.query("ROLLBACK"); console.error(`Error starting operation ${operationId}:`, err); res.status(500).json({ error: "Internal server error" }); }
});

app.post("/api/operations/:operationId/pause", authenticateToken, workerOrManager, async (req, res) => { // Added auth + roles
  const { operationId } = req.params;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    const now = new Date();
    await dbPool.query("BEGIN");
    const result = await dbPool.query("UPDATE production_operations SET status = \'paused\', pause_time = $1 WHERE operation_id = $2 AND status = \'in_progress\' RETURNING *", [now, operationId]);
    if (result.rows.length === 0) { await dbPool.query("ROLLBACK"); return res.status(404).json({ error: "Operation not found or not in progress" }); }
    const operation = result.rows[0];
    await dbPool.query("UPDATE production_pieces SET status = \'paused\' WHERE piece_id = $1", [operation.piece_id]);
    await dbPool.query("COMMIT");
    publishEvent({ type: "operation_paused", operationId: operation.operation_id, pieceId: operation.piece_id, userId: req.user.userId, timestamp: now.toISOString() });
    res.json(operation);
  } catch (err) { await dbPool.query("ROLLBACK"); console.error(`Error pausing operation ${operationId}:`, err); res.status(500).json({ error: "Internal server error" }); }
});

app.post("/api/operations/:operationId/resume", authenticateToken, workerOrManager, async (req, res) => { // Added auth + roles
  const { operationId } = req.params;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    const now = new Date();
    await dbPool.query("BEGIN");
    const pauseResult = await dbPool.query("SELECT piece_id, pause_time FROM production_operations WHERE operation_id = $1 AND status = \'paused\' FOR UPDATE", [operationId]);
    if (pauseResult.rows.length === 0) { await dbPool.query("ROLLBACK"); return res.status(404).json({ error: "Operation not found or not paused" }); }
    const { piece_id, pause_time } = pauseResult.rows[0];
    const pausedDurationSeconds = Math.round((now.getTime() - new Date(pause_time).getTime()) / 1000);
    const result = await dbPool.query("UPDATE production_operations SET status = \'in_progress\', pause_time = NULL, total_paused_duration_seconds = total_paused_duration_seconds + $1 WHERE operation_id = $2 RETURNING *", [pausedDurationSeconds, operationId]);
    await dbPool.query("UPDATE production_pieces SET status = \'in_progress\' WHERE piece_id = $1", [piece_id]);
    await dbPool.query("COMMIT");
    const operation = result.rows[0];
    publishEvent({ type: "operation_resumed", operationId: operation.operation_id, pieceId: operation.piece_id, pausedDuration: pausedDurationSeconds, userId: req.user.userId, timestamp: now.toISOString() });
    res.json(operation);
  } catch (err) { await dbPool.query("ROLLBACK"); console.error(`Error resuming operation ${operationId}:`, err); res.status(500).json({ error: "Internal server error" }); }
});

app.post("/api/operations/:operationId/complete", authenticateToken, workerOrManager, async (req, res) => { // Added auth + roles
  const { operationId } = req.params;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    const now = new Date();
    await dbPool.query("BEGIN");
    const opResult = await dbPool.query("SELECT piece_id, stage_id, start_time, total_paused_duration_seconds FROM production_operations WHERE operation_id = $1 AND status IN (\'in_progress\', \'paused\') FOR UPDATE", [operationId]);
    if (opResult.rows.length === 0) { await dbPool.query("ROLLBACK"); return res.status(404).json({ error: "Operation not found or not in progress/paused" }); }
    const { piece_id, stage_id, start_time, total_paused_duration_seconds } = opResult.rows[0];
    let actualDurationSeconds = 0;
    if (start_time) { actualDurationSeconds = Math.max(0, Math.round((now.getTime() - new Date(start_time).getTime()) / 1000) - (total_paused_duration_seconds || 0)); }
    const result = await dbPool.query("UPDATE production_operations SET status = \'completed\', end_time = $1, actual_duration_seconds = $2 WHERE operation_id = $3 RETURNING *", [now, actualDurationSeconds, operationId]);
    const operation = result.rows[0];
    await dbPool.query("UPDATE production_pieces SET status = \'qc_pending\' WHERE piece_id = $1", [piece_id]);
    await dbPool.query("INSERT INTO piece_workflow_history (piece_id, operation_id, event_type, stage_id, user_id, details) VALUES ($1, $2, \'op_complete\', $3, $4, $5)", [piece_id, operationId, stage_id, req.user.userId, JSON.stringify({ actualDuration: actualDurationSeconds })]);
    await dbPool.query("COMMIT");
    publishEvent({ type: "operation_completed", operationId: operation.operation_id, pieceId: operation.piece_id, actualDuration: actualDurationSeconds, userId: req.user.userId, timestamp: now.toISOString() });
    res.json({ operation, piece_status: "qc_pending" }); 
  } catch (err) { await dbPool.query("ROLLBACK"); console.error(`Error completing operation ${operationId}:`, err); res.status(500).json({ error: "Internal server error" }); }
});

app.post("/api/operations/:operationId/workers", authenticateToken, workerOrManager, async (req, res) => { // Added auth + roles
  const { operationId } = req.params;
  const { userId } = req.body;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  if (!userId) return res.status(400).json({ error: "Missing userId" });
  try {
    await dbPool.query("BEGIN");
    const countResult = await dbPool.query("SELECT count(*) as worker_count FROM operation_worker_assignments WHERE operation_id = $1 FOR SHARE", [operationId]);
    const workerCount = parseInt(countResult.rows[0].worker_count, 10);
    if (workerCount >= MAX_WORKERS_PER_OPERATION) { await dbPool.query("ROLLBACK"); return res.status(400).json({ error: `Cannot assign more than ${MAX_WORKERS_PER_OPERATION} workers` }); }
    const result = await dbPool.query("INSERT INTO operation_worker_assignments (operation_id, user_id) VALUES ($1, $2) ON CONFLICT (operation_id, user_id) DO NOTHING RETURNING *", [operationId, userId]);
    await dbPool.query("COMMIT");
    if (result.rows.length > 0) {
        const assignment = result.rows[0];
        publishEvent({ type: "worker_assigned", operationId: assignment.operation_id, assignedUserId: assignment.user_id, assigningUserId: req.user.userId, timestamp: new Date().toISOString() });
        res.status(201).json(assignment);
    } else { res.status(200).json({ message: "Worker already assigned" }); }
  } catch (err) {
    await dbPool.query("ROLLBACK");
    console.error(`Error assigning worker ${userId} to operation ${operationId}:`, err);
    if (err.code === "23503") return res.status(404).json({ error: "Operation or User not found" });
    res.status(500).json({ error: "Internal server error" });
  }
});

app.delete("/api/operations/:operationId/workers/:userId", authenticateToken, workerOrManager, async (req, res) => { // Added auth + roles
  const { operationId, userId } = req.params;
  const dbPool = getDbPool(req);
  if (!dbPool) return res.status(500).json({ error: "Database connection not available" });
  try {
    const result = await dbPool.query("DELETE FROM operation_worker_assignments WHERE operation_id = $1 AND user_id = $2 RETURNING *", [operationId, userId]);
    if (result.rows.length === 0) return res.status(404).json({ error: "Assignment not found" });
    publishEvent({ type: "worker_removed", operationId: operationId, removedUserId: userId, removingUserId: req.user.userId, timestamp: new Date().toISOString() });
    res.status(200).json({ message: "Worker removed successfully" });
  } catch (err) { console.error(`Error removing worker ${userId} from operation ${operationId}:`, err); res.status(500).json({ error: "Internal server error" }); }
});

// --- Quality Control Routes ---
const qcOrManager = authorizeRoles(["qc_inspector", "production_manager", "admin"]);

app.post("/api/quality-checks", authenticateToken, qcOrManager, upload.single("qcImage"), async (req, res) => { // Added auth + roles
  const { pieceId, operationId, stageId, result, notes } = req.body;
  const qcUserId = req.user.userId; // Get user ID from token
  const imagePath = req.file ? req.file.path : null;
  const dbPool = getDbPool(req);
  if (!pieceId || !result || !["accepted", "rejected"].includes(result)) { if (imagePath) fs.unlinkSync(imagePath); return res.status(400).json({ error: "Missing required fields: pieceId, result (accepted/rejected)" }); }
  const client = await dbPool.connect();
  try {
    await client.query("BEGIN");
    const qcInsertResult = await client.query("INSERT INTO quality_checks (piece_id, operation_id, stage_id, qc_user_id, result, notes, image_path) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *", [pieceId, operationId, stageId, qcUserId, result, notes, imagePath]);
    const newQcCheck = qcInsertResult.rows[0];
    let nextPieceStatus = "";
    if (result === "accepted") { nextPieceStatus = "qc_passed"; console.log(`QC Passed for piece ${pieceId}. Workflow logic needed.`); }
    else { nextPieceStatus = "qc_failed"; console.log(`QC Failed for piece ${pieceId}. Rework logic needed.`); }
    await client.query("UPDATE production_pieces SET status = $1 WHERE piece_id = $2", [nextPieceStatus, pieceId]);
    await client.query("INSERT INTO piece_workflow_history (piece_id, operation_id, qc_id, event_type, stage_id, user_id, details) VALUES ($1, $2, $3, $4, $5, $6, $7)", [pieceId, operationId, newQcCheck.qc_id, `qc_${result}`, stageId, qcUserId, JSON.stringify({ notes: notes, imagePath: imagePath, nextStatus: nextPieceStatus })]);
    await client.query("COMMIT");
    publishEvent({ type: `qc_${result}`, qcId: newQcCheck.qc_id, pieceId: pieceId, operationId: operationId, stageId: stageId, userId: qcUserId, notes: notes, imagePath: imagePath, nextStatus: nextPieceStatus, timestamp: new Date().toISOString() });
    res.status(201).json({ qcCheck: newQcCheck, pieceStatus: nextPieceStatus });
  } catch (err) {
    await client.query("ROLLBACK");
    if (imagePath) { try { fs.unlinkSync(imagePath); } catch (unlinkErr) { console.error("Error deleting uploaded file after transaction rollback:", unlinkErr); } }
    console.error("Error submitting quality check:", err);
    if (err.code === "23503") return res.status(404).json({ error: "Invalid pieceId, operationId, stageId, or qcUserId" });
    res.status(500).json({ error: "Internal server error" });
  } finally { client.release(); }
});

// --- Material Consumption Routes ---
app.post("/api/operations/:operationId/consumption", authenticateToken, workerOrManager, async (req, res) => { // Added auth + roles
  const { operationId } = req.params;
  const consumedItems = req.body.items;
  const loggingUserId = req.user.userId; // Get user ID from token
  const dbPool = getDbPool(req);
  if (!consumedItems || !Array.isArray(consumedItems) || consumedItems.length === 0) return res.status(400).json({ error: "Missing or invalid 'items' array in request body" });
  for (const item of consumedItems) {
    if (!item.materialId || !item.quantity || !item.unit) return res.status(400).json({ error: `Invalid item: ${JSON.stringify(item)}. Missing required fields.` });
    if (isNaN(parseFloat(item.quantity)) || parseFloat(item.quantity) <= 0) return res.status(400).json({ error: `Invalid quantity for material ${item.materialId}: ${item.quantity}` });
  }
  const client = await dbPool.connect();
  try {
    await client.query("BEGIN");
    const opResult = await client.query("SELECT piece_id FROM production_operations WHERE operation_id = $1", [operationId]);
    if (opResult.rows.length === 0) throw new Error("Operation not found");
    const pieceId = opResult.rows[0].piece_id;
    const insertedLogs = [];
    for (const item of consumedItems) {
      const result = await client.query("INSERT INTO material_consumption_log (operation_id, piece_id, material_id, consumed_quantity, unit_of_measure, user_id, notes) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *", [operationId, pieceId, item.materialId, parseFloat(item.quantity), item.unit, loggingUserId, item.notes || null]);
      const newLog = result.rows[0];
      insertedLogs.push(newLog);
      await client.query("INSERT INTO piece_workflow_history (piece_id, operation_id, material_log_id, event_type, user_id, details) VALUES ($1, $2, $3, \'material_logged\', $4, $5)", [pieceId, operationId, newLog.log_id, loggingUserId, JSON.stringify({ materialId: item.materialId, quantity: item.quantity, unit: item.unit })]);
      publishEvent({ type: "material_logged", logId: newLog.log_id, operationId: operationId, pieceId: pieceId, materialId: item.materialId, quantity: item.quantity, unit: item.unit, userId: loggingUserId, timestamp: new Date().toISOString() });
    }
    await client.query("COMMIT");
    res.status(201).json({ logs: insertedLogs });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error(`Error logging material consumption for operation ${operationId}:`, err);
    if (err.message === "Operation not found") return res.status(404).json({ error: err.message });
    if (err.code === "23503") return res.status(404).json({ error: "Invalid operationId, pieceId, materialId, or userId" });
    res.status(500).json({ error: "Internal server error" });
  } finally { client.release(); }
});

// --- Start Server ---
const server = app.listen(PORT, "0.0.0.0", () => console.log(`Server listening on port ${PORT}`));

// --- Graceful Shutdown ---
process.on("SIGTERM", async () => {
  console.log("SIGTERM signal received: closing HTTP server");
  server.close(async () => {
    console.log("HTTP server closed");
    const currentRedisClient = app.get("redisClient");
    if (currentRedisClient && currentRedisClient.isReady) { try { await currentRedisClient.quit(); console.log("Redis client disconnected"); } catch (err) { console.error("Error disconnecting Redis client:", err); } }
    const currentDbPool = app.get("dbPool");
    if (currentDbPool) { try { await currentDbPool.end(); console.log("PostgreSQL pool closed"); } catch (err) { console.error("Error closing PostgreSQL pool:", err); } }
    process.exit(0);
  });
});

