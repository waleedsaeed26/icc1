-- Schema for the Production Module (ICC Furniture) - Updated for User Management

-- Enable UUID generation if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enum for order types
CREATE TYPE production_order_type AS ENUM (
    'standard',
    'partially_customized',
    'fully_customized'
);

-- Enum for operation/piece status
CREATE TYPE operation_status AS ENUM (
    'pending',       -- Operation/Piece waiting to start
    'in_progress',   -- Operation/Piece being worked on
    'paused',        -- Operation temporarily stopped
    'completed',     -- Operation finished, awaiting QC or material log
    'qc_pending',    -- Piece finished operation, awaiting QC check
    'qc_passed',     -- Piece passed QC
    'qc_failed',     -- Piece failed QC, awaiting rework decision
    'rework',        -- Piece undergoing rework
    'shipped'        -- Piece completed all stages and shipped (final status)
);

-- Enum for QC result
CREATE TYPE qc_result AS ENUM (
    'accepted',
    'rejected'
);

-- Enum for User Roles (More explicit)
CREATE TYPE user_role AS ENUM (
    'worker',
    'qc_inspector',
    'production_manager',
    'sales_rep',
    'admin'
);

-- Users Table (Enhanced)
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL, -- Added for authentication
    full_name VARCHAR(255),
    role user_role NOT NULL, -- Use the enum type
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Workshops Table
CREATE TABLE workshops (
    workshop_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT
);

-- Stages Table
CREATE TABLE stages (
    stage_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    workshop_id VARCHAR(50) REFERENCES workshops(workshop_id),
    standard_time_minutes INT,
    is_qc_stage BOOLEAN DEFAULT FALSE
);

-- Products Table
CREATE TABLE products (
    product_id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Materials Table
CREATE TABLE materials (
    material_id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    unit_of_measure VARCHAR(20) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Bill of Materials Items Table
CREATE TABLE bom_items (
    bom_item_id SERIAL PRIMARY KEY,
    product_id VARCHAR(100) NOT NULL REFERENCES products(product_id) ON DELETE CASCADE,
    stage_id VARCHAR(50) REFERENCES stages(stage_id),
    material_id VARCHAR(100) NOT NULL REFERENCES materials(material_id) ON DELETE CASCADE,
    standard_quantity DECIMAL(10, 4) NOT NULL,
    unit_of_measure VARCHAR(20) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (product_id, stage_id, material_id)
);

-- Production Orders Table
CREATE TABLE production_orders (
    order_id SERIAL PRIMARY KEY,
    sales_order_id VARCHAR(100) UNIQUE,
    order_type production_order_type NOT NULL,
    status VARCHAR(50) DEFAULT 'pending' NOT NULL,
    customer_name VARCHAR(255),
    approval_status VARCHAR(50) DEFAULT 'pending' NOT NULL,
    approved_by INT REFERENCES users(user_id),
    approved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Production Pieces Table
CREATE TABLE production_pieces (
    piece_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    production_order_id INT NOT NULL REFERENCES production_orders(order_id) ON DELETE CASCADE,
    product_id VARCHAR(100) NOT NULL REFERENCES products(product_id),
    description TEXT,
    qr_code_data JSONB UNIQUE,
    current_stage_id VARCHAR(50) REFERENCES stages(stage_id),
    current_workshop_id VARCHAR(50) REFERENCES workshops(workshop_id),
    status operation_status DEFAULT 'pending' NOT NULL,
    customization_details JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Production Operations Table
CREATE TABLE production_operations (
    operation_id SERIAL PRIMARY KEY,
    piece_id UUID NOT NULL REFERENCES production_pieces(piece_id) ON DELETE CASCADE,
    stage_id VARCHAR(50) NOT NULL REFERENCES stages(stage_id),
    workshop_id VARCHAR(50) NOT NULL REFERENCES workshops(workshop_id),
    status operation_status DEFAULT 'pending' NOT NULL,
    start_time TIMESTAMP WITH TIME ZONE,
    pause_time TIMESTAMP WITH TIME ZONE,
    total_paused_duration_seconds INT DEFAULT 0,
    end_time TIMESTAMP WITH TIME ZONE,
    actual_duration_seconds INT,
    standard_time_minutes INT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Operation Worker Assignments Table
CREATE TABLE operation_worker_assignments (
    assignment_id SERIAL PRIMARY KEY,
    operation_id INT NOT NULL REFERENCES production_operations(operation_id) ON DELETE CASCADE,
    user_id INT NOT NULL REFERENCES users(user_id),
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (operation_id, user_id)
);

-- Quality Checks Table
CREATE TABLE quality_checks (
    qc_id SERIAL PRIMARY KEY,
    piece_id UUID NOT NULL REFERENCES production_pieces(piece_id) ON DELETE CASCADE,
    operation_id INT REFERENCES production_operations(operation_id),
    stage_id VARCHAR(50) REFERENCES stages(stage_id),
    qc_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    qc_user_id INT REFERENCES users(user_id),
    result qc_result NOT NULL,
    notes TEXT,
    image_path VARCHAR(512),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Material Consumption Log Table
CREATE TABLE material_consumption_log (
    log_id SERIAL PRIMARY KEY,
    operation_id INT NOT NULL REFERENCES production_operations(operation_id) ON DELETE CASCADE,
    piece_id UUID NOT NULL REFERENCES production_pieces(piece_id) ON DELETE CASCADE,
    material_id VARCHAR(100) NOT NULL REFERENCES materials(material_id),
    consumed_quantity DECIMAL(10, 4) NOT NULL,
    unit_of_measure VARCHAR(20) NOT NULL,
    consumption_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    user_id INT REFERENCES users(user_id),
    notes TEXT
);

-- Piece Workflow History Table
CREATE TABLE piece_workflow_history (
    history_id SERIAL PRIMARY KEY,
    piece_id UUID NOT NULL REFERENCES production_pieces(piece_id) ON DELETE CASCADE,
    operation_id INT REFERENCES production_operations(operation_id),
    qc_id INT REFERENCES quality_checks(qc_id),
    material_log_id INT REFERENCES material_consumption_log(log_id),
    event_type VARCHAR(50) NOT NULL,
    stage_id VARCHAR(50),
    workshop_id VARCHAR(50),
    event_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    user_id INT REFERENCES users(user_id),
    details JSONB
);

-- Index for faster lookups
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_role ON users(role);

CREATE INDEX idx_prod_name ON products(name);
CREATE INDEX idx_mat_name ON materials(name);
CREATE INDEX idx_bom_product_id ON bom_items(product_id);
CREATE INDEX idx_bom_stage_id ON bom_items(stage_id);
CREATE INDEX idx_bom_material_id ON bom_items(material_id);

CREATE INDEX idx_po_sales_order_id ON production_orders(sales_order_id);
CREATE INDEX idx_po_status ON production_orders(status);

CREATE INDEX idx_pp_order_id ON production_pieces(production_order_id);
CREATE INDEX idx_pp_status ON production_pieces(status);
CREATE INDEX idx_pp_product_id ON production_pieces(product_id);
CREATE INDEX idx_pp_qr_code_data ON production_pieces USING GIN (qr_code_data);

CREATE INDEX idx_pop_piece_id ON production_operations(piece_id);
CREATE INDEX idx_pop_stage_id ON production_operations(stage_id);
CREATE INDEX idx_pop_status ON production_operations(status);

CREATE INDEX idx_owa_operation_id ON operation_worker_assignments(operation_id);

CREATE INDEX idx_qc_piece_id ON quality_checks(piece_id);
CREATE INDEX idx_qc_operation_id ON quality_checks(operation_id);

CREATE INDEX idx_mcl_operation_id ON material_consumption_log(operation_id);
CREATE INDEX idx_mcl_piece_id ON material_consumption_log(piece_id);
CREATE INDEX idx_mcl_material_id ON material_consumption_log(material_id);

CREATE INDEX idx_pwh_piece_id ON piece_workflow_history(piece_id);
CREATE INDEX idx_pwh_timestamp ON piece_workflow_history(event_timestamp DESC);
CREATE INDEX idx_pwh_event_type ON piece_workflow_history(event_type);

-- Trigger function to update 'updated_at' timestamp automatically
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply trigger to tables
CREATE TRIGGER update_users_modtime BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_products_modtime BEFORE UPDATE ON products FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_materials_modtime BEFORE UPDATE ON materials FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bom_items_modtime BEFORE UPDATE ON bom_items FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_production_orders_modtime BEFORE UPDATE ON production_orders FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_production_pieces_modtime BEFORE UPDATE ON production_pieces FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_production_operations_modtime BEFORE UPDATE ON production_operations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Note: Workflow logic (defining stage sequences) is still needed.

