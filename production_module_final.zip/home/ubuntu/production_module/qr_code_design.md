# تصميم نظام تتبع QR Code لموديول الإنتاج

بناءً على المتطلبات، سيتم تصميم نظام تتبع QR Code لربط كل قطعة منتجة بأمر البيع الخاص بها وتتبعها عبر مراحل الإنتاج المختلفة.

## 1. البيانات المشفرة في QR Code (لكل قطعة)

سيحتوي كل QR Code فرعي خاص بقطعة إنتاج على المعلومات الأساسية اللازمة لتحديدها وتتبعها. يمكن استخدام تنسيق JSON لتنظيم البيانات داخل الـ QR Code لسهولة القراءة والمعالجة:

```json
{
  "pieceId": "UNIQUE_PIECE_IDENTIFIER", // معرف فريد للقطعة (قد يكون تسلسلي أو UUID)
  "salesOrderId": "SO-12345",          // رقم أمر البيع المرتبط
  "productId": "PROD-XYZ",            // معرف المنتج
  "currentStageId": "STAGE-WELD",       // معرف المرحلة الحالية
  "currentWorkshopId": "WS-METAL"       // معرف الورشة الحالية
}
```

**ملاحظات:**
*   سيتم إنشاء `pieceId` فريد لكل قطعة عند توليد أمر الإنتاج من طلب الإنتاج المجمع.
*   سيتم تحديث `currentStageId` و `currentWorkshopId` ديناميكيًا عند مسح الـ QR Code في كل مرحلة/ورشة جديدة.
*   يمكن إضافة بيانات أخرى حسب الحاجة المستقبلية، ولكن يفضل إبقاء البيانات الأساسية فقط في الـ QR لتقليل حجمه وزيادة سرعة القراءة، مع جلب التفاصيل الأخرى (مثل بيانات العميل، تفاصيل المنتج الكاملة، إلخ) من قاعدة البيانات باستخدام المعرفات الموجودة.

## 2. تحديثات مخطط قاعدة البيانات (PostgreSQL)

لتخزين وإدارة معلومات تتبع القطع وربطها بالـ QR Codes، سنحتاج إلى إضافة جداول جديدة وتعديل الجداول الحالية في `schema.sql`.

**الجداول المقترحة:**

```sql
-- جدول لتخزين تفاصيل كل قطعة إنتاج فردية
CREATE TABLE production_pieces (
    piece_id UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- استخدام UUID كمعرف فريد
    production_order_id INT NOT NULL REFERENCES production_orders(order_id),
    product_id VARCHAR(100) NOT NULL, -- معرف المنتج (يمكن ربطه بجدول منتجات لاحقًا)
    qr_code_data TEXT UNIQUE, -- يمكن تخزين بيانات QR هنا أو رابط لها
    current_stage_id VARCHAR(50), -- معرف المرحلة الحالية (يمكن ربطه بجدول مراحل)
    current_workshop_id VARCHAR(50), -- معرف الورشة الحالية (يمكن ربطه بجدول ورش)
    status VARCHAR(50) DEFAULT 'pending' NOT NULL, -- e.g., pending, in_progress, quality_check, rework, completed
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    -- Add foreign keys to stages, workshops, products etc. as needed
);

-- جدول لتسجيل تاريخ حركة القطعة بين المراحل/الورش (سجل التتبع)
CREATE TABLE piece_workflow_history (
    history_id SERIAL PRIMARY KEY,
    piece_id UUID NOT NULL REFERENCES production_pieces(piece_id),
    previous_stage_id VARCHAR(50),
    new_stage_id VARCHAR(50) NOT NULL,
    workshop_id VARCHAR(50) NOT NULL,
    scan_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    worker_id INT -- العامل الذي قام بالمسح (يمكن ربطه بجدول عمال)
);

-- تعديل جدول production_orders لإزالة بعض الحقول التي ستكون على مستوى القطعة
-- (إذا كان الأمر يمثل مجموعة قطع، قد نحتفظ ببعض الحقول الملخصة)
-- ALTER TABLE production_orders DROP COLUMN ...;

-- إضافة Trigger لتحديث updated_at لجدول production_pieces
CREATE TRIGGER update_production_pieces_modtime
BEFORE UPDATE ON production_pieces
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column(); -- استخدام نفس الدالة المعرفة سابقًا

-- إضافة فهارس لتحسين الأداء
CREATE INDEX idx_piece_order_id ON production_pieces(production_order_id);
CREATE INDEX idx_piece_status ON production_pieces(status);
CREATE INDEX idx_history_piece_id ON piece_workflow_history(piece_id);
```

**ملاحظات:**
*   استخدام `UUID` لـ `piece_id` يضمن التفرد عبر النظام.
*   جدول `piece_workflow_history` يسجل كل انتقال للقطعة، مما يوفر سجل تتبع كامل.
*   سيتم تحديث `current_stage_id`, `current_workshop_id`, و `status` في جدول `production_pieces` عند كل عملية مسح ناجحة للـ QR Code وتسجيل عملية.

## 3. خطوات التنفيذ التالية:

1.  **تحديث `schema.sql`:** دمج التغييرات المقترحة في ملف `schema.sql`.
2.  **تطوير API Endpoints:** إنشاء نقاط نهاية في الواجهة الخلفية (Node.js) لـ:
    *   توليد `piece_id` و `qr_code_data` عند إنشاء أوامر الإنتاج للقطع.
    *   جلب تفاصيل القطعة عند مسح QR Code.
    *   تحديث حالة القطعة وموقعها (المرحلة/الورشة) وتسجيل سجل الحركة.
3.  **تكامل الواجهة الأمامية (React):** تطوير مكونات في لوحة التحكم لقراءة QR Codes (قد يتطلب استخدام كاميرا الجهاز أو قارئ خارجي) والتفاعل مع الـ API.




## 4. اعتبارات إضافية (بناءً على المتطلبات الجديدة)

*   **التوافق مع الأجهزة المحمولة:** يجب تصميم واجهات مسح QR Code (في الواجهة الأمامية React) لتكون متجاوبة تمامًا وتعمل بكفاءة على متصفحات الأجهزة المحمولة (هواتف ذكية وأجهزة لوحية). سيشمل ذلك استخدام تصميم مرن، واختبار الواجهات على أحجام شاشات مختلفة، والتأكد من سهولة استخدام الكاميرا للمسح.
*   **العلامة التجارية:** يجب تطبيق العلامة التجارية "ADAM'S FURNITURE" على جميع واجهات النظام، بما في ذلك شاشات مسح QR Code ولوحات التحكم.
*   **تسمية الحقول:** يجب استخدام مسمى "الوصف" بدلاً من "وصف القطعه" في جميع الواجهات وهياكل البيانات المتعلقة بتفاصيل المنتج أو القطعة.
*   **الوصول العام:** يجب أن يكون نظام مسح QR Code متاحًا عبر رابط عام يمكن مشاركته مع المستخدمين المصرح لهم (عمال الورش، مشرفي الجودة، إلخ). سيتطلب ذلك نشر الواجهة الأمامية وتأمين الوصول إليها بشكل مناسب.
