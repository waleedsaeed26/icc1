import axios from 'axios';

// Create an axios instance with default config
export const api = axios.create({ // Added export here
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000', // Corrected env variable name and removed /api suffix
  headers: {
    'Content-Type': 'application/json',
  },
});

// Helper function to get current user from localStorage
const getCurrentUserFromStorage = () => {
  try {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  } catch (error) {
    console.error("Error parsing user data from localStorage:", error);
    return null;
  }
};

// Add a request interceptor to include auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    // Add company_id query parameter if not present and user has company_id
    const user = getCurrentUserFromStorage();
    if (user && user.company_id && !config.params?.company_id && config.method?.toLowerCase() === 'get') {
      config.params = { ...config.params, company_id: user.company_id };
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Add a response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle 401 Unauthorized errors
    if (error.response && error.response.status === 401) {
      // Clear token and redirect to login
      authService.logout(); // Use logout function
      // Avoid redirecting if already on login page
      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// --- Existing Service Definitions ---

// API service for authentication
export const authService = {
  // Login
  login: async (credentials) => {
    const response = await api.post("/api/auth/login", credentials); // Added /api prefix
    if (response.data.token && response.data.user) {
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    return response;
  },
  // Register
  register: (userData) => 
    api.post('/auth/register', userData),
  
  // Logout
  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },
  
  // Get current user
  getCurrentUser: () => {
    try {
      const user = localStorage.getItem('user');
      return user ? JSON.parse(user) : null;
    } catch (error) {
      console.error("Error parsing user data from localStorage:", error);
      authService.logout(); // Clear invalid data
      return null;
    }
  },
  
  // Set current user
  setCurrentUser: (user) => {
    localStorage.setItem('user', JSON.stringify(user));
  },
  
  // Check if user is authenticated
  isAuthenticated: () => {
    return !!localStorage.getItem('token');
  },
};

// API service for workshops
export const workshopService = {
  getAllWorkshops: (companyId, onlyActive = true) => 
    api.get(`/workshops?company_id=${companyId}&only_active=${onlyActive}`),
  getWorkshopById: (id) => 
    api.get(`/workshops/${id}`),
  createWorkshop: (workshop) => 
    api.post('/workshops', workshop),
  updateWorkshop: (id, workshop) => 
    api.put(`/workshops/${id}`, workshop),
  deactivateWorkshop: (id, companyId) => 
    api.post(`/workshops/${id}/deactivate`, { company_id: companyId }),
  activateWorkshop: (id, companyId) => 
    api.post(`/workshops/${id}/activate`, { company_id: companyId }),
};

// API service for production items
export const productionService = {
  getAllProductionItems: (companyId) => 
    api.get(`/production-items?company_id=${companyId}`),
  getProductionItemById: (id) => 
    api.get(`/production-items/${id}`),
  getProductionItemByQrCode: (qrCode) => 
    api.get(`/production-items/qr/${qrCode}`),
  createProductionItem: (item) => 
    api.post('/production-items', item),
  updateProductionItem: (id, item) => 
    api.put(`/production-items/${id}`, item),
  moveProductionItem: (id, moveData) => 
    api.post(`/production-items/${id}/move`, moveData),
  getItemsByProductionOrder: (orderId) => 
    api.get(`/production-items/order/${orderId}`),
  getItemsByCurrentStage: (stageId, companyId) => 
    api.get(`/production-items/stage/${stageId}?company_id=${companyId}`),
};

// API service for companies
export const companyService = {
  getAllCompanies: () => 
    api.get('/companies'),
  getCompanyById: (id) => 
    api.get(`/companies/${id}`),
  createCompany: (company) => 
    api.post('/companies', company),
  updateCompany: (id, company) => 
    api.put(`/companies/${id}`, company),
  getChildCompanies: (parentId) => 
    api.get(`/companies/${parentId}/children`),
};

// API service for employees
export const employeeService = {
  getAllEmployees: (companyId) => 
    api.get(`/employees?company_id=${companyId}`),
  getEmployeeById: (id) => 
    api.get(`/employees/${id}`),
  createEmployee: (employee) => 
    api.post('/employees', employee),
  updateEmployee: (id, employee) => 
    api.put(`/employees/${id}`, employee),
};

// API service for departments
export const departmentService = {
  getAllDepartments: (companyId) => 
    api.get(`/departments?company_id=${companyId}`),
  getDepartmentById: (id) => 
    api.get(`/departments/${id}`),
  createDepartment: (department) => 
    api.post('/departments', department),
  updateDepartment: (id, department) => 
    api.put(`/departments/${id}`, department),
};

// API service for inventory
export const inventoryService = {
  getMaterialInventory: (companyId) => 
    api.get(`/inventory/materials?company_id=${companyId}`),
  getProductInventory: (companyId) => 
    api.get(`/inventory/products?company_id=${companyId}`),
  updateMaterialInventory: (transaction) => 
    api.post('/inventory/materials/transaction', transaction),
  updateProductInventory: (transaction) => 
    api.post('/inventory/products/transaction', transaction),
  getTransactionHistory: (companyId, filters = {}) => {
    let url = `/inventory/history?company_id=${companyId}`;
    if (filters.materialId) url += `&material_id=${filters.materialId}`;
    if (filters.productId) url += `&product_id=${filters.productId}`;
    if (filters.locationId) url += `&location_id=${filters.locationId}`;
    if (filters.startDate) url += `&start_date=${filters.startDate}`;
    if (filters.endDate) url += `&end_date=${filters.endDate}`;
    return api.get(url);
  },
};

// --- Costing Services ---

export const costCenterService = {
  getAll: (companyId) => api.get(`/cost-centers?company_id=${companyId}`),
  getById: (id) => api.get(`/cost-centers/${id}`),
  create: (data) => api.post('/cost-centers', data),
  update: (id, data) => api.put(`/cost-centers/${id}`, data),
  delete: (id) => api.delete(`/cost-centers/${id}`),
};

export const fixedCostService = {
  getAll: (companyId) => api.get(`/fixed-costs?company_id=${companyId}`),
  getById: (id) => api.get(`/fixed-costs/${id}`),
  create: (data) => api.post('/fixed-costs', data),
  update: (id, data) => api.put(`/fixed-costs/${id}`, data),
  delete: (id) => api.delete(`/fixed-costs/${id}`),
};

export const variableCostService = {
  getAll: (companyId) => api.get(`/variable-costs?company_id=${companyId}`),
  getById: (id) => api.get(`/variable-costs/${id}`),
  create: (data) => api.post('/variable-costs', data),
  update: (id, data) => api.put(`/variable-costs/${id}`, data),
  delete: (id) => api.delete(`/variable-costs/${id}`),
};

export const materialCostService = {
  getAll: (companyId) => api.get(`/material-costs?company_id=${companyId}`),
  getById: (id) => api.get(`/material-costs/${id}`),
  create: (data) => api.post('/material-costs', data),
  update: (id, data) => api.put(`/material-costs/${id}`, data),
  delete: (id) => api.delete(`/material-costs/${id}`),
};

export const laborCostService = {
  getAll: (companyId) => api.get(`/labor-costs?company_id=${companyId}`),
  getById: (id) => api.get(`/labor-costs/${id}`),
  create: (data) => api.post('/labor-costs', data),
  update: (id, data) => api.put(`/labor-costs/${id}`, data),
  delete: (id) => api.delete(`/labor-costs/${id}`),
};

export const operationalCostService = {
  getAll: (companyId) => api.get(`/operational-costs?company_id=${companyId}`),
  getById: (id) => api.get(`/operational-costs/${id}`),
  create: (data) => api.post('/operational-costs', data),
  update: (id, data) => api.put(`/operational-costs/${id}`, data),
  delete: (id) => api.delete(`/operational-costs/${id}`),
};

export const costTemplateService = {
  getAll: (companyId) => api.get(`/cost-templates?company_id=${companyId}`),
  getById: (id) => api.get(`/cost-templates/${id}`),
  create: (data) => api.post('/cost-templates', data),
  update: (id, data) => api.put(`/cost-templates/${id}`, data),
  delete: (id) => api.delete(`/cost-templates/${id}`),
};

export const productCostService = {
  getAll: (companyId) => api.get(`/product-costs?company_id=${companyId}`),
  getById: (id) => api.get(`/product-costs/${id}`),
  calculate: (productId) => api.post(`/product-costs/calculate/${productId}`),
  // Add other methods if needed (create, update, delete might not be applicable directly)
};

export const pricingRuleService = {
  getAll: (companyId) => api.get(`/pricing-rules?company_id=${companyId}`),
  getById: (id) => api.get(`/pricing-rules/${id}`),
  create: (data) => api.post('/pricing-rules', data),
  update: (id, data) => api.put(`/pricing-rules/${id}`, data),
  delete: (id) => api.delete(`/pricing-rules/${id}`),
};

export const costAllocationService = {
  getAll: (companyId) => api.get(`/cost-allocations?company_id=${companyId}`),
  getById: (id) => api.get(`/cost-allocations/${id}`),
  create: (data) => api.post('/cost-allocations', data),
  update: (id, data) => api.put(`/cost-allocations/${id}`, data),
  delete: (id) => api.delete(`/cost-allocations/${id}`),
};

export const historicalCostDataService = {
  getAll: (companyId) => api.get(`/historical-cost-data?company_id=${companyId}`),
  getById: (id) => api.get(`/historical-cost-data/${id}`),
  create: (data) => api.post('/historical-cost-data', data),
  update: (id, data) => api.put(`/historical-cost-data/${id}`, data),
  delete: (id) => api.delete(`/historical-cost-data/${id}`),
};

export const costCalculationService = {
  runAllocation: (periodData: any) => api.post('/cost-calculation/allocate', periodData),
  getAllocations: (companyId: number, period: string) => api.get(`/cost-calculation/allocations?company_id=${companyId}&period=${period}`),
};


// Default export containing all services
export default {
  api, // Export the api instance as well
  authService,
  workshopService,
  productionService,
  companyService,
  employeeService,
  departmentService,
  inventoryService,
  // Costing services
  costCenterService,
  fixedCostService,
  variableCostService,
  materialCostService,
  laborCostService,
  operationalCostService,
  costTemplateService,
  productCostService,
  pricingRuleService,
  costAllocationService,
  historicalCostDataService,
  costCalculationService,
};

