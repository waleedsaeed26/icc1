import React from 'react';
import { Box, CssBaseline, ThemeProvider } from '@mui/material';
import { BrowserRouter as Router } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { getAppTheme } from './theme';
import './i18n'; // Import i18n configuration

// Import components (to be created)
import AppLayout from './components/layout/AppLayout';
import AppRoutes from './routes/AppRoutes';

function App() {
  const { i18n } = useTranslation();
  const direction = i18n.dir(); // Get current language direction (rtl or ltr)
  const theme = getAppTheme(direction);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box dir={direction} sx={{ height: '100vh', display: 'flex' }}>
        <Router>
          <AppLayout>
            <AppRoutes />
          </AppLayout>
        </Router>
      </Box>
    </ThemeProvider>
  );
}

export default App;
