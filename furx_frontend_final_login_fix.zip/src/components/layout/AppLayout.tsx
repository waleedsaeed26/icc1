import React from 'react';
import { Box, AppBar, Toolbar, IconButton, Typography, Drawer, List, ListItem, ListItemIcon, ListItemText, Divider, Menu, MenuItem, Avatar, Button, Collapse } from '@mui/material';
import { useTranslation } from 'react-i18next';
import MenuIcon from '@mui/icons-material/Menu';
import DashboardIcon from '@mui/icons-material/Dashboard';
import BusinessIcon from '@mui/icons-material/Business';
import PeopleIcon from '@mui/icons-material/People';
import CategoryIcon from '@mui/icons-material/Category';
import FactoryIcon from '@mui/icons-material/Factory';
import InventoryIcon from '@mui/icons-material/Inventory';
import AssessmentIcon from '@mui/icons-material/Assessment';
import LanguageIcon from '@mui/icons-material/Language';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import CalculateIcon from '@mui/icons-material/Calculate';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';
import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

// Import company logos
import iccLogo from "../../assets/logos/icc logo.jpg";
import furxLogo from '../../assets/logos/FURX LOGO.jpg';
import noahLogo from '../../assets/logos/NOAH LOGO.jpg';
import adamsLogo from '../../assets/logos/ADAM\'S LOGO.png';

const drawerWidth = 240;

interface AppLayoutProps {
  children: React.ReactNode;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const [open, setOpen] = useState(true);
  const [languageMenu, setLanguageMenu] = useState<null | HTMLElement>(null);
  const [companyMenu, setCompanyMenu] = useState<null | HTMLElement>(null);
  const [costPricingOpen, setCostPricingOpen] = useState(false);
  
  // Current company state (default to ICC)
  const [currentCompany, setCurrentCompany] = useState({
    id: 1,
    name: 'ICC',
    logo: iccLogo
  });

  // Company options
  const companies = [
    { id: 1, name: 'ICC', logo: iccLogo },
    { id: 2, name: 'FURX', logo: furxLogo },
    { id: 3, name: 'NOAH', logo: noahLogo },
    { id: 4, name: 'ADAM\'S', logo: adamsLogo }
  ];

  const toggleDrawer = () => {
    setOpen(!open);
  };

  const handleLanguageMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setLanguageMenu(event.currentTarget);
  };

  const handleLanguageMenuClose = () => {
    setLanguageMenu(null);
  };

  const handleCompanyMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setCompanyMenu(event.currentTarget);
  };

  const handleCompanyMenuClose = () => {
    setCompanyMenu(null);
  };

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    handleLanguageMenuClose();
  };

  const changeCompany = (company: typeof companies[0]) => {
    setCurrentCompany(company);
    handleCompanyMenuClose();
  };

  const handleCostPricingClick = () => {
    setCostPricingOpen(!costPricingOpen);
  };

  const menuItems = [
    { text: t('navigation.dashboard'), icon: <DashboardIcon />, path: '/' },
    { text: t('navigation.companies'), icon: <BusinessIcon />, path: '/companies' },
    { text: t('navigation.employees'), icon: <PeopleIcon />, path: '/employees' },
    { text: t('navigation.departments'), icon: <CategoryIcon />, path: '/departments' },
    { text: t('navigation.workshops'), icon: <FactoryIcon />, path: '/workshops' },
    { text: t('navigation.production'), icon: <FactoryIcon />, path: '/production' },
    { text: t('navigation.inventory'), icon: <InventoryIcon />, path: '/inventory' },
    { text: t('navigation.reports'), icon: <AssessmentIcon />, path: '/reports' },
  ];

  const costPricingItems = [
    { text: t('navigation.costCenters'), icon: <AccountBalanceIcon />, path: '/cost-centers' },
    { text: t('navigation.fixedCosts'), icon: <AttachMoneyIcon />, path: '/fixed-costs' },
    { text: t('navigation.variableCosts'), icon: <AttachMoneyIcon />, path: '/variable-costs' },
    { text: t('navigation.materialCosts'), icon: <InventoryIcon />, path: '/material-costs' },
    { text: t('navigation.laborCosts'), icon: <PeopleIcon />, path: '/labor-costs' },
    { text: t('navigation.operationalCosts'), icon: <FactoryIcon />, path: '/operational-costs' },
    { text: t('navigation.costTemplates'), icon: <CalculateIcon />, path: '/cost-templates' },
    { text: t('navigation.productCosts'), icon: <CalculateIcon />, path: '/product-costs' },
    { text: t('navigation.pricingRules'), icon: <LocalOfferIcon />, path: '/pricing-rules' },
  ];

  return (
    <Box sx={{ display: 'flex' }}>
      <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={toggleDrawer}
            sx={{ marginRight: 2 }}
          >
            <MenuIcon />
          </IconButton>
          
          <Button 
            onClick={handleCompanyMenuOpen}
            sx={{ 
              display: 'flex', 
              alignItems: 'center', 
              textTransform: 'none',
              color: 'white'
            }}
          >
            <Avatar 
              src={currentCompany.logo} 
              alt={currentCompany.name}
              sx={{ width: 40, height: 40, marginRight: 1, bgcolor: 'white', p: 0.5 }}
            />
            <Typography variant="h6" noWrap component="div">
              {currentCompany.name}
            </Typography>
          </Button>
          
          <Menu
            anchorEl={companyMenu}
            open={Boolean(companyMenu)}
            onClose={handleCompanyMenuClose}
          >
            {companies.map((company) => (
              <MenuItem key={company.id} onClick={() => changeCompany(company)}>
                <Avatar 
                  src={company.logo} 
                  alt={company.name}
                  sx={{ width: 30, height: 30, marginRight: 1, bgcolor: 'white', p: 0.5 }}
                />
                {company.name}
              </MenuItem>
            ))}
          </Menu>
          
          <Box sx={{ flexGrow: 1 }} />
          
          <IconButton
            color="inherit"
            aria-label="change language"
            onClick={handleLanguageMenuOpen}
          >
            <LanguageIcon />
          </IconButton>
          
          <Menu
            anchorEl={languageMenu}
            open={Boolean(languageMenu)}
            onClose={handleLanguageMenuClose}
          >
            <MenuItem onClick={() => changeLanguage('ar')}>العربية</MenuItem>
            <MenuItem onClick={() => changeLanguage('en')}>English</MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>
      
      <Drawer
        variant="persistent"
        open={open}
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
          },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: 'auto', mt: 2 }}>
          <List>
            {menuItems.map((item) => (
              <ListItem 
                button 
                key={item.text} 
                onClick={() => navigate(item.path)}
                selected={location.pathname === item.path}
              >
                <ListItemIcon>{item.icon}</ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItem>
            ))}
            
            {/* Cost & Pricing Section */}
            <ListItem button onClick={handleCostPricingClick}>
              <ListItemIcon>
                <AttachMoneyIcon />
              </ListItemIcon>
              <ListItemText primary={t('navigation.costPricing')} />
              {costPricingOpen ? <ExpandLess /> : <ExpandMore />}
            </ListItem>
            
            <Collapse in={costPricingOpen} timeout="auto" unmountOnExit>
              <List component="div" disablePadding>
                {costPricingItems.map((item) => (
                  <ListItem 
                    button 
                    key={item.text} 
                    onClick={() => navigate(item.path)}
                    selected={location.pathname === item.path}
                    sx={{ pl: 4 }}
                  >
                    <ListItemIcon>{item.icon}</ListItemIcon>
                    <ListItemText primary={item.text} />
                  </ListItem>
                ))}
              </List>
            </Collapse>
          </List>
          <Divider />
        </Box>
      </Drawer>
      
      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <Toolbar />
        {children}
      </Box>
    </Box>
  );
};

export default AppLayout;
