import React from 'react';
import { Routes, Route } from 'react-router-dom';

// Import pages
import Dashboard from '../pages/Dashboard';
import CompanyList from '../pages/companies/CompanyList';
import EmployeeList from '../pages/employees/EmployeeList';
import DepartmentList from '../pages/departments/DepartmentList';
import WorkshopList from '../pages/workshops/WorkshopList';
import ProductionList from '../pages/production/ProductionList';
import InventoryList from '../pages/inventory/InventoryList';
import ReportList from '../pages/reports/ReportList';
import Login from '../pages/auth/Login';
import NotFound from '../pages/NotFound';

// Import cost pricing pages
import CostCenterList from '../pages/costing/CostCenterList';
import FixedCostList from '../pages/costing/FixedCostList';
import VariableCostList from '../pages/costing/VariableCostList';
import MaterialCostList from '../pages/costing/MaterialCostList';
import LaborCostList from '../pages/costing/LaborCostList';
import OperationalCostList from '../pages/costing/OperationalCostList';
import CostTemplateList from '../pages/costing/CostTemplateList';
import ProductCostList from '../pages/costing/ProductCostList';
import PricingRuleList from '../pages/costing/PricingRuleList';

// Import auth components
import ProtectedRoute from '../components/auth/ProtectedRoute';

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      
      <Route path="/" element={
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      } />
      
      <Route path="/companies" element={
        <ProtectedRoute>
          <CompanyList />
        </ProtectedRoute>
      } />
      
      <Route path="/employees" element={
        <ProtectedRoute>
          <EmployeeList />
        </ProtectedRoute>
      } />
      
      <Route path="/departments" element={
        <ProtectedRoute>
          <DepartmentList />
        </ProtectedRoute>
      } />
      
      <Route path="/workshops" element={
        <ProtectedRoute>
          <WorkshopList />
        </ProtectedRoute>
      } />
      
      <Route path="/production" element={
        <ProtectedRoute>
          <ProductionList />
        </ProtectedRoute>
      } />
      
      <Route path="/inventory" element={
        <ProtectedRoute>
          <InventoryList />
        </ProtectedRoute>
      } />
      
      <Route path="/reports" element={
        <ProtectedRoute>
          <ReportList />
        </ProtectedRoute>
      } />
      
      {/* Cost Pricing Routes */}
      <Route path="/cost-centers" element={
        <ProtectedRoute>
          <CostCenterList />
        </ProtectedRoute>
      } />
      
      <Route path="/fixed-costs" element={
        <ProtectedRoute>
          <FixedCostList />
        </ProtectedRoute>
      } />
      
      <Route path="/variable-costs" element={
        <ProtectedRoute>
          <VariableCostList />
        </ProtectedRoute>
      } />
      
      <Route path="/material-costs" element={
        <ProtectedRoute>
          <MaterialCostList />
        </ProtectedRoute>
      } />
      
      <Route path="/labor-costs" element={
        <ProtectedRoute>
          <LaborCostList />
        </ProtectedRoute>
      } />
      
      <Route path="/operational-costs" element={
        <ProtectedRoute>
          <OperationalCostList />
        </ProtectedRoute>
      } />
      
      <Route path="/cost-templates" element={
        <ProtectedRoute>
          <CostTemplateList />
        </ProtectedRoute>
      } />
      
      <Route path="/product-costs" element={
        <ProtectedRoute>
          <ProductCostList />
        </ProtectedRoute>
      } />
      
      <Route path="/pricing-rules" element={
        <ProtectedRoute>
          <PricingRuleList />
        </ProtectedRoute>
      } />
      
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default AppRoutes;
