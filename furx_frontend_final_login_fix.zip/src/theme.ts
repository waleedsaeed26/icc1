import { createTheme } from "@mui/material/styles";
import { arEG, enUS } from "@mui/material/locale";

// Define your base theme options
const baseThemeOptions = {
  typography: {
    fontFamily: ["Cairo", "Roboto", "Helvetica Neue", "Arial", "sans-serif"].join(","),
  },
  // Add other base theme configurations like palette, components overrides etc.
  palette: {
    primary: {
      main: "#1976d2", // Example primary color
    },
    secondary: {
      main: "#dc004e", // Example secondary color
    },
  },
};

// Create themes for LTR (English) and RTL (Arabic)
export const theme_ltr = createTheme({
  ...baseThemeOptions,
  direction: "ltr",
}, enUS);

export const theme_rtl = createTheme({
  ...baseThemeOptions,
  direction: "rtl",
}, arEG);

// Function to get the theme based on language direction
export const getAppTheme = (direction: 'rtl' | 'ltr') => {
  return direction === "rtl" ? theme_rtl : theme_ltr;
};
