import React from 'react';
import { Typography, Box } from '@mui/material';
import { useTranslation } from 'react-i18next';

const CompanyList: React.FC = () => {
  const { t } = useTranslation();
  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        {t('companies.title')} {/* Assuming 'companies.title' exists in translations */}
      </Typography>
      <Typography variant="body1">
        {t('common.comingSoon')} {/* Assuming 'common.comingSoon' exists */}
      </Typography>
    </Box>
  );
};

export default CompanyList;
