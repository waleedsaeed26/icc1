import React from 'react';
import { Typography, Box } from '@mui/material';
import { useTranslation } from 'react-i18next';

const DepartmentList: React.FC = () => {
  const { t } = useTranslation();
  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        {t('departments.title')} {/* Assuming 'departments.title' exists */}
      </Typography>
      <Typography variant="body1">
        {t('common.comingSoon')}
      </Typography>
    </Box>
  );
};

export default DepartmentList;
