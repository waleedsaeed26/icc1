import React, { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Box, 
  Typography, 
  Paper, 
  Button,
  TextField,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControlLabel,
  Switch,
  IconButton,
  Tooltip,
  Snackbar,
  Alert,
  CircularProgress
} from '@mui/material';
import { DataGrid, GridColDef, GridRowParams } from '@mui/x-data-grid';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@mui/icons-material/Visibility';
import PowerSettingsNewIcon from '@mui/icons-material/PowerSettingsNew';
import { workshopService } from '../../services/api'; // Import the API service

// Interface for Workshop data
interface Workshop {
  id: number;
  name: string;
  production_line: string;
  description: string | null;
  is_active: boolean;
  company_id: number;
}

const WorkshopList: React.FC = () => {
  const { t } = useTranslation();
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [loading, setLoading] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [openDeactivateDialog, setOpenDeactivateDialog] = useState(false);
  const [currentWorkshop, setCurrentWorkshop] = useState<Workshop | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    production_line: '',
    description: '',
    is_active: true,
    company_id: 1 // Assuming default company ID is 1 (ICC) for now
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  // Fetch workshops from API
  const fetchWorkshops = useCallback(async () => {
    setLoading(true);
    try {
      // TODO: Get current company ID dynamically
      const companyId = 1; 
      const response = await workshopService.getAllWorkshops(companyId, false); // Fetch all (active and inactive)
      setWorkshops(response.data);
    } catch (error) {
      console.error("Error fetching workshops:", error);
      setSnackbar({
        open: true,
        message: t('common.error') + ': ' + t('workshops.title'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    fetchWorkshops();
  }, [fetchWorkshops]);

  const handleOpenDialog = (workshop: Workshop | null = null) => {
    if (workshop) {
      setFormData({
        name: workshop.name,
        production_line: workshop.production_line,
        description: workshop.description || '',
        is_active: workshop.is_active,
        company_id: workshop.company_id
      });
      setCurrentWorkshop(workshop);
    } else {
      setFormData({
        name: '',
        production_line: '',
        description: '',
        is_active: true,
        company_id: 1 // Default company ID
      });
      setCurrentWorkshop(null);
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleOpenDeactivateDialog = (workshop: Workshop) => {
    setCurrentWorkshop(workshop);
    setOpenDeactivateDialog(true);
  };

  const handleCloseDeactivateDialog = () => {
    setOpenDeactivateDialog(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, checked, type } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSaveWorkshop = async () => {
    setLoading(true);
    try {
      if (currentWorkshop) {
        // Update existing workshop
        await workshopService.updateWorkshop(currentWorkshop.id, formData);
        setSnackbar({
          open: true,
          message: t('workshops.edit') + ' ' + t('common.success'),
          severity: 'success'
        });
      } else {
        // Add new workshop
        await workshopService.createWorkshop(formData);
        setSnackbar({
          open: true,
          message: t('workshops.add') + ' ' + t('common.success'),
          severity: 'success'
        });
      }
      fetchWorkshops(); // Refresh the list
      handleCloseDialog();
    } catch (error) {
      console.error("Error saving workshop:", error);
      setSnackbar({
        open: true,
        message: t('common.error'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeactivateWorkshop = async () => {
    if (!currentWorkshop) return;
    setLoading(true);
    try {
      await workshopService.deactivateWorkshop(currentWorkshop.id, currentWorkshop.company_id);
      setSnackbar({
        open: true,
        message: t('workshops.deactivate') + ' ' + t('common.success'),
        severity: 'success'
      });
      fetchWorkshops(); // Refresh the list
      handleCloseDeactivateDialog();
    } catch (error) {
      console.error("Error deactivating workshop:", error);
      setSnackbar({
        open: true,
        message: t('common.error'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleActivateWorkshop = async (id: number, companyId: number) => {
    setLoading(true);
    try {
      await workshopService.activateWorkshop(id, companyId);
      setSnackbar({
        open: true,
        message: t('workshops.activate') + ' ' + t('common.success'),
        severity: 'success'
      });
      fetchWorkshops(); // Refresh the list
    } catch (error) {
      console.error("Error activating workshop:", error);
      setSnackbar({
        open: true,
        message: t('common.error'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'ID', width: 70 },
    { field: 'name', headerName: t('workshops.name'), width: 200 },
    { field: 'production_line', headerName: t('workshops.productionLine'), width: 200 },
    { field: 'description', headerName: t('workshops.description'), width: 300 },
    { 
      field: 'is_active', 
      headerName: t('common.status'), 
      width: 120,
      renderCell: (params) => (
        <Box sx={{ 
          bgcolor: params.value ? 'success.main' : 'error.main',
          color: 'white',
          px: 2,
          py: 0.5,
          borderRadius: 1
        }}>
          {params.value ? t('workshops.active') : t('workshops.inactive')}
        </Box>
      )
    },
    {
      field: 'actions',
      headerName: t('common.actions'),
      width: 200,
      sortable: false,
      renderCell: (params: GridRowParams<Workshop>) => (
        <Box>
          <Tooltip title={t('common.view')}>
            <IconButton color="primary">
              <VisibilityIcon />
            </IconButton>
          </Tooltip>
          <Tooltip title={t('common.edit')}>
            <IconButton color="primary" onClick={() => handleOpenDialog(params.row)}>
              <EditIcon />
            </IconButton>
          </Tooltip>
          {params.row.is_active ? (
            <Tooltip title={t('workshops.deactivate')}>
              <IconButton color="error" onClick={() => handleOpenDeactivateDialog(params.row)}>
                <PowerSettingsNewIcon />
              </IconButton>
            </Tooltip>
          ) : (
            <Tooltip title={t('workshops.activate')}>
              <IconButton color="success" onClick={() => handleActivateWorkshop(params.row.id, params.row.company_id)}>
                <PowerSettingsNewIcon />
              </IconButton>
            </Tooltip>
          )}
        </Box>
      )
    }
  ];

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h4" gutterBottom>
          {t('workshops.title')}
        </Typography>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
          disabled={loading}
        >
          {t('workshops.add')}
        </Button>
      </Box>

      <Paper sx={{ height: 400, width: '100%' }}>
        <DataGrid
          rows={workshops}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5, 10, 20]}
          checkboxSelection
          disableSelectionOnClick
          loading={loading}
        />
      </Paper>

      {/* Add/Edit Workshop Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {currentWorkshop ? t('workshops.edit') : t('workshops.add')}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <TextField
                name="name"
                label={t('workshops.name')}
                value={formData.name}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="production_line"
                label={t('workshops.productionLine')}
                value={formData.production_line}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="description"
                label={t('workshops.description')}
                value={formData.description}
                onChange={handleInputChange}
                fullWidth
                multiline
                rows={4}
              />
            </Grid>
            {/* We might not allow changing status directly here, handled by activate/deactivate actions */}
            {/* <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Switch
                    name="is_active"
                    checked={formData.is_active}
                    onChange={handleInputChange}
                    color="primary"
                  />
                }
                label={t('common.status')}
              />
            </Grid> */}
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} disabled={loading}>{t('common.cancel')}</Button>
          <Button onClick={handleSaveWorkshop} variant="contained" color="primary" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : t('common.save')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Deactivate Workshop Confirmation Dialog */}
      <Dialog open={openDeactivateDialog} onClose={handleCloseDeactivateDialog}>
        <DialogTitle>{t('workshops.deactivate')}</DialogTitle>
        <DialogContent>
          <Typography>
            {t('workshops.confirmDeactivate')}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDeactivateDialog} disabled={loading}>{t('common.cancel')}</Button>
          <Button onClick={handleDeactivateWorkshop} variant="contained" color="error" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : t('common.confirm')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity} sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default WorkshopList;
