import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Box, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  Snackbar,
  Alert
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useAuth } from '../../contexts/AuthContext';
import { costCenterService, departmentService, workshopService } from '../../services/api';

interface CostCenter {
  id: number;
  company_id: number;
  center_name: string;
  center_type: string;
  department_id: number | null;
  workshop_id: number | null;
  department_name?: string;
  workshop_name?: string;
  is_active: boolean;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

interface Department {
  id: number;
  department_name: string;
}

interface Workshop {
  id: number;
  workshop_name: string;
}

const CostCenterList: React.FC = () => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingCostCenter, setEditingCostCenter] = useState<CostCenter | null>(null);
  const [formData, setFormData] = useState({
    center_name: '',
    center_type: 'department',
    department_id: '',
    workshop_id: '',
    is_active: true,
    notes: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  useEffect(() => {
    fetchCostCenters();
    fetchDepartments();
    fetchWorkshops();
  }, []);

  const fetchCostCenters = async () => {
    try {
      setLoading(true);
      const response = await costCenterService.getAll(currentUser?.company_id);
      setCostCenters(response.data);
    } catch (error) {
      console.error('Error fetching cost centers:', error);
      setSnackbar({
        open: true,
        message: t('costCenters.fetchError'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };
  const fetchDepartments = async () => {
    try {
      const response = await departmentService.getAllDepartments(currentUser?.company_id);
      setDepartments(response.data);
    } catch (error) {
      console.error("Error fetching departments:", error);
    }
  };
  const fetchWorkshops = async () => {
    try {
      const response = await workshopService.getAllWorkshops(currentUser?.company_id);
      setWorkshops(response.data);
    } catch (error) {
      console.error("Error fetching workshops:", error);
    }
  };

  const handleOpenDialog = (costCenter?: CostCenter) => {
    if (costCenter) {
      setEditingCostCenter(costCenter);
      setFormData({
        center_name: costCenter.center_name,
        center_type: costCenter.center_type,
        department_id: costCenter.department_id?.toString() || '',
        workshop_id: costCenter.workshop_id?.toString() || '',
        is_active: costCenter.is_active,
        notes: costCenter.notes || ''
      });
    } else {
      setEditingCostCenter(null);
      setFormData({
        center_name: '',
        center_type: 'department',
        department_id: '',
        workshop_id: '',
        is_active: true,
        notes: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    if (name) {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const handleSubmit = async () => {
    try {
      const data = {
        ...formData,
        company_id: currentUser?.company_id,
        department_id: formData.center_type === 'department' && formData.department_id ? parseInt(formData.department_id) : null,
        workshop_id: formData.center_type === 'workshop' && formData.workshop_id ? parseInt(formData.workshop_id) : null
      };

      if (editingCostCenter) {
        await costCenterService.update(editingCostCenter.id, data);
        setSnackbar({
          open: true,
          message: t("costCenters.updateSuccess"),
          severity: "success",
        });
      } else {
        await costCenterService.create(data);
        setSnackbar({
          open: true,
          message: t("costCenters.createSuccess"),
          severity: "success",
        });
      }      handleCloseDialog();
      fetchCostCenters();
    } catch (error) {
      console.error('Error saving cost center:', error);
      setSnackbar({
        open: true,
        message: editingCostCenter ? t('costCenters.updateError') : t('costCenters.createError'),
        severity: 'error'
      });
    }
  };  const handleDelete = async (id: number) => {
    if (window.confirm(t("common.confirmDelete"))) {
      try {
        await costCenterService.delete(id);
        fetchCostCenters();
        setSnackbar({
          open: true,
          message: t("costCenters.deleteSuccess"),
          severity: "success",
        });
      } catch (error) {
        console.error("Error deleting cost center:", error);
        setSnackbar({
          open: true,
          message: t("costCenters.deleteError"),
          severity: "error",
        });
      }
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          {t('costCenters.title')}
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          {t('costCenters.addNew')}
        </Button>
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>{t('costCenters.centerName')}</TableCell>
                <TableCell>{t('costCenters.centerType')}</TableCell>
                <TableCell>{t('costCenters.department')}</TableCell>
                <TableCell>{t('costCenters.workshop')}</TableCell>
                <TableCell>{t('common.status')}</TableCell>
                <TableCell>{t('common.notes')}</TableCell>
                <TableCell>{t('common.actions')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={7} align="center">
                    {t('common.loading')}
                  </TableCell>
                </TableRow>
              ) : costCenters.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} align="center">
                    {t('costCenters.noCostCenters')}
                  </TableCell>
                </TableRow>
              ) : (
                costCenters.map((costCenter) => (
                  <TableRow key={costCenter.id}>
                    <TableCell>{costCenter.center_name}</TableCell>
                    <TableCell>
                      {costCenter.center_type === 'department' 
                        ? t('costCenters.typeDepartment') 
                        : t('costCenters.typeWorkshop')}
                    </TableCell>
                    <TableCell>{costCenter.department_name || '-'}</TableCell>
                    <TableCell>{costCenter.workshop_name || '-'}</TableCell>
                    <TableCell>
                      {costCenter.is_active 
                        ? t('common.active') 
                        : t('common.inactive')}
                    </TableCell>
                    <TableCell>{costCenter.notes || '-'}</TableCell>
                    <TableCell>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleOpenDialog(costCenter)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton 
                        color="error" 
                        onClick={() => handleDelete(costCenter.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingCostCenter 
            ? t('costCenters.editCostCenter') 
            : t('costCenters.addCostCenter')}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                name="center_name"
                label={t('costCenters.centerName')}
                value={formData.center_name}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>{t('costCenters.centerType')}</InputLabel>
                <Select
                  name="center_type"
                  value={formData.center_type}
                  onChange={handleInputChange}
                  label={t('costCenters.centerType')}
                >
                  <MenuItem value="department">{t('costCenters.typeDepartment')}</MenuItem>
                  <MenuItem value="workshop">{t('costCenters.typeWorkshop')}</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            {formData.center_type === 'department' && (
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>{t('costCenters.department')}</InputLabel>
                  <Select
                    name="department_id"
                    value={formData.department_id}
                    onChange={handleInputChange}
                    label={t('costCenters.department')}
                  >
                    {departments.map((dept) => (
                      <MenuItem key={dept.id} value={dept.id}>
                        {dept.department_name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            )}
            {formData.center_type === 'workshop' && (
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>{t('costCenters.workshop')}</InputLabel>
                  <Select
                    name="workshop_id"
                    value={formData.workshop_id}
                    onChange={handleInputChange}
                    label={t('costCenters.workshop')}
                  >
                    {workshops.map((workshop) => (
                      <MenuItem key={workshop.id} value={workshop.id}>
                        {workshop.workshop_name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            )}
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>{t('common.status')}</InputLabel>
                <Select
                  name="is_active"
                  value={formData.is_active}
                  onChange={handleInputChange}
                  label={t('common.status')}
                >
                  <MenuItem value={true}>{t('common.active')}</MenuItem>
                  <MenuItem value={false}>{t('common.inactive')}</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="notes"
                label={t('common.notes')}
                value={formData.notes}
                onChange={handleInputChange}
                fullWidth
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>{t('common.cancel')}</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            {t('common.save')}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default CostCenterList;
