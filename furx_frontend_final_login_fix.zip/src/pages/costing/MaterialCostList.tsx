import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Box, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  Snackbar,
  Alert,
  Checkbox,
  FormControlLabel
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';

interface MaterialCost {
  id: number;
  company_id: number;
  material_id: number;
  item_name?: string; // Added for display
  cost_per_unit: number;
  wastage_percentage: number | null;
  last_purchase_date: string | null;
  is_active: boolean;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

interface InventoryItem {
  id: number;
  item_name: string;
  unit_of_measure: string;
}

const MaterialCostList: React.FC = () => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();
  const [materialCosts, setMaterialCosts] = useState<MaterialCost[]>([]);
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingMaterialCost, setEditingMaterialCost] = useState<MaterialCost | null>(null);
  const [formData, setFormData] = useState({
    material_id: '',
    cost_per_unit: '',
    wastage_percentage: '',
    last_purchase_date: '',
    is_active: true,
    notes: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  useEffect(() => {
    fetchMaterialCosts();
    fetchInventoryItems();
  }, []);

  const fetchMaterialCosts = async () => {
    try {
      setLoading(true);
      const response = await api.get('/material-costs', {
        params: { company_id: currentUser?.company_id }
      });
      setMaterialCosts(response.data);
    } catch (error) {
      console.error('Error fetching material costs:', error);
      setSnackbar({
        open: true,
        message: t('materialCosts.fetchError'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchInventoryItems = async () => {
    try {
      const response = await api.get('/inventory/items', {
        params: { company_id: currentUser?.company_id }
      });
      setInventoryItems(response.data);
    } catch (error) {
      console.error('Error fetching inventory items:', error);
    }
  };

  const handleOpenDialog = (materialCost?: MaterialCost) => {
    if (materialCost) {
      setEditingMaterialCost(materialCost);
      setFormData({
        material_id: materialCost.material_id.toString(),
        cost_per_unit: materialCost.cost_per_unit.toString(),
        wastage_percentage: materialCost.wastage_percentage?.toString() || '',
        last_purchase_date: materialCost.last_purchase_date ? new Date(materialCost.last_purchase_date).toISOString().split('T')[0] : '',
        is_active: materialCost.is_active,
        notes: materialCost.notes || ''
      });
    } else {
      setEditingMaterialCost(null);
      setFormData({
        material_id: '',
        cost_per_unit: '',
        wastage_percentage: '',
        last_purchase_date: '',
        is_active: true,
        notes: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    if (name) {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const handleSubmit = async () => {
    try {
      const data = {
        ...formData,
        company_id: currentUser?.company_id,
        material_id: parseInt(formData.material_id),
        cost_per_unit: parseFloat(formData.cost_per_unit),
        wastage_percentage: formData.wastage_percentage ? parseFloat(formData.wastage_percentage) : null,
        last_purchase_date: formData.last_purchase_date || null
      };

      if (editingMaterialCost) {
        await api.put(`/material-costs/${editingMaterialCost.id}`, data);
        setSnackbar({
          open: true,
          message: t('materialCosts.updateSuccess'),
          severity: 'success'
        });
      } else {
        // Use upsert logic (POST request handles this in backend)
        await api.post('/material-costs', data);
        setSnackbar({
          open: true,
          message: t('materialCosts.createSuccess'),
          severity: 'success'
        });
      }

      handleCloseDialog();
      fetchMaterialCosts();
    } catch (error) {
      console.error('Error saving material cost:', error);
      setSnackbar({
        open: true,
        message: editingMaterialCost ? t('materialCosts.updateError') : t('materialCosts.createError'),
        severity: 'error'
      });
    }
  };

  const handleDelete = async (id: number) => {
    if (window.confirm(t('common.confirmDelete'))) {
      try {
        await api.delete(`/material-costs/${id}`);
        fetchMaterialCosts();
        setSnackbar({
          open: true,
          message: t('materialCosts.deleteSuccess'),
          severity: 'success'
        });
      } catch (error) {
        console.error('Error deleting material cost:', error);
        setSnackbar({
          open: true,
          message: t('materialCosts.deleteError'),
          severity: 'error'
        });
      }
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          {t('materialCosts.title')}
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          {t('materialCosts.addNew')}
        </Button>
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>{t('materialCosts.materialName')}</TableCell>
                <TableCell>{t('materialCosts.costPerUnit')}</TableCell>
                <TableCell>{t('materialCosts.wastagePercentage')}</TableCell>
                <TableCell>{t('materialCosts.lastPurchaseDate')}</TableCell>
                <TableCell>{t('common.status')}</TableCell>
                <TableCell>{t('common.actions')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    {t('common.loading')}
                  </TableCell>
                </TableRow>
              ) : materialCosts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    {t('materialCosts.noMaterialCosts')}
                  </TableCell>
                </TableRow>
              ) : (
                materialCosts.map((cost) => (
                  <TableRow key={cost.id}>
                    <TableCell>{cost.item_name || t('common.unknown')}</TableCell>
                    <TableCell>{cost.cost_per_unit.toFixed(2)}</TableCell>
                    <TableCell>{cost.wastage_percentage !== null ? `${cost.wastage_percentage.toFixed(2)}%` : '-'}</TableCell>
                    <TableCell>{cost.last_purchase_date ? new Date(cost.last_purchase_date).toLocaleDateString() : '-'}</TableCell>
                    <TableCell>
                      {cost.is_active 
                        ? t('common.active') 
                        : t('common.inactive')}
                    </TableCell>
                    <TableCell>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleOpenDialog(cost)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton 
                        color="error" 
                        onClick={() => handleDelete(cost.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingMaterialCost 
            ? t('materialCosts.editMaterialCost') 
            : t('materialCosts.addMaterialCost')}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth required>
                <InputLabel>{t('materialCosts.materialName')}</InputLabel>
                <Select
                  name="material_id"
                  value={formData.material_id}
                  onChange={handleInputChange}
                  label={t('materialCosts.materialName')}
                  disabled={!!editingMaterialCost} // Disable if editing
                >
                  {inventoryItems.map((item) => (
                    <MenuItem key={item.id} value={item.id}>
                      {item.item_name} ({item.unit_of_measure})
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="cost_per_unit"
                label={t('materialCosts.costPerUnit')}
                value={formData.cost_per_unit}
                onChange={handleInputChange}
                type="number"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="wastage_percentage"
                label={t('materialCosts.wastagePercentage')}
                value={formData.wastage_percentage}
                onChange={handleInputChange}
                type="number"
                fullWidth
                InputProps={{ endAdornment: '%' }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="last_purchase_date"
                label={t('materialCosts.lastPurchaseDate')}
                value={formData.last_purchase_date}
                onChange={handleInputChange}
                type="date"
                fullWidth
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="is_active"
                    checked={formData.is_active}
                    onChange={handleCheckboxChange}
                  />
                }
                label={t('common.active')}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="notes"
                label={t('common.notes')}
                value={formData.notes}
                onChange={handleInputChange}
                fullWidth
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>{t('common.cancel')}</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            {t('common.save')}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default MaterialCostList;
