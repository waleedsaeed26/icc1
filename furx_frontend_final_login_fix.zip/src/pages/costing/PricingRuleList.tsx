import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Box, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  Snackbar,
  Alert,
  Checkbox,
  FormControlLabel,
  Chip
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import CalculateIcon from '@mui/icons-material/Calculate';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';

interface PricingRule {
  id: number;
  company_id: number;
  rule_name: string;
  product_category: string | null;
  product_id: number | null;
  customer_category: string | null;
  markup_percentage: number;
  discount_percentage: number | null;
  min_profit_margin: number | null;
  priority: number;
  is_active: boolean;
  start_date: string | null;
  end_date: string | null;
  notes: string | null;
  product_name?: string; // Added for display
  created_at: string;
  updated_at: string;
}

interface Product {
  id: number;
  item_name: string;
}

const PricingRuleList: React.FC = () => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();
  const [pricingRules, setPricingRules] = useState<PricingRule[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingPricingRule, setEditingPricingRule] = useState<PricingRule | null>(null);
  const [formData, setFormData] = useState({
    rule_name: '',
    product_category: '',
    product_id: '',
    customer_category: '',
    markup_percentage: '',
    discount_percentage: '',
    min_profit_margin: '',
    priority: '10',
    is_active: true,
    start_date: '',
    end_date: '',
    notes: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  useEffect(() => {
    fetchPricingRules();
    fetchProducts();
  }, []);

  const fetchPricingRules = async () => {
    try {
      setLoading(true);
      const response = await api.get('/pricing-rules', {
        params: { company_id: currentUser?.company_id }
      });
      setPricingRules(response.data);
    } catch (error) {
      console.error('Error fetching pricing rules:', error);
      setSnackbar({
        open: true,
        message: t('pricingRules.fetchError'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchProducts = async () => {
    try {
      // Assuming an endpoint exists to fetch products/production items
      const response = await api.get('/production-items', {
        params: { company_id: currentUser?.company_id }
      });
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const handleOpenDialog = (pricingRule?: PricingRule) => {
    if (pricingRule) {
      setEditingPricingRule(pricingRule);
      setFormData({
        rule_name: pricingRule.rule_name,
        product_category: pricingRule.product_category || '',
        product_id: pricingRule.product_id?.toString() || '',
        customer_category: pricingRule.customer_category || '',
        markup_percentage: pricingRule.markup_percentage.toString(),
        discount_percentage: pricingRule.discount_percentage?.toString() || '',
        min_profit_margin: pricingRule.min_profit_margin?.toString() || '',
        priority: pricingRule.priority.toString(),
        is_active: pricingRule.is_active,
        start_date: pricingRule.start_date ? new Date(pricingRule.start_date).toISOString().split('T')[0] : '',
        end_date: pricingRule.end_date ? new Date(pricingRule.end_date).toISOString().split('T')[0] : '',
        notes: pricingRule.notes || ''
      });
    } else {
      setEditingPricingRule(null);
      setFormData({
        rule_name: '',
        product_category: '',
        product_id: '',
        customer_category: '',
        markup_percentage: '',
        discount_percentage: '',
        min_profit_margin: '',
        priority: '10',
        is_active: true,
        start_date: '',
        end_date: '',
        notes: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    if (name) {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const handleSubmit = async () => {
    try {
      const data = {
        ...formData,
        company_id: currentUser?.company_id,
        product_category: formData.product_category || null,
        product_id: formData.product_id ? parseInt(formData.product_id) : null,
        customer_category: formData.customer_category || null,
        markup_percentage: parseFloat(formData.markup_percentage),
        discount_percentage: formData.discount_percentage ? parseFloat(formData.discount_percentage) : null,
        min_profit_margin: formData.min_profit_margin ? parseFloat(formData.min_profit_margin) : null,
        priority: parseInt(formData.priority),
        start_date: formData.start_date || null,
        end_date: formData.end_date || null
      };

      if (editingPricingRule) {
        await api.put(`/pricing-rules/${editingPricingRule.id}`, data);
        setSnackbar({
          open: true,
          message: t('pricingRules.updateSuccess'),
          severity: 'success'
        });
      } else {
        await api.post('/pricing-rules', data);
        setSnackbar({
          open: true,
          message: t('pricingRules.createSuccess'),
          severity: 'success'
        });
      }

      handleCloseDialog();
      fetchPricingRules();
    } catch (error) {
      console.error('Error saving pricing rule:', error);
      setSnackbar({
        open: true,
        message: editingPricingRule ? t('pricingRules.updateError') : t('pricingRules.createError'),
        severity: 'error'
      });
    }
  };

  const handleDelete = async (id: number) => {
    if (window.confirm(t('common.confirmDelete'))) {
      try {
        await api.delete(`/pricing-rules/${id}`);
        fetchPricingRules();
        setSnackbar({
          open: true,
          message: t('pricingRules.deleteSuccess'),
          severity: 'success'
        });
      } catch (error) {
        console.error('Error deleting pricing rule:', error);
        setSnackbar({
          open: true,
          message: t('pricingRules.deleteError'),
          severity: 'error'
        });
      }
    }
  };

  const handleCalculatePrice = async (productId: number) => {
    try {
      const response = await api.post(`/pricing-rules/calculate/${productId}`, {
        company_id: currentUser?.company_id,
        customer_category: 'retail' // Default to retail, could be made selectable
      });
      
      setSnackbar({
        open: true,
        message: t('pricingRules.calculatedPrice', { 
          price: response.data.calculated_price.toFixed(2) 
        }),
        severity: 'success'
      });
    } catch (error) {
      console.error('Error calculating price:', error);
      setSnackbar({
        open: true,
        message: t('pricingRules.calculateError'),
        severity: 'error'
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          {t('pricingRules.title')}
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          {t('pricingRules.addNew')}
        </Button>
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>{t('pricingRules.ruleName')}</TableCell>
                <TableCell>{t('pricingRules.applicability')}</TableCell>
                <TableCell align="right">{t('pricingRules.markup')}</TableCell>
                <TableCell align="right">{t('pricingRules.discount')}</TableCell>
                <TableCell align="right">{t('pricingRules.minProfitMargin')}</TableCell>
                <TableCell align="center">{t('pricingRules.priority')}</TableCell>
                <TableCell>{t('common.status')}</TableCell>
                <TableCell>{t('common.actions')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={8} align="center">
                    {t('common.loading')}
                  </TableCell>
                </TableRow>
              ) : pricingRules.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} align="center">
                    {t('pricingRules.noPricingRules')}
                  </TableCell>
                </TableRow>
              ) : (
                pricingRules.map((rule) => (
                  <TableRow key={rule.id}>
                    <TableCell>{rule.rule_name}</TableCell>
                    <TableCell>
                      {rule.product_id ? (
                        <Chip 
                          label={rule.product_name || `ID: ${rule.product_id}`} 
                          size="small" 
                          color="primary" 
                          variant="outlined"
                          sx={{ mr: 0.5 }}
                        />
                      ) : rule.product_category ? (
                        <Chip 
                          label={rule.product_category} 
                          size="small" 
                          color="secondary" 
                          variant="outlined"
                          sx={{ mr: 0.5 }}
                        />
                      ) : null}
                      
                      {rule.customer_category && (
                        <Chip 
                          label={rule.customer_category} 
                          size="small" 
                          color="info" 
                          variant="outlined"
                        />
                      )}
                      
                      {!rule.product_id && !rule.product_category && !rule.customer_category && (
                        <Typography variant="body2" color="textSecondary">
                          {t('pricingRules.globalRule')}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell align="right">{rule.markup_percentage}%</TableCell>
                    <TableCell align="right">{rule.discount_percentage !== null ? `${rule.discount_percentage}%` : '-'}</TableCell>
                    <TableCell align="right">{rule.min_profit_margin !== null ? `${rule.min_profit_margin}%` : '-'}</TableCell>
                    <TableCell align="center">{rule.priority}</TableCell>
                    <TableCell>
                      {rule.is_active 
                        ? t('common.active') 
                        : t('common.inactive')}
                    </TableCell>
                    <TableCell>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleOpenDialog(rule)}
                        title={t('common.edit')}
                      >
                        <EditIcon />
                      </IconButton>
                      {rule.product_id && (
                        <IconButton 
                          color="primary" 
                          onClick={() => handleCalculatePrice(rule.product_id!)}
                          title={t('pricingRules.calculatePrice')}
                        >
                          <CalculateIcon />
                        </IconButton>
                      )}
                      <IconButton 
                        color="error" 
                        onClick={() => handleDelete(rule.id)}
                        title={t('common.delete')}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingPricingRule 
            ? t('pricingRules.editPricingRule') 
            : t('pricingRules.addPricingRule')}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                name="rule_name"
                label={t('pricingRules.ruleName')}
                value={formData.rule_name}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="product_category"
                label={t('pricingRules.productCategory')}
                value={formData.product_category}
                onChange={handleInputChange}
                fullWidth
                helperText={t('pricingRules.leaveEmptyForAll')}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>{t('pricingRules.specificProduct')}</InputLabel>
                <Select
                  name="product_id"
                  value={formData.product_id}
                  onChange={handleInputChange}
                  label={t('pricingRules.specificProduct')}
                >
                  <MenuItem value=""><em>{t('pricingRules.leaveEmptyForAll')}</em></MenuItem>
                  {products.map((product) => (
                    <MenuItem key={product.id} value={product.id}>
                      {product.item_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="customer_category"
                label={t('pricingRules.customerCategory')}
                value={formData.customer_category}
                onChange={handleInputChange}
                fullWidth
                helperText={t('pricingRules.leaveEmptyForAll')}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="markup_percentage"
                label={t('pricingRules.markupPercentage')}
                value={formData.markup_percentage}
                onChange={handleInputChange}
                type="number"
                fullWidth
                required
                InputProps={{ endAdornment: '%' }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="discount_percentage"
                label={t('pricingRules.discountPercentage')}
                value={formData.discount_percentage}
                onChange={handleInputChange}
                type="number"
                fullWidth
                InputProps={{ endAdornment: '%' }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="min_profit_margin"
                label={t('pricingRules.minProfitMargin')}
                value={formData.min_profit_margin}
                onChange={handleInputChange}
                type="number"
                fullWidth
                InputProps={{ endAdornment: '%' }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="priority"
                label={t('pricingRules.priority')}
                value={formData.priority}
                onChange={handleInputChange}
                type="number"
                fullWidth
                required
                helperText={t('pricingRules.priorityHelp')}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="start_date"
                label={t('pricingRules.startDate')}
                value={formData.start_date}
                onChange={handleInputChange}
                type="date"
                fullWidth
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="end_date"
                label={t('pricingRules.endDate')}
                value={formData.end_date}
                onChange={handleInputChange}
                type="date"
                fullWidth
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="is_active"
                    checked={formData.is_active}
                    onChange={handleCheckboxChange}
                  />
                }
                label={t('common.active')}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="notes"
                label={t('common.notes')}
                value={formData.notes}
                onChange={handleInputChange}
                fullWidth
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>{t('common.cancel')}</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            {t('common.save')}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default PricingRuleList;
