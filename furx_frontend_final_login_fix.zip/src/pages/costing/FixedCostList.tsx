import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Box, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  Snackbar,
  Alert,
  Checkbox,
  FormControlLabel
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';

interface FixedCost {
  id: number;
  company_id: number;
  cost_name: string;
  cost_category: string;
  amount: number;
  frequency: string;
  allocation_method: string;
  allocation_basis: string | null;
  start_date: string;
  end_date: string | null;
  is_active: boolean;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

const FixedCostList: React.FC = () => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();
  const [fixedCosts, setFixedCosts] = useState<FixedCost[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingFixedCost, setEditingFixedCost] = useState<FixedCost | null>(null);
  const [formData, setFormData] = useState({
    cost_name: '',
    cost_category: '',
    amount: '',
    frequency: 'monthly',
    allocation_method: 'direct',
    allocation_basis: '',
    start_date: new Date().toISOString().split('T')[0], // Default to today
    end_date: '',
    is_active: true,
    notes: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  useEffect(() => {
    fetchFixedCosts();
  }, []);

  const fetchFixedCosts = async () => {
    try {
      setLoading(true);
      const response = await api.get('/fixed-costs', {
        params: { company_id: currentUser?.company_id }
      });
      setFixedCosts(response.data);
    } catch (error) {
      console.error('Error fetching fixed costs:', error);
      setSnackbar({
        open: true,
        message: t('fixedCosts.fetchError'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (fixedCost?: FixedCost) => {
    if (fixedCost) {
      setEditingFixedCost(fixedCost);
      setFormData({
        cost_name: fixedCost.cost_name,
        cost_category: fixedCost.cost_category,
        amount: fixedCost.amount.toString(),
        frequency: fixedCost.frequency,
        allocation_method: fixedCost.allocation_method,
        allocation_basis: fixedCost.allocation_basis || '',
        start_date: fixedCost.start_date ? new Date(fixedCost.start_date).toISOString().split('T')[0] : '',
        end_date: fixedCost.end_date ? new Date(fixedCost.end_date).toISOString().split('T')[0] : '',
        is_active: fixedCost.is_active,
        notes: fixedCost.notes || ''
      });
    } else {
      setEditingFixedCost(null);
      setFormData({
        cost_name: '',
        cost_category: '',
        amount: '',
        frequency: 'monthly',
        allocation_method: 'direct',
        allocation_basis: '',
        start_date: new Date().toISOString().split('T')[0],
        end_date: '',
        is_active: true,
        notes: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    if (name) {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const handleSubmit = async () => {
    try {
      const data = {
        ...formData,
        company_id: currentUser?.company_id,
        amount: parseFloat(formData.amount),
        end_date: formData.end_date || null // Send null if empty
      };

      if (editingFixedCost) {
        await api.put(`/fixed-costs/${editingFixedCost.id}`, data);
        setSnackbar({
          open: true,
          message: t('fixedCosts.updateSuccess'),
          severity: 'success'
        });
      } else {
        await api.post('/fixed-costs', data);
        setSnackbar({
          open: true,
          message: t('fixedCosts.createSuccess'),
          severity: 'success'
        });
      }

      handleCloseDialog();
      fetchFixedCosts();
    } catch (error) {
      console.error('Error saving fixed cost:', error);
      setSnackbar({
        open: true,
        message: editingFixedCost ? t('fixedCosts.updateError') : t('fixedCosts.createError'),
        severity: 'error'
      });
    }
  };

  const handleDelete = async (id: number) => {
    if (window.confirm(t('common.confirmDelete'))) {
      try {
        await api.delete(`/fixed-costs/${id}`);
        fetchFixedCosts();
        setSnackbar({
          open: true,
          message: t('fixedCosts.deleteSuccess'),
          severity: 'success'
        });
      } catch (error) {
        console.error('Error deleting fixed cost:', error);
        setSnackbar({
          open: true,
          message: t('fixedCosts.deleteError'),
          severity: 'error'
        });
      }
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          {t('fixedCosts.title')}
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          {t('fixedCosts.addNew')}
        </Button>
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>{t('fixedCosts.costName')}</TableCell>
                <TableCell>{t('fixedCosts.category')}</TableCell>
                <TableCell>{t('fixedCosts.amount')}</TableCell>
                <TableCell>{t('fixedCosts.frequency')}</TableCell>
                <TableCell>{t('fixedCosts.allocationMethod')}</TableCell>
                <TableCell>{t('fixedCosts.startDate')}</TableCell>
                <TableCell>{t('fixedCosts.endDate')}</TableCell>
                <TableCell>{t('common.status')}</TableCell>
                <TableCell>{t('common.actions')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={9} align="center">
                    {t('common.loading')}
                  </TableCell>
                </TableRow>
              ) : fixedCosts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} align="center">
                    {t('fixedCosts.noFixedCosts')}
                  </TableCell>
                </TableRow>
              ) : (
                fixedCosts.map((cost) => (
                  <TableRow key={cost.id}>
                    <TableCell>{cost.cost_name}</TableCell>
                    <TableCell>{cost.cost_category}</TableCell>
                    <TableCell>{cost.amount.toFixed(2)}</TableCell>
                    <TableCell>{t(`fixedCosts.frequency_${cost.frequency}`)}</TableCell>
                    <TableCell>{t(`fixedCosts.allocation_${cost.allocation_method}`)}</TableCell>
                    <TableCell>{cost.start_date ? new Date(cost.start_date).toLocaleDateString() : '-'}</TableCell>
                    <TableCell>{cost.end_date ? new Date(cost.end_date).toLocaleDateString() : '-'}</TableCell>
                    <TableCell>
                      {cost.is_active 
                        ? t('common.active') 
                        : t('common.inactive')}
                    </TableCell>
                    <TableCell>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleOpenDialog(cost)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton 
                        color="error" 
                        onClick={() => handleDelete(cost.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingFixedCost 
            ? t('fixedCosts.editFixedCost') 
            : t('fixedCosts.addFixedCost')}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} sm={6}>
              <TextField
                name="cost_name"
                label={t('fixedCosts.costName')}
                value={formData.cost_name}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="cost_category"
                label={t('fixedCosts.category')}
                value={formData.cost_category}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="amount"
                label={t('fixedCosts.amount')}
                value={formData.amount}
                onChange={handleInputChange}
                type="number"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>{t('fixedCosts.frequency')}</InputLabel>
                <Select
                  name="frequency"
                  value={formData.frequency}
                  onChange={handleInputChange}
                  label={t('fixedCosts.frequency')}
                >
                  <MenuItem value="monthly">{t('fixedCosts.frequency_monthly')}</MenuItem>
                  <MenuItem value="quarterly">{t('fixedCosts.frequency_quarterly')}</MenuItem>
                  <MenuItem value="annually">{t('fixedCosts.frequency_annually')}</MenuItem>
                  <MenuItem value="one_time">{t('fixedCosts.frequency_one_time')}</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>{t('fixedCosts.allocationMethod')}</InputLabel>
                <Select
                  name="allocation_method"
                  value={formData.allocation_method}
                  onChange={handleInputChange}
                  label={t('fixedCosts.allocationMethod')}
                >
                  <MenuItem value="direct">{t('fixedCosts.allocation_direct')}</MenuItem>
                  <MenuItem value="percentage">{t('fixedCosts.allocation_percentage')}</MenuItem>
                  <MenuItem value="activity_based">{t('fixedCosts.allocation_activity_based')}</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="allocation_basis"
                label={t('fixedCosts.allocationBasis')}
                value={formData.allocation_basis}
                onChange={handleInputChange}
                fullWidth
                helperText={t('fixedCosts.allocationBasisHelper')}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="start_date"
                label={t('fixedCosts.startDate')}
                value={formData.start_date}
                onChange={handleInputChange}
                type="date"
                fullWidth
                required
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="end_date"
                label={t('fixedCosts.endDate')}
                value={formData.end_date}
                onChange={handleInputChange}
                type="date"
                fullWidth
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="is_active"
                    checked={formData.is_active}
                    onChange={handleCheckboxChange}
                  />
                }
                label={t('common.active')}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="notes"
                label={t('common.notes')}
                value={formData.notes}
                onChange={handleInputChange}
                fullWidth
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>{t('common.cancel')}</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            {t('common.save')}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default FixedCostList;
