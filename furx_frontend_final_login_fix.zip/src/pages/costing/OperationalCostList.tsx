import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Box, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  Snackbar,
  Alert,
  Checkbox,
  FormControlLabel
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';

interface OperationalCost {
  id: number;
  company_id: number;
  cost_center_id: number | null;
  cost_name: string;
  cost_category: string;
  amount: number;
  frequency: string;
  start_date: string;
  end_date: string | null;
  is_active: boolean;
  notes: string | null;
  cost_center_name?: string; // Added for display
  created_at: string;
  updated_at: string;
}

interface CostCenter {
  id: number;
  center_name: string;
}

const OperationalCostList: React.FC = () => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();
  const [operationalCosts, setOperationalCosts] = useState<OperationalCost[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingOperationalCost, setEditingOperationalCost] = useState<OperationalCost | null>(null);
  const [formData, setFormData] = useState({
    cost_center_id: '',
    cost_name: '',
    cost_category: '',
    amount: '',
    frequency: 'monthly',
    start_date: new Date().toISOString().split('T')[0],
    end_date: '',
    is_active: true,
    notes: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  useEffect(() => {
    fetchOperationalCosts();
    fetchCostCenters();
  }, []);

  const fetchOperationalCosts = async () => {
    try {
      setLoading(true);
      const response = await api.get('/operational-costs', {
        params: { company_id: currentUser?.company_id }
      });
      setOperationalCosts(response.data);
    } catch (error) {
      console.error('Error fetching operational costs:', error);
      setSnackbar({
        open: true,
        message: t('operationalCosts.fetchError'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCostCenters = async () => {
    try {
      const response = await api.get('/cost-centers', {
        params: { company_id: currentUser?.company_id }
      });
      setCostCenters(response.data);
    } catch (error) {
      console.error('Error fetching cost centers:', error);
    }
  };

  const handleOpenDialog = (operationalCost?: OperationalCost) => {
    if (operationalCost) {
      setEditingOperationalCost(operationalCost);
      setFormData({
        cost_center_id: operationalCost.cost_center_id?.toString() || '',
        cost_name: operationalCost.cost_name,
        cost_category: operationalCost.cost_category,
        amount: operationalCost.amount.toString(),
        frequency: operationalCost.frequency,
        start_date: operationalCost.start_date ? new Date(operationalCost.start_date).toISOString().split('T')[0] : '',
        end_date: operationalCost.end_date ? new Date(operationalCost.end_date).toISOString().split('T')[0] : '',
        is_active: operationalCost.is_active,
        notes: operationalCost.notes || ''
      });
    } else {
      setEditingOperationalCost(null);
      setFormData({
        cost_center_id: '',
        cost_name: '',
        cost_category: '',
        amount: '',
        frequency: 'monthly',
        start_date: new Date().toISOString().split('T')[0],
        end_date: '',
        is_active: true,
        notes: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    if (name) {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const handleSubmit = async () => {
    try {
      const data = {
        ...formData,
        company_id: currentUser?.company_id,
        cost_center_id: formData.cost_center_id ? parseInt(formData.cost_center_id) : null,
        amount: parseFloat(formData.amount),
        end_date: formData.end_date || null
      };

      if (editingOperationalCost) {
        await api.put(`/operational-costs/${editingOperationalCost.id}`, data);
        setSnackbar({
          open: true,
          message: t('operationalCosts.updateSuccess'),
          severity: 'success'
        });
      } else {
        await api.post('/operational-costs', data);
        setSnackbar({
          open: true,
          message: t('operationalCosts.createSuccess'),
          severity: 'success'
        });
      }

      handleCloseDialog();
      fetchOperationalCosts();
    } catch (error) {
      console.error('Error saving operational cost:', error);
      setSnackbar({
        open: true,
        message: editingOperationalCost ? t('operationalCosts.updateError') : t('operationalCosts.createError'),
        severity: 'error'
      });
    }
  };

  const handleDelete = async (id: number) => {
    if (window.confirm(t('common.confirmDelete'))) {
      try {
        await api.delete(`/operational-costs/${id}`);
        fetchOperationalCosts();
        setSnackbar({
          open: true,
          message: t('operationalCosts.deleteSuccess'),
          severity: 'success'
        });
      } catch (error) {
        console.error('Error deleting operational cost:', error);
        setSnackbar({
          open: true,
          message: t('operationalCosts.deleteError'),
          severity: 'error'
        });
      }
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          {t('operationalCosts.title')}
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          {t('operationalCosts.addNew')}
        </Button>
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>{t('operationalCosts.costName')}</TableCell>
                <TableCell>{t('operationalCosts.category')}</TableCell>
                <TableCell>{t('operationalCosts.amount')}</TableCell>
                <TableCell>{t('operationalCosts.frequency')}</TableCell>
                <TableCell>{t('operationalCosts.costCenter')}</TableCell>
                <TableCell>{t('operationalCosts.startDate')}</TableCell>
                <TableCell>{t('operationalCosts.endDate')}</TableCell>
                <TableCell>{t('common.status')}</TableCell>
                <TableCell>{t('common.actions')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={9} align="center">
                    {t('common.loading')}
                  </TableCell>
                </TableRow>
              ) : operationalCosts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} align="center">
                    {t('operationalCosts.noOperationalCosts')}
                  </TableCell>
                </TableRow>
              ) : (
                operationalCosts.map((cost) => (
                  <TableRow key={cost.id}>
                    <TableCell>{cost.cost_name}</TableCell>
                    <TableCell>{cost.cost_category}</TableCell>
                    <TableCell>{cost.amount.toFixed(2)}</TableCell>
                    <TableCell>{t(`operationalCosts.frequency_${cost.frequency}`)}</TableCell>
                    <TableCell>{cost.cost_center_name || t('common.general')}</TableCell>
                    <TableCell>{cost.start_date ? new Date(cost.start_date).toLocaleDateString() : '-'}</TableCell>
                    <TableCell>{cost.end_date ? new Date(cost.end_date).toLocaleDateString() : '-'}</TableCell>
                    <TableCell>
                      {cost.is_active 
                        ? t('common.active') 
                        : t('common.inactive')}
                    </TableCell>
                    <TableCell>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleOpenDialog(cost)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton 
                        color="error" 
                        onClick={() => handleDelete(cost.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingOperationalCost 
            ? t('operationalCosts.editOperationalCost') 
            : t('operationalCosts.addOperationalCost')}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} sm={6}>
              <TextField
                name="cost_name"
                label={t('operationalCosts.costName')}
                value={formData.cost_name}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="cost_category"
                label={t('operationalCosts.category')}
                value={formData.cost_category}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="amount"
                label={t('operationalCosts.amount')}
                value={formData.amount}
                onChange={handleInputChange}
                type="number"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>{t('operationalCosts.frequency')}</InputLabel>
                <Select
                  name="frequency"
                  value={formData.frequency}
                  onChange={handleInputChange}
                  label={t('operationalCosts.frequency')}
                >
                  <MenuItem value="monthly">{t('operationalCosts.frequency_monthly')}</MenuItem>
                  <MenuItem value="quarterly">{t('operationalCosts.frequency_quarterly')}</MenuItem>
                  <MenuItem value="annually">{t('operationalCosts.frequency_annually')}</MenuItem>
                  <MenuItem value="one_time">{t('operationalCosts.frequency_one_time')}</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>{t('operationalCosts.costCenter')}</InputLabel>
                <Select
                  name="cost_center_id"
                  value={formData.cost_center_id}
                  onChange={handleInputChange}
                  label={t('operationalCosts.costCenter')}
                >
                  <MenuItem value=""><em>{t('common.general')}</em></MenuItem>
                  {costCenters.map((center) => (
                    <MenuItem key={center.id} value={center.id}>
                      {center.center_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="start_date"
                label={t('operationalCosts.startDate')}
                value={formData.start_date}
                onChange={handleInputChange}
                type="date"
                fullWidth
                required
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="end_date"
                label={t('operationalCosts.endDate')}
                value={formData.end_date}
                onChange={handleInputChange}
                type="date"
                fullWidth
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="is_active"
                    checked={formData.is_active}
                    onChange={handleCheckboxChange}
                  />
                }
                label={t('common.active')}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="notes"
                label={t('common.notes')}
                value={formData.notes}
                onChange={handleInputChange}
                fullWidth
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>{t('common.cancel')}</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            {t('common.save')}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default OperationalCostList;
