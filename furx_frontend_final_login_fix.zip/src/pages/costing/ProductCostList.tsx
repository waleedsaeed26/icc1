import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Box, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  Snackbar,
  Alert,
  CircularProgress,
  Accordion,
  AccordionSummary,
  AccordionDetails
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import RefreshIcon from '@mui/icons-material/Refresh';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';

interface ProductCost {
  id: number;
  company_id: number;
  product_id: number;
  item_name?: string; // Added for display
  total_material_cost: number;
  total_labor_cost: number;
  total_operational_cost: number;
  total_overhead_cost: number;
  total_cost: number;
  calculation_date: string;
  cost_template_id: number | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

interface ProductCostComponent {
  component_type: string;
  component_name: string;
  cost_category: string;
  quantity: number;
  unit_cost: number;
  total_cost: number;
  wastage_percentage: number | null;
}

interface Product {
  id: number;
  item_name: string;
}

const ProductCostList: React.FC = () => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();
  const [productCosts, setProductCosts] = useState<ProductCost[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [calculating, setCalculating] = useState(false);
  const [openDetailsDialog, setOpenDetailsDialog] = useState(false);
  const [selectedProductCost, setSelectedProductCost] = useState<ProductCost | null>(null);
  const [costComponents, setCostComponents] = useState<ProductCostComponent[]>([]);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  useEffect(() => {
    fetchProductCosts();
    fetchProducts();
  }, []);

  const fetchProductCosts = async () => {
    try {
      setLoading(true);
      const response = await api.get('/product-costs', {
        params: { company_id: currentUser?.company_id }
      });
      setProductCosts(response.data);
    } catch (error) {
      console.error('Error fetching product costs:', error);
      setSnackbar({
        open: true,
        message: t('productCosts.fetchError'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchProducts = async () => {
    try {
      // Assuming an endpoint exists to fetch products/production items
      const response = await api.get('/production-items', {
        params: { company_id: currentUser?.company_id }
      });
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const handleCalculateCost = async (productId: number) => {
    setCalculating(true);
    try {
      await api.post(`/product-costs/calculate/${productId}`, { 
        company_id: currentUser?.company_id 
      });
      setSnackbar({
        open: true,
        message: t('productCosts.calculateSuccess'),
        severity: 'success'
      });
      fetchProductCosts(); // Refresh the list
    } catch (error) {
      console.error('Error calculating product cost:', error);
      setSnackbar({
        open: true,
        message: t('productCosts.calculateError'),
        severity: 'error'
      });
    } finally {
      setCalculating(false);
    }
  };

  const handleViewDetails = async (productCost: ProductCost) => {
    setSelectedProductCost(productCost);
    try {
      const response = await api.get(`/product-costs/${productCost.id}/components`);
      setCostComponents(response.data);
      setOpenDetailsDialog(true);
    } catch (error) {
      console.error('Error fetching cost components:', error);
      setSnackbar({
        open: true,
        message: t('productCosts.fetchComponentsError'),
        severity: 'error'
      });
    }
  };

  const handleCloseDetailsDialog = () => {
    setOpenDetailsDialog(false);
    setSelectedProductCost(null);
    setCostComponents([]);
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          {t('productCosts.title')}
        </Typography>
        {/* Optional: Add button to trigger calculation for all or selected products */}
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>{t('productCosts.productName')}</TableCell>
                <TableCell align="right">{t('productCosts.totalMaterialCost')}</TableCell>
                <TableCell align="right">{t('productCosts.totalLaborCost')}</TableCell>
                <TableCell align="right">{t('productCosts.totalOperationalCost')}</TableCell>
                <TableCell align="right">{t('productCosts.totalOverheadCost')}</TableCell>
                <TableCell align="right">{t('productCosts.totalCost')}</TableCell>
                <TableCell>{t('productCosts.calculationDate')}</TableCell>
                <TableCell>{t('common.actions')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={8} align="center">
                    <CircularProgress />
                  </TableCell>
                </TableRow>
              ) : productCosts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} align="center">
                    {t('productCosts.noProductCosts')}
                  </TableCell>
                </TableRow>
              ) : (
                productCosts.map((cost) => (
                  <TableRow key={cost.id}>
                    <TableCell>{cost.item_name || t('common.unknown')}</TableCell>
                    <TableCell align="right">{cost.total_material_cost.toFixed(2)}</TableCell>
                    <TableCell align="right">{cost.total_labor_cost.toFixed(2)}</TableCell>
                    <TableCell align="right">{cost.total_operational_cost.toFixed(2)}</TableCell>
                    <TableCell align="right">{cost.total_overhead_cost.toFixed(2)}</TableCell>
                    <TableCell align="right"><strong>{cost.total_cost.toFixed(2)}</strong></TableCell>
                    <TableCell>{cost.calculation_date ? new Date(cost.calculation_date).toLocaleString() : '-'}</TableCell>
                    <TableCell>
                      <Button 
                        variant="outlined" 
                        size="small" 
                        onClick={() => handleViewDetails(cost)}
                        sx={{ mr: 1 }}
                      >
                        {t('common.details')}
                      </Button>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleCalculateCost(cost.product_id)}
                        disabled={calculating}
                        title={t('productCosts.recalculate')}
                      >
                        {calculating ? <CircularProgress size={20} /> : <RefreshIcon />}
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Details Dialog */}
      <Dialog open={openDetailsDialog} onClose={handleCloseDetailsDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {t('productCosts.costDetailsTitle', { productName: selectedProductCost?.item_name || '' })}
        </DialogTitle>
        <DialogContent>
          {selectedProductCost && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="h6" gutterBottom>{t('productCosts.summary')}</Typography>
              <Grid container spacing={1} sx={{ mb: 2 }}>
                <Grid item xs={6} sm={3}>{t('productCosts.totalMaterialCost')}:</Grid>
                <Grid item xs={6} sm={9}>{selectedProductCost.total_material_cost.toFixed(2)}</Grid>
                <Grid item xs={6} sm={3}>{t('productCosts.totalLaborCost')}:</Grid>
                <Grid item xs={6} sm={9}>{selectedProductCost.total_labor_cost.toFixed(2)}</Grid>
                <Grid item xs={6} sm={3}>{t('productCosts.totalOperationalCost')}:</Grid>
                <Grid item xs={6} sm={9}>{selectedProductCost.total_operational_cost.toFixed(2)}</Grid>
                <Grid item xs={6} sm={3}>{t('productCosts.totalOverheadCost')}:</Grid>
                <Grid item xs={6} sm={9}>{selectedProductCost.total_overhead_cost.toFixed(2)}</Grid>
                <Grid item xs={6} sm={3}><strong>{t('productCosts.totalCost')}:</strong></Grid>
                <Grid item xs={6} sm={9}><strong>{selectedProductCost.total_cost.toFixed(2)}</strong></Grid>
                <Grid item xs={6} sm={3}>{t('productCosts.calculationDate')}:</Grid>
                <Grid item xs={6} sm={9}>{selectedProductCost.calculation_date ? new Date(selectedProductCost.calculation_date).toLocaleString() : '-'}</Grid>
              </Grid>

              <Typography variant="h6" gutterBottom>{t('productCosts.components')}</Typography>
              {costComponents.length === 0 ? (
                <Typography>{t('productCosts.noComponentsData')}</Typography>
              ) : (
                costComponents.map((component, index) => (
                  <Accordion key={index}>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                      <Typography sx={{ width: '33%', flexShrink: 0 }}>
                        {t(`costTemplates.type_${component.component_type}`)}
                      </Typography>
                      <Typography sx={{ color: 'text.secondary' }}>{component.component_name}</Typography>
                      <Typography sx={{ ml: 'auto', fontWeight: 'bold' }}>{component.total_cost.toFixed(2)}</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Grid container spacing={1}>
                        <Grid item xs={6} sm={3}>{t('costTemplates.category')}:</Grid>
                        <Grid item xs={6} sm={9}>{component.cost_category}</Grid>
                        <Grid item xs={6} sm={3}>{t('costTemplates.quantity')}:</Grid>
                        <Grid item xs={6} sm={9}>{component.quantity}</Grid>
                        <Grid item xs={6} sm={3}>{t('costTemplates.unitCost')}:</Grid>
                        <Grid item xs={6} sm={9}>{component.unit_cost.toFixed(2)}</Grid>
                        {component.wastage_percentage !== null && (
                          <>
                            <Grid item xs={6} sm={3}>{t('costTemplates.wastage')}:</Grid>
                            <Grid item xs={6} sm={9}>{component.wastage_percentage}%</Grid>
                          </>
                        )}
                      </Grid>
                    </AccordionDetails>
                  </Accordion>
                ))
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDetailsDialog}>{t('common.close')}</Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ProductCostList;
