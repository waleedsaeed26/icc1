import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Box, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  Snackbar,
  Alert,
  Checkbox,
  FormControlLabel
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';

interface VariableCost {
  id: number;
  company_id: number;
  cost_name: string;
  cost_category: string;
  unit_of_measure: string;
  cost_per_unit: number;
  is_active: boolean;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

const VariableCostList: React.FC = () => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();
  const [variableCosts, setVariableCosts] = useState<VariableCost[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingVariableCost, setEditingVariableCost] = useState<VariableCost | null>(null);
  const [formData, setFormData] = useState({
    cost_name: '',
    cost_category: '',
    unit_of_measure: '',
    cost_per_unit: '',
    is_active: true,
    notes: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  useEffect(() => {
    fetchVariableCosts();
  }, []);

  const fetchVariableCosts = async () => {
    try {
      setLoading(true);
      const response = await api.get('/variable-costs', {
        params: { company_id: currentUser?.company_id }
      });
      setVariableCosts(response.data);
    } catch (error) {
      console.error('Error fetching variable costs:', error);
      setSnackbar({
        open: true,
        message: t('variableCosts.fetchError'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (variableCost?: VariableCost) => {
    if (variableCost) {
      setEditingVariableCost(variableCost);
      setFormData({
        cost_name: variableCost.cost_name,
        cost_category: variableCost.cost_category,
        unit_of_measure: variableCost.unit_of_measure,
        cost_per_unit: variableCost.cost_per_unit.toString(),
        is_active: variableCost.is_active,
        notes: variableCost.notes || ''
      });
    } else {
      setEditingVariableCost(null);
      setFormData({
        cost_name: '',
        cost_category: '',
        unit_of_measure: '',
        cost_per_unit: '',
        is_active: true,
        notes: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    if (name) {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const handleSubmit = async () => {
    try {
      const data = {
        ...formData,
        company_id: currentUser?.company_id,
        cost_per_unit: parseFloat(formData.cost_per_unit)
      };

      if (editingVariableCost) {
        await api.put(`/variable-costs/${editingVariableCost.id}`, data);
        setSnackbar({
          open: true,
          message: t('variableCosts.updateSuccess'),
          severity: 'success'
        });
      } else {
        await api.post('/variable-costs', data);
        setSnackbar({
          open: true,
          message: t('variableCosts.createSuccess'),
          severity: 'success'
        });
      }

      handleCloseDialog();
      fetchVariableCosts();
    } catch (error) {
      console.error('Error saving variable cost:', error);
      setSnackbar({
        open: true,
        message: editingVariableCost ? t('variableCosts.updateError') : t('variableCosts.createError'),
        severity: 'error'
      });
    }
  };

  const handleDelete = async (id: number) => {
    if (window.confirm(t('common.confirmDelete'))) {
      try {
        await api.delete(`/variable-costs/${id}`);
        fetchVariableCosts();
        setSnackbar({
          open: true,
          message: t('variableCosts.deleteSuccess'),
          severity: 'success'
        });
      } catch (error) {
        console.error('Error deleting variable cost:', error);
        setSnackbar({
          open: true,
          message: t('variableCosts.deleteError'),
          severity: 'error'
        });
      }
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          {t('variableCosts.title')}
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          {t('variableCosts.addNew')}
        </Button>
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>{t('variableCosts.costName')}</TableCell>
                <TableCell>{t('variableCosts.category')}</TableCell>
                <TableCell>{t('variableCosts.unitOfMeasure')}</TableCell>
                <TableCell>{t('variableCosts.costPerUnit')}</TableCell>
                <TableCell>{t('common.status')}</TableCell>
                <TableCell>{t('common.actions')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    {t('common.loading')}
                  </TableCell>
                </TableRow>
              ) : variableCosts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    {t('variableCosts.noVariableCosts')}
                  </TableCell>
                </TableRow>
              ) : (
                variableCosts.map((cost) => (
                  <TableRow key={cost.id}>
                    <TableCell>{cost.cost_name}</TableCell>
                    <TableCell>{cost.cost_category}</TableCell>
                    <TableCell>{cost.unit_of_measure}</TableCell>
                    <TableCell>{cost.cost_per_unit.toFixed(2)}</TableCell>
                    <TableCell>
                      {cost.is_active 
                        ? t('common.active') 
                        : t('common.inactive')}
                    </TableCell>
                    <TableCell>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleOpenDialog(cost)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton 
                        color="error" 
                        onClick={() => handleDelete(cost.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingVariableCost 
            ? t('variableCosts.editVariableCost') 
            : t('variableCosts.addVariableCost')}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                name="cost_name"
                label={t('variableCosts.costName')}
                value={formData.cost_name}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="cost_category"
                label={t('variableCosts.category')}
                value={formData.cost_category}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="unit_of_measure"
                label={t('variableCosts.unitOfMeasure')}
                value={formData.unit_of_measure}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="cost_per_unit"
                label={t('variableCosts.costPerUnit')}
                value={formData.cost_per_unit}
                onChange={handleInputChange}
                type="number"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="is_active"
                    checked={formData.is_active}
                    onChange={handleCheckboxChange}
                  />
                }
                label={t('common.active')}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="notes"
                label={t('common.notes')}
                value={formData.notes}
                onChange={handleInputChange}
                fullWidth
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>{t('common.cancel')}</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            {t('common.save')}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default VariableCostList;
