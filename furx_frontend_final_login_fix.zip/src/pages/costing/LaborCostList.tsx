import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Box, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  Snackbar,
  Alert,
  Checkbox,
  FormControlLabel
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';

interface LaborCost {
  id: number;
  company_id: number;
  department_id: number | null;
  workshop_id: number | null;
  labor_category: string;
  cost_per_hour: number;
  overhead_percentage: number | null;
  is_active: boolean;
  notes: string | null;
  department_name?: string; // Added for display
  workshop_name?: string; // Added for display
  created_at: string;
  updated_at: string;
}

interface Department {
  id: number;
  department_name: string;
}

interface Workshop {
  id: number;
  workshop_name: string;
}

const LaborCostList: React.FC = () => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();
  const [laborCosts, setLaborCosts] = useState<LaborCost[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingLaborCost, setEditingLaborCost] = useState<LaborCost | null>(null);
  const [formData, setFormData] = useState({
    department_id: '',
    workshop_id: '',
    labor_category: '',
    cost_per_hour: '',
    overhead_percentage: '',
    is_active: true,
    notes: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  useEffect(() => {
    fetchLaborCosts();
    fetchDepartments();
    fetchWorkshops();
  }, []);

  const fetchLaborCosts = async () => {
    try {
      setLoading(true);
      const response = await api.get('/labor-costs', {
        params: { company_id: currentUser?.company_id }
      });
      setLaborCosts(response.data);
    } catch (error) {
      console.error('Error fetching labor costs:', error);
      setSnackbar({
        open: true,
        message: t('laborCosts.fetchError'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await api.get('/departments', {
        params: { company_id: currentUser?.company_id }
      });
      setDepartments(response.data);
    } catch (error) {
      console.error('Error fetching departments:', error);
    }
  };

  const fetchWorkshops = async () => {
    try {
      const response = await api.get('/workshops', {
        params: { company_id: currentUser?.company_id }
      });
      setWorkshops(response.data);
    } catch (error) {
      console.error('Error fetching workshops:', error);
    }
  };

  const handleOpenDialog = (laborCost?: LaborCost) => {
    if (laborCost) {
      setEditingLaborCost(laborCost);
      setFormData({
        department_id: laborCost.department_id?.toString() || '',
        workshop_id: laborCost.workshop_id?.toString() || '',
        labor_category: laborCost.labor_category,
        cost_per_hour: laborCost.cost_per_hour.toString(),
        overhead_percentage: laborCost.overhead_percentage?.toString() || '',
        is_active: laborCost.is_active,
        notes: laborCost.notes || ''
      });
    } else {
      setEditingLaborCost(null);
      setFormData({
        department_id: '',
        workshop_id: '',
        labor_category: '',
        cost_per_hour: '',
        overhead_percentage: '',
        is_active: true,
        notes: ''
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    if (name) {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const handleSubmit = async () => {
    try {
      const data = {
        ...formData,
        company_id: currentUser?.company_id,
        department_id: formData.department_id ? parseInt(formData.department_id) : null,
        workshop_id: formData.workshop_id ? parseInt(formData.workshop_id) : null,
        cost_per_hour: parseFloat(formData.cost_per_hour),
        overhead_percentage: formData.overhead_percentage ? parseFloat(formData.overhead_percentage) : null
      };

      if (editingLaborCost) {
        await api.put(`/labor-costs/${editingLaborCost.id}`, data);
        setSnackbar({
          open: true,
          message: t('laborCosts.updateSuccess'),
          severity: 'success'
        });
      } else {
        await api.post('/labor-costs', data);
        setSnackbar({
          open: true,
          message: t('laborCosts.createSuccess'),
          severity: 'success'
        });
      }

      handleCloseDialog();
      fetchLaborCosts();
    } catch (error) {
      console.error('Error saving labor cost:', error);
      setSnackbar({
        open: true,
        message: editingLaborCost ? t('laborCosts.updateError') : t('laborCosts.createError'),
        severity: 'error'
      });
    }
  };

  const handleDelete = async (id: number) => {
    if (window.confirm(t('common.confirmDelete'))) {
      try {
        await api.delete(`/labor-costs/${id}`);
        fetchLaborCosts();
        setSnackbar({
          open: true,
          message: t('laborCosts.deleteSuccess'),
          severity: 'success'
        });
      } catch (error) {
        console.error('Error deleting labor cost:', error);
        setSnackbar({
          open: true,
          message: t('laborCosts.deleteError'),
          severity: 'error'
        });
      }
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          {t('laborCosts.title')}
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          {t('laborCosts.addNew')}
        </Button>
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>{t('laborCosts.category')}</TableCell>
                <TableCell>{t('laborCosts.costPerHour')}</TableCell>
                <TableCell>{t('laborCosts.overheadPercentage')}</TableCell>
                <TableCell>{t('laborCosts.department')}</TableCell>
                <TableCell>{t('laborCosts.workshop')}</TableCell>
                <TableCell>{t('common.status')}</TableCell>
                <TableCell>{t('common.actions')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={7} align="center">
                    {t('common.loading')}
                  </TableCell>
                </TableRow>
              ) : laborCosts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} align="center">
                    {t('laborCosts.noLaborCosts')}
                  </TableCell>
                </TableRow>
              ) : (
                laborCosts.map((cost) => (
                  <TableRow key={cost.id}>
                    <TableCell>{cost.labor_category}</TableCell>
                    <TableCell>{cost.cost_per_hour.toFixed(2)}</TableCell>
                    <TableCell>{cost.overhead_percentage !== null ? `${cost.overhead_percentage.toFixed(2)}%` : '-'}</TableCell>
                    <TableCell>{cost.department_name || '-'}</TableCell>
                    <TableCell>{cost.workshop_name || '-'}</TableCell>
                    <TableCell>
                      {cost.is_active 
                        ? t('common.active') 
                        : t('common.inactive')}
                    </TableCell>
                    <TableCell>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleOpenDialog(cost)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton 
                        color="error" 
                        onClick={() => handleDelete(cost.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingLaborCost 
            ? t('laborCosts.editLaborCost') 
            : t('laborCosts.addLaborCost')}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                name="labor_category"
                label={t('laborCosts.category')}
                value={formData.labor_category}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="cost_per_hour"
                label={t('laborCosts.costPerHour')}
                value={formData.cost_per_hour}
                onChange={handleInputChange}
                type="number"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                name="overhead_percentage"
                label={t('laborCosts.overheadPercentage')}
                value={formData.overhead_percentage}
                onChange={handleInputChange}
                type="number"
                fullWidth
                InputProps={{ endAdornment: '%' }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>{t('laborCosts.department')}</InputLabel>
                <Select
                  name="department_id"
                  value={formData.department_id}
                  onChange={handleInputChange}
                  label={t('laborCosts.department')}
                >
                  <MenuItem value=""><em>{t('common.none')}</em></MenuItem>
                  {departments.map((dept) => (
                    <MenuItem key={dept.id} value={dept.id}>
                      {dept.department_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth>
                <InputLabel>{t('laborCosts.workshop')}</InputLabel>
                <Select
                  name="workshop_id"
                  value={formData.workshop_id}
                  onChange={handleInputChange}
                  label={t('laborCosts.workshop')}
                >
                  <MenuItem value=""><em>{t('common.none')}</em></MenuItem>
                  {workshops.map((workshop) => (
                    <MenuItem key={workshop.id} value={workshop.id}>
                      {workshop.workshop_name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="is_active"
                    checked={formData.is_active}
                    onChange={handleCheckboxChange}
                  />
                }
                label={t('common.active')}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="notes"
                label={t('common.notes')}
                value={formData.notes}
                onChange={handleInputChange}
                fullWidth
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>{t('common.cancel')}</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            {t('common.save')}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default LaborCostList;
