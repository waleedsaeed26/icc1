import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Box, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  IconButton,
  Snackbar,
  Alert,
  Checkbox,
  FormControlLabel,
  Tabs,
  Tab
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import { useAuth } from '../../contexts/AuthContext';
import { api } from '../../services/api';

interface CostTemplate {
  id: number;
  company_id: number;
  template_name: string;
  template_description: string | null;
  product_category: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface CostTemplateComponent {
  id: number;
  template_id: number;
  component_type: string;
  component_name: string;
  cost_category: string;
  quantity: number;
  unit_cost: number;
  wastage_percentage: number | null;
  notes: string | null;
}

const CostTemplateList: React.FC = () => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();
  const [costTemplates, setCostTemplates] = useState<CostTemplate[]>([]);
  const [templateComponents, setTemplateComponents] = useState<CostTemplateComponent[]>([]);
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [openComponentsDialog, setOpenComponentsDialog] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<CostTemplate | null>(null);
  const [selectedTemplateId, setSelectedTemplateId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState(0);
  const [formData, setFormData] = useState({
    template_name: '',
    template_description: '',
    product_category: '',
    is_active: true
  });
  const [componentFormData, setComponentFormData] = useState({
    component_type: 'material',
    component_name: '',
    cost_category: '',
    quantity: '1',
    unit_cost: '',
    wastage_percentage: '',
    notes: ''
  });
  const [editingComponent, setEditingComponent] = useState<CostTemplateComponent | null>(null);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  useEffect(() => {
    fetchCostTemplates();
  }, []);

  const fetchCostTemplates = async () => {
    try {
      setLoading(true);
      const response = await api.get('/cost-templates', {
        params: { company_id: currentUser?.company_id }
      });
      setCostTemplates(response.data);
    } catch (error) {
      console.error('Error fetching cost templates:', error);
      setSnackbar({
        open: true,
        message: t('costTemplates.fetchError'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchTemplateComponents = async (templateId: number) => {
    try {
      const response = await api.get(`/cost-templates/${templateId}/components`);
      setTemplateComponents(response.data);
    } catch (error) {
      console.error('Error fetching template components:', error);
      setSnackbar({
        open: true,
        message: t('costTemplates.fetchComponentsError'),
        severity: 'error'
      });
    }
  };

  const handleOpenDialog = (template?: CostTemplate) => {
    if (template) {
      setEditingTemplate(template);
      setFormData({
        template_name: template.template_name,
        template_description: template.template_description || '',
        product_category: template.product_category || '',
        is_active: template.is_active
      });
    } else {
      setEditingTemplate(null);
      setFormData({
        template_name: '',
        template_description: '',
        product_category: '',
        is_active: true
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleOpenComponentsDialog = (templateId: number) => {
    setSelectedTemplateId(templateId);
    fetchTemplateComponents(templateId);
    setOpenComponentsDialog(true);
    setActiveTab(0);
  };

  const handleCloseComponentsDialog = () => {
    setOpenComponentsDialog(false);
    setSelectedTemplateId(null);
    setTemplateComponents([]);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    if (name) {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleComponentInputChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    if (name) {
      setComponentFormData({
        ...componentFormData,
        [name]: value
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData({
      ...formData,
      [name]: checked
    });
  };

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
    if (newValue === 0) {
      // Reset component form when switching to list view
      resetComponentForm();
    }
  };

  const resetComponentForm = () => {
    setComponentFormData({
      component_type: 'material',
      component_name: '',
      cost_category: '',
      quantity: '1',
      unit_cost: '',
      wastage_percentage: '',
      notes: ''
    });
    setEditingComponent(null);
  };

  const handleEditComponent = (component: CostTemplateComponent) => {
    setEditingComponent(component);
    setComponentFormData({
      component_type: component.component_type,
      component_name: component.component_name,
      cost_category: component.cost_category,
      quantity: component.quantity.toString(),
      unit_cost: component.unit_cost.toString(),
      wastage_percentage: component.wastage_percentage?.toString() || '',
      notes: component.notes || ''
    });
    setActiveTab(1); // Switch to edit tab
  };

  const handleSubmit = async () => {
    try {
      const data = {
        ...formData,
        company_id: currentUser?.company_id,
        product_category: formData.product_category || null,
        template_description: formData.template_description || null
      };

      if (editingTemplate) {
        await api.put(`/cost-templates/${editingTemplate.id}`, data);
        setSnackbar({
          open: true,
          message: t('costTemplates.updateSuccess'),
          severity: 'success'
        });
      } else {
        await api.post('/cost-templates', data);
        setSnackbar({
          open: true,
          message: t('costTemplates.createSuccess'),
          severity: 'success'
        });
      }

      handleCloseDialog();
      fetchCostTemplates();
    } catch (error) {
      console.error('Error saving cost template:', error);
      setSnackbar({
        open: true,
        message: editingTemplate ? t('costTemplates.updateError') : t('costTemplates.createError'),
        severity: 'error'
      });
    }
  };

  const handleSubmitComponent = async () => {
    if (!selectedTemplateId) return;

    try {
      const data = {
        template_id: selectedTemplateId,
        component_type: componentFormData.component_type,
        component_name: componentFormData.component_name,
        cost_category: componentFormData.cost_category,
        quantity: parseFloat(componentFormData.quantity),
        unit_cost: parseFloat(componentFormData.unit_cost),
        wastage_percentage: componentFormData.wastage_percentage ? parseFloat(componentFormData.wastage_percentage) : null,
        notes: componentFormData.notes || null
      };

      if (editingComponent) {
        await api.put(`/cost-templates/${selectedTemplateId}/components/${editingComponent.id}`, data);
        setSnackbar({
          open: true,
          message: t('costTemplates.updateComponentSuccess'),
          severity: 'success'
        });
      } else {
        await api.post(`/cost-templates/${selectedTemplateId}/components`, data);
        setSnackbar({
          open: true,
          message: t('costTemplates.addComponentSuccess'),
          severity: 'success'
        });
      }

      resetComponentForm();
      fetchTemplateComponents(selectedTemplateId);
      setActiveTab(0); // Switch back to list view
    } catch (error) {
      console.error('Error saving component:', error);
      setSnackbar({
        open: true,
        message: editingComponent ? t('costTemplates.updateComponentError') : t('costTemplates.addComponentError'),
        severity: 'error'
      });
    }
  };

  const handleDeleteComponent = async (componentId: number) => {
    if (!selectedTemplateId) return;

    if (window.confirm(t('common.confirmDelete'))) {
      try {
        await api.delete(`/cost-templates/${selectedTemplateId}/components/${componentId}`);
        fetchTemplateComponents(selectedTemplateId);
        setSnackbar({
          open: true,
          message: t('costTemplates.deleteComponentSuccess'),
          severity: 'success'
        });
      } catch (error) {
        console.error('Error deleting component:', error);
        setSnackbar({
          open: true,
          message: t('costTemplates.deleteComponentError'),
          severity: 'error'
        });
      }
    }
  };

  const handleDelete = async (id: number) => {
    if (window.confirm(t('common.confirmDelete'))) {
      try {
        await api.delete(`/cost-templates/${id}`);
        fetchCostTemplates();
        setSnackbar({
          open: true,
          message: t('costTemplates.deleteSuccess'),
          severity: 'success'
        });
      } catch (error) {
        console.error('Error deleting cost template:', error);
        setSnackbar({
          open: true,
          message: t('costTemplates.deleteError'),
          severity: 'error'
        });
      }
    }
  };

  const handleDuplicateTemplate = async (id: number) => {
    try {
      await api.post(`/cost-templates/${id}/duplicate`);
      fetchCostTemplates();
      setSnackbar({
        open: true,
        message: t('costTemplates.duplicateSuccess'),
        severity: 'success'
      });
    } catch (error) {
      console.error('Error duplicating template:', error);
      setSnackbar({
        open: true,
        message: t('costTemplates.duplicateError'),
        severity: 'error'
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          {t('costTemplates.title')}
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
        >
          {t('costTemplates.addNew')}
        </Button>
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>{t('costTemplates.templateName')}</TableCell>
                <TableCell>{t('costTemplates.description')}</TableCell>
                <TableCell>{t('costTemplates.productCategory')}</TableCell>
                <TableCell>{t('common.status')}</TableCell>
                <TableCell>{t('common.actions')}</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} align="center">
                    {t('common.loading')}
                  </TableCell>
                </TableRow>
              ) : costTemplates.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} align="center">
                    {t('costTemplates.noCostTemplates')}
                  </TableCell>
                </TableRow>
              ) : (
                costTemplates.map((template) => (
                  <TableRow key={template.id}>
                    <TableCell>{template.template_name}</TableCell>
                    <TableCell>{template.template_description || '-'}</TableCell>
                    <TableCell>{template.product_category || '-'}</TableCell>
                    <TableCell>
                      {template.is_active 
                        ? t('common.active') 
                        : t('common.inactive')}
                    </TableCell>
                    <TableCell>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleOpenDialog(template)}
                        title={t('common.edit')}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleOpenComponentsDialog(template.id)}
                        title={t('costTemplates.manageComponents')}
                      >
                        <AddIcon />
                      </IconButton>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleDuplicateTemplate(template.id)}
                        title={t('costTemplates.duplicate')}
                      >
                        <ContentCopyIcon />
                      </IconButton>
                      <IconButton 
                        color="error" 
                        onClick={() => handleDelete(template.id)}
                        title={t('common.delete')}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      {/* Template Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {editingTemplate 
            ? t('costTemplates.editCostTemplate') 
            : t('costTemplates.addCostTemplate')}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                name="template_name"
                label={t('costTemplates.templateName')}
                value={formData.template_name}
                onChange={handleInputChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="template_description"
                label={t('costTemplates.description')}
                value={formData.template_description}
                onChange={handleInputChange}
                fullWidth
                multiline
                rows={2}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="product_category"
                label={t('costTemplates.productCategory')}
                value={formData.product_category}
                onChange={handleInputChange}
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="is_active"
                    checked={formData.is_active}
                    onChange={handleCheckboxChange}
                  />
                }
                label={t('common.active')}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>{t('common.cancel')}</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            {t('common.save')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Components Dialog */}
      <Dialog 
        open={openComponentsDialog} 
        onClose={handleCloseComponentsDialog} 
        maxWidth="lg" 
        fullWidth
      >
        <DialogTitle>
          {t('costTemplates.manageComponents')}
        </DialogTitle>
        <DialogContent>
          <Tabs value={activeTab} onChange={handleTabChange} sx={{ mb: 2 }}>
            <Tab label={t('costTemplates.componentsList')} />
            <Tab label={t('costTemplates.addComponent')} />
          </Tabs>

          {activeTab === 0 && (
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>{t('costTemplates.componentType')}</TableCell>
                    <TableCell>{t('costTemplates.componentName')}</TableCell>
                    <TableCell>{t('costTemplates.category')}</TableCell>
                    <TableCell>{t('costTemplates.quantity')}</TableCell>
                    <TableCell>{t('costTemplates.unitCost')}</TableCell>
                    <TableCell>{t('costTemplates.totalCost')}</TableCell>
                    <TableCell>{t('costTemplates.wastage')}</TableCell>
                    <TableCell>{t('common.actions')}</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {templateComponents.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} align="center">
                        {t('costTemplates.noComponents')}
                      </TableCell>
                    </TableRow>
                  ) : (
                    templateComponents.map((component) => (
                      <TableRow key={component.id}>
                        <TableCell>{t(`costTemplates.type_${component.component_type}`)}</TableCell>
                        <TableCell>{component.component_name}</TableCell>
                        <TableCell>{component.cost_category}</TableCell>
                        <TableCell>{component.quantity}</TableCell>
                        <TableCell>{component.unit_cost.toFixed(2)}</TableCell>
                        <TableCell>{(component.quantity * component.unit_cost).toFixed(2)}</TableCell>
                        <TableCell>{component.wastage_percentage ? `${component.wastage_percentage}%` : '-'}</TableCell>
                        <TableCell>
                          <IconButton 
                            color="primary" 
                            onClick={() => handleEditComponent(component)}
                          >
                            <EditIcon />
                          </IconButton>
                          <IconButton 
                            color="error" 
                            onClick={() => handleDeleteComponent(component.id)}
                          >
                            <DeleteIcon />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}

          {activeTab === 1 && (
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth required>
                  <InputLabel>{t('costTemplates.componentType')}</InputLabel>
                  <Select
                    name="component_type"
                    value={componentFormData.component_type}
                    onChange={handleComponentInputChange}
                    label={t('costTemplates.componentType')}
                  >
                    <MenuItem value="material">{t('costTemplates.type_material')}</MenuItem>
                    <MenuItem value="labor">{t('costTemplates.type_labor')}</MenuItem>
                    <MenuItem value="operational">{t('costTemplates.type_operational')}</MenuItem>
                    <MenuItem value="other">{t('costTemplates.type_other')}</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="component_name"
                  label={t('costTemplates.componentName')}
                  value={componentFormData.component_name}
                  onChange={handleComponentInputChange}
                  fullWidth
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="cost_category"
                  label={t('costTemplates.category')}
                  value={componentFormData.cost_category}
                  onChange={handleComponentInputChange}
                  fullWidth
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="quantity"
                  label={t('costTemplates.quantity')}
                  value={componentFormData.quantity}
                  onChange={handleComponentInputChange}
                  type="number"
                  fullWidth
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="unit_cost"
                  label={t('costTemplates.unitCost')}
                  value={componentFormData.unit_cost}
                  onChange={handleComponentInputChange}
                  type="number"
                  fullWidth
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="wastage_percentage"
                  label={t('costTemplates.wastagePercentage')}
                  value={componentFormData.wastage_percentage}
                  onChange={handleComponentInputChange}
                  type="number"
                  fullWidth
                  InputProps={{ endAdornment: '%' }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  name="notes"
                  label={t('common.notes')}
                  value={componentFormData.notes}
                  onChange={handleComponentInputChange}
                  fullWidth
                  multiline
                  rows={2}
                />
              </Grid>
            </Grid>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseComponentsDialog}>{t('common.close')}</Button>
          {activeTab === 1 && (
            <Button onClick={handleSubmitComponent} variant="contained" color="primary">
              {editingComponent ? t('common.update') : t('common.add')}
            </Button>
          )}
        </DialogActions>
      </Dialog>

      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default CostTemplateList;
