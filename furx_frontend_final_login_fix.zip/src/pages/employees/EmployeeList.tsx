import React from 'react';
import { Typography, Box } from '@mui/material';
import { useTranslation } from 'react-i18next';

const EmployeeList: React.FC = () => {
  const { t } = useTranslation();
  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        {t('employees.title')} {/* Assuming 'employees.title' exists */}
      </Typography>
      <Typography variant="body1">
        {t('common.comingSoon')}
      </Typography>
    </Box>
  );
};

export default EmployeeList;
