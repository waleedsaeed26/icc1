import React from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Box, 
  Typography, 
  Grid, 
  Paper, 
  Card, 
  CardContent, 
  CardHeader,
  List,
  ListItem,
  ListItemText,
  Divider,
  Button,
  Stack
} from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';
import FactoryIcon from '@mui/icons-material/Factory';
import InventoryIcon from '@mui/icons-material/Inventory';
import AssignmentIcon from '@mui/icons-material/Assignment';

const Dashboard: React.FC = () => {
  const { t } = useTranslation();

  // Mock data for dashboard
  const stats = {
    employees: 120,
    activeWorkshops: 8,
    productionItems: 45,
    inventoryItems: 230
  };

  const recentActivities = [
    { id: 1, text: 'تم إضافة ورشة جديدة: ورشة الدهان', time: '10:30 AM' },
    { id: 2, text: 'تم نقل قطعة الإنتاج #1234 إلى مرحلة التجميع', time: '09:45 AM' },
    { id: 3, text: 'تم استلام مواد خام: خشب زان - 200 متر', time: 'أمس' },
    { id: 4, text: 'تم تعيين موظف جديد: أحمد محمد', time: 'أمس' }
  ];

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        {t('dashboard.welcome')}
      </Typography>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        {/* Stats Cards */}
        <Grid item xs={12} sm={6} md={3}>
          <Paper elevation={3} sx={{ p: 2, display: 'flex', flexDirection: 'column', alignItems: 'center', height: 140 }}>
            <PeopleIcon sx={{ fontSize: 40, color: 'primary.main', mb: 1 }} />
            <Typography variant="h4">{stats.employees}</Typography>
            <Typography variant="body2" color="text.secondary">{t('dashboard.totalEmployees')}</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper elevation={3} sx={{ p: 2, display: 'flex', flexDirection: 'column', alignItems: 'center', height: 140 }}>
            <FactoryIcon sx={{ fontSize: 40, color: 'success.main', mb: 1 }} />
            <Typography variant="h4">{stats.activeWorkshops}</Typography>
            <Typography variant="body2" color="text.secondary">{t('dashboard.activeWorkshops')}</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper elevation={3} sx={{ p: 2, display: 'flex', flexDirection: 'column', alignItems: 'center', height: 140 }}>
            <AssignmentIcon sx={{ fontSize: 40, color: 'warning.main', mb: 1 }} />
            <Typography variant="h4">{stats.productionItems}</Typography>
            <Typography variant="body2" color="text.secondary">{t('dashboard.productionItems')}</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Paper elevation={3} sx={{ p: 2, display: 'flex', flexDirection: 'column', alignItems: 'center', height: 140 }}>
            <InventoryIcon sx={{ fontSize: 40, color: 'error.main', mb: 1 }} />
            <Typography variant="h4">{stats.inventoryItems}</Typography>
            <Typography variant="body2" color="text.secondary">{t('dashboard.inventoryStatus')}</Typography>
          </Paper>
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        {/* Recent Activities */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader title={t('dashboard.recentActivities')} />
            <CardContent>
              <List>
                {recentActivities.map((activity, index) => (
                  <React.Fragment key={activity.id}>
                    <ListItem>
                      <ListItemText 
                        primary={activity.text} 
                        secondary={activity.time} 
                      />
                    </ListItem>
                    {index < recentActivities.length - 1 && <Divider />}
                  </React.Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Quick Actions */}
        <Grid item xs={12} md={6}>
          <Card>
            <CardHeader title={t('dashboard.quickActions')} />
            <CardContent>
              <Stack spacing={2}>
                <Button variant="contained" color="primary" fullWidth>
                  {t('workshops.add')}
                </Button>
                <Button variant="contained" color="secondary" fullWidth>
                  {t('production.scanQR')}
                </Button>
                <Button variant="contained" color="success" fullWidth>
                  {t('inventory.receipt')}
                </Button>
                <Button variant="outlined" color="primary" fullWidth>
                  {t('reports.title')}
                </Button>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
