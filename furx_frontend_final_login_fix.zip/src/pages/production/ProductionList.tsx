import React, { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Box, 
  Typography, 
  Paper, 
  Button,
  TextField,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Tooltip,
  Snackbar,
  Alert,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  LinearProgress
} from '@mui/material';
import { DataGrid, GridColDef, GridRowParams } from '@mui/x-data-grid';
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@mui/icons-material/Visibility';
import QrCodeIcon from '@mui/icons-material/QrCode';
import { productionService } from '../../services/api'; // Import the API service

// Interface for Production Item data
interface ProductionItem {
  id: number;
  qr_code: string;
  production_order_id: number | null;
  current_stage_id: number | null;
  current_location_id: number | null;
  status: string;
  completion_percentage: number;
  notes: string | null;
  company_id: number;
  // Add related data if needed (e.g., stage name, location name)
  current_stage_name?: string;
  current_location_name?: string;
  production_order_code?: string;
}

// Mock data for stages and locations (Replace with API calls later if needed)
const productionStages = [
  { id: 1, name: 'النجارة' },
  { id: 2, name: 'الدهان' },
  { id: 3, name: 'التنجيد' },
  { id: 4, name: 'المعادن' },
  { id: 5, name: 'التجميع' },
  { id: 6, name: 'مكتمل' }
];

const locations = [
  { id: 1, name: 'ورشة النجارة' },
  { id: 2, name: 'ورشة الدهان' },
  { id: 3, name: 'ورشة التنجيد' },
  { id: 4, name: 'ورشة المعادن' },
  { id: 5, name: 'ورشة التجميع' },
  { id: 6, name: 'المخزن' }
];

const ProductionList: React.FC = () => {
  const { t } = useTranslation();
  const [productionItems, setProductionItems] = useState<ProductionItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [openMoveDialog, setOpenMoveDialog] = useState(false);
  const [openDetailsDialog, setOpenDetailsDialog] = useState(false);
  const [currentItem, setCurrentItem] = useState<ProductionItem | null>(null);
  const [moveData, setMoveData] = useState({
    to_stage_id: '' as string | number,
    to_location_id: '' as string | number,
    notes: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success' as 'success' | 'error'
  });

  // Fetch production items from API
  const fetchProductionItems = useCallback(async () => {
    setLoading(true);
    try {
      // TODO: Get current company ID dynamically
      const companyId = 1;
      const response = await productionService.getAllProductionItems(companyId);
      // Map stage/location IDs to names (ideally backend should provide this)
      const itemsWithNames = response.data.map((item: ProductionItem) => ({
        ...item,
        current_stage_name: productionStages.find(s => s.id === item.current_stage_id)?.name || 'N/A',
        current_location_name: locations.find(l => l.id === item.current_location_id)?.name || 'N/A',
        // Assuming production_order_id relates to an order code, fetch/map if needed
        production_order_code: `PO-${item.production_order_id || 'N/A'}` 
      }));
      setProductionItems(itemsWithNames);
    } catch (error) {
      console.error("Error fetching production items:", error);
      setSnackbar({
        open: true,
        message: t('common.error') + ': ' + t('production.items'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    fetchProductionItems();
  }, [fetchProductionItems]);

  const handleOpenMoveDialog = (item: ProductionItem) => {
    setCurrentItem(item);
    setMoveData({
      to_stage_id: item.current_stage_id || '',
      to_location_id: item.current_location_id || '',
      notes: ''
    });
    setOpenMoveDialog(true);
  };

  const handleCloseMoveDialog = () => {
    setOpenMoveDialog(false);
  };

  const handleOpenDetailsDialog = (item: ProductionItem) => {
    setCurrentItem(item);
    setOpenDetailsDialog(true);
  };

  const handleCloseDetailsDialog = () => {
    setOpenDetailsDialog(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    setMoveData({
      ...moveData,
      [name as string]: value
    });
  };

  const handleMoveItem = async () => {
    if (!currentItem) return;
    setLoading(true);
    try {
      await productionService.moveProductionItem(currentItem.id, {
        to_stage_id: moveData.to_stage_id,
        to_location_id: moveData.to_location_id,
        notes: moveData.notes,
        company_id: currentItem.company_id // Pass company_id
      });
      
      setSnackbar({
        open: true,
        message: t('production.moveItem') + ' ' + t('common.success'),
        severity: 'success'
      });
      
      fetchProductionItems(); // Refresh the list
      handleCloseMoveDialog();
    } catch (error) {
      console.error("Error moving item:", error);
      setSnackbar({
        open: true,
        message: t('common.error'),
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'ID', width: 70 },
    { field: 'qr_code', headerName: 'QR Code', width: 150 },
    { field: 'production_order_code', headerName: t('production.orders'), width: 150 },
    { field: 'current_stage_name', headerName: t('production.currentStage'), width: 150 },
    { field: 'current_location_name', headerName: t('production.currentLocation'), width: 150 },
    { field: 'status', headerName: t('production.status'), width: 120 },
    { 
      field: 'completion_percentage', 
      headerName: t('production.completion'), 
      width: 150,
      renderCell: (params) => (
        <Box sx={{ width: '100%', position: 'relative' }}>
          <LinearProgress 
            variant="determinate" 
            value={params.value} 
            sx={{ height: 10, borderRadius: 1 }}
            color={params.value < 30 ? 'error' : params.value < 70 ? 'warning' : 'success'}
          />
          <Box sx={{ 
            position: 'absolute', 
            top: 0, 
            left: 0, 
            right: 0, 
            bottom: 0, 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            color: 'text.secondary',
            fontSize: '0.75rem'
          }}>
            {params.value}%
          </Box>
        </Box>
      )
    },
    {
      field: 'actions',
      headerName: t('common.actions'),
      width: 200,
      sortable: false,
      renderCell: (params: GridRowParams<ProductionItem>) => (
        <Box>
          <Tooltip title={t('common.view')}>
            <IconButton color="primary" onClick={() => handleOpenDetailsDialog(params.row)}>
              <VisibilityIcon />
            </IconButton>
          </Tooltip>
          <Tooltip title={t('production.moveItem')}>
            <IconButton color="secondary" onClick={() => handleOpenMoveDialog(params.row)}>
              <EditIcon />
            </IconButton>
          </Tooltip>
          <Tooltip title={t('production.scanQR')}>
            <IconButton color="default">
              <QrCodeIcon />
            </IconButton>
          </Tooltip>
        </Box>
      )
    }
  ];

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h4" gutterBottom>
          {t('production.items')}
        </Typography>
        <Button 
          variant="contained" 
          startIcon={<QrCodeIcon />}
          color="secondary"
          disabled={loading}
        >
          {t('production.scanQR')}
        </Button>
      </Box>

      <Paper sx={{ height: 400, width: '100%' }}>
        <DataGrid
          rows={productionItems}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5, 10, 20]}
          checkboxSelection
          disableSelectionOnClick
          loading={loading}
        />
      </Paper>

      {/* Move Item Dialog */}
      <Dialog open={openMoveDialog} onClose={handleCloseMoveDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {t('production.moveItem')} - {currentItem?.qr_code}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel id="to-stage-label">{t('production.currentStage')}</InputLabel>
                <Select
                  labelId="to-stage-label"
                  name="to_stage_id"
                  value={moveData.to_stage_id}
                  onChange={handleInputChange}
                  label={t('production.currentStage')}
                >
                  {productionStages.map(stage => (
                    <MenuItem key={stage.id} value={stage.id}>{stage.name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel id="to-location-label">{t('production.currentLocation')}</InputLabel>
                <Select
                  labelId="to-location-label"
                  name="to_location_id"
                  value={moveData.to_location_id}
                  onChange={handleInputChange}
                  label={t('production.currentLocation')}
                >
                  {locations.map(location => (
                    <MenuItem key={location.id} value={location.id}>{location.name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="notes"
                label={t('common.notes')}
                value={moveData.notes}
                onChange={handleInputChange}
                fullWidth
                multiline
                rows={4}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseMoveDialog} disabled={loading}>{t('common.cancel')}</Button>
          <Button onClick={handleMoveItem} variant="contained" color="primary" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : t('common.save')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Item Details Dialog */}
      <Dialog open={openDetailsDialog} onClose={handleCloseDetailsDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {t('production.itemDetails')} - {currentItem?.qr_code}
        </DialogTitle>
        <DialogContent>
          {currentItem && (
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1">QR Code:</Typography>
                <Typography variant="body1">{currentItem.qr_code}</Typography>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1">{t('production.orders')}:</Typography>
                <Typography variant="body1">{currentItem.production_order_code}</Typography>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1">{t('production.currentStage')}:</Typography>
                <Typography variant="body1">{currentItem.current_stage_name}</Typography>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1">{t('production.currentLocation')}:</Typography>
                <Typography variant="body1">{currentItem.current_location_name}</Typography>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1">{t('production.status')}:</Typography>
                <Typography variant="body1">{currentItem.status}</Typography>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1">{t('production.completion')}:</Typography>
                <Box sx={{ width: '100%', position: 'relative' }}>
                  <LinearProgress 
                    variant="determinate" 
                    value={currentItem.completion_percentage} 
                    sx={{ height: 20, borderRadius: 1 }}
                    color={currentItem.completion_percentage < 30 ? 'error' : currentItem.completion_percentage < 70 ? 'warning' : 'success'}
                  />
                  <Box sx={{ 
                    position: 'absolute', 
                    top: 0, 
                    left: 0, 
                    right: 0, 
                    bottom: 0, 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center',
                    color: 'white',
                    fontWeight: 'bold'
                  }}>
                    {currentItem.completion_percentage}%
                  </Box>
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Typography variant="subtitle1">{t('common.notes')}:</Typography>
                <Typography variant="body1">{currentItem.notes || '-'}</Typography>
              </Grid>
            </Grid>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDetailsDialog}>{t('common.cancel')}</Button>
          <Button 
            onClick={() => {
              handleCloseDetailsDialog();
              if (currentItem) handleOpenMoveDialog(currentItem);
            }} 
            variant="contained" 
            color="primary"
          >
            {t('production.moveItem')}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity} sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ProductionList;
