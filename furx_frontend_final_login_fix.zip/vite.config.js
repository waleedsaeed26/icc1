import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    allowedHosts: [
      '5173-ifff3ar08niu121po90uj-fb3b2a41.manus.computer',
      'localhost',
    ],
    cors: true
  }
})
