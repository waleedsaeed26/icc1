# FURX Integrated System - Frontend Documentation

## Overview
This document provides comprehensive documentation for the frontend of the FURX Integrated System, a multi-company management system for furniture manufacturing and retail operations.

## Technology Stack
- **Framework**: React with TypeScript
- **UI Library**: Material UI (MUI)
- **State Management**: React Context API
- **Routing**: React Router
- **Internationalization**: i18next
- **API Communication**: Axios
- **Data Grid**: MUI X-Data-Grid

## Features
1. **Multi-Company Support**
   - Support for multiple companies (ICC, FURX, NOAH, ADAM'S)
   - Company-specific data separation
   - Company switching via dropdown in header

2. **Multilingual Support**
   - Arabic (primary language)
   - English (secondary language)
   - RTL/LTR layout switching
   - Language switching via dropdown in header

3. **User Authentication**
   - Login/logout functionality
   - Protected routes
   - Role-based access control

4. **Dashboard**
   - Overview statistics
   - Recent activities
   - Quick action buttons

5. **Workshop Management**
   - List all workshops
   - Add new workshops
   - Edit workshop details
   - Activate/deactivate workshops

6. **Production Tracking**
   - List production items
   - View item details
   - Move items between stages and locations
   - QR code scanning support

7. **Additional Modules**
   - Employee management
   - Department management
   - Inventory management
   - Reporting

## Project Structure
```
furx_frontend/
├── src/
│   ├── assets/
│   │   └── logos/         # Company logos
│   ├── components/
│   │   ├── auth/          # Authentication components
│   │   └── layout/        # Layout components
│   ├── contexts/
│   │   └── AuthContext.tsx # Authentication context
│   ├── locales/
│   │   ├── ar/            # Arabic translations
│   │   └── en/            # English translations
│   ├── pages/
│   │   ├── auth/          # Authentication pages
│   │   ├── companies/     # Company management pages
│   │   ├── departments/   # Department management pages
│   │   ├── employees/     # Employee management pages
│   │   ├── inventory/     # Inventory management pages
│   │   ├── production/    # Production management pages
│   │   ├── reports/       # Reporting pages
│   │   ├── workshops/     # Workshop management pages
│   │   ├── Dashboard.tsx  # Main dashboard
│   │   └── NotFound.tsx   # 404 page
│   ├── routes/
│   │   └── AppRoutes.tsx  # Application routes
│   ├── services/
│   │   ├── api.ts         # API service for production
│   │   └── mockApi.ts     # Mock API service for testing
│   ├── App.tsx            # Main application component
│   ├── i18n.ts            # Internationalization configuration
│   ├── main.tsx           # Application entry point
│   └── theme.ts           # Theme configuration
└── package.json           # Project dependencies
```

## Installation and Setup
1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. Create `.env` file with API URL:
   ```
   VITE_API_URL=http://localhost:3000/api
   ```
4. Start development server:
   ```
   npm run dev
   ```
5. Build for production:
   ```
   npm run build
   ```

## Authentication
The application uses JWT-based authentication. The login flow is as follows:
1. User enters credentials on the login page
2. Credentials are sent to the backend API
3. On successful authentication, a JWT token is returned
4. Token is stored in localStorage
5. Token is included in all subsequent API requests
6. Protected routes check for valid token

## Internationalization
The application supports both Arabic (RTL) and English (LTR) languages:
1. Default language is Arabic
2. Language can be switched via dropdown in header
3. UI direction (RTL/LTR) changes automatically based on language
4. All text is stored in translation files in `src/locales/`

## Workshop Management
The workshop management module allows:
1. Viewing all workshops with their status
2. Adding new workshops
3. Editing workshop details
4. Deactivating workshops (closing)
5. Reactivating previously deactivated workshops

This directly addresses the user's specific request to add functionality for creating new workshops and closing old ones through the main user interface.

## Production Tracking
The production tracking module allows:
1. Viewing all production items
2. Viewing detailed information about each item
3. Moving items between production stages and locations
4. Tracking completion percentage
5. QR code scanning for quick item lookup

## Integration with Backend
The frontend communicates with the backend API using Axios. The API service is structured to:
1. Handle authentication
2. Manage API requests for all modules
3. Handle errors consistently
4. Support company-specific data filtering

For testing purposes, a mock API service is provided that simulates backend functionality.

## Deployment
To deploy the application:
1. Build the application:
   ```
   npm run build
   ```
2. The build output will be in the `dist` directory
3. Deploy the contents of the `dist` directory to a web server
4. Ensure the backend API is accessible from the deployment location

## Future Enhancements
1. Implement offline support with service workers
2. Add more detailed reporting features
3. Enhance mobile responsiveness
4. Add user profile management
5. Implement real-time notifications
