#!/bin/bash

# Script to update and deploy the cost pricing module

echo "Starting deployment of cost pricing module..."

# Navigate to the project directory
cd /home/ubuntu/furx_integrated_system

# Create docs directory if it doesn't exist
mkdir -p docs

# Ensure the database schema directory exists
mkdir -p src/database

# Make the deployment script executable
chmod +x src/database/deploy_cost_pricing.py

# Check if PostgreSQL is running
if ! pg_isready -h localhost -p 5432 > /dev/null 2>&1; then
    echo "PostgreSQL is not running. Starting PostgreSQL..."
    sudo service postgresql start
    sleep 5
fi

# Create the database if it doesn't exist
if ! psql -lqt | cut -d \| -f 1 | grep -qw furx_db; then
    echo "Creating database furx_db..."
    createdb furx_db
fi

# Deploy the cost pricing schema and test data
echo "Deploying cost pricing schema and test data..."
python3 src/database/deploy_cost_pricing.py

# Update the server.js file if needed
# This step is already done in previous steps

# Restart the backend server
echo "Restarting the backend server..."
if pgrep -f "node src/server.js" > /dev/null; then
    pkill -f "node src/server.js"
fi
nohup node src/server.js > server.log 2>&1 &
echo "Backend server restarted."

# Print deployment summary
echo "Deployment completed successfully!"
echo "Cost pricing module has been deployed with the following components:"
echo "- Database schema: src/database/cost_pricing_schema_final.sql"
echo "- Test data: Generated from COST CONTROL.xlsx"
echo "- Backend API: Integrated in src/server.js"
echo "- Frontend components: Added to furx_frontend/src/pages/costing/"
echo "- Documentation: docs/cost_pricing_system.md"

echo "You can now access the cost pricing module through the FURX Integrated System."
