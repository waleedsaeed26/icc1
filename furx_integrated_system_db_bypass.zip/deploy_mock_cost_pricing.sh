#!/bin/bash

# Script to deploy the cost pricing module with mock database

echo "Starting deployment of cost pricing module with mock database..."

# Navigate to the project directory
cd /home/ubuntu/furx_integrated_system

# Create necessary directories
mkdir -p docs
mkdir -p src/database
mkdir -p src/services

# Ensure test data directory exists
if [ ! -d "/home/ubuntu/test_data" ]; then
  echo "Error: Test data directory not found. Please run extract_test_data.py first."
  exit 1
fi

# Check if all required JSON files exist
required_files=("cost_centers.json" "fixed_costs.json" "operational_costs.json" "cost_allocations.json" 
                "material_costs.json" "labor_costs.json" "products.json" "cost_templates.json" "pricing_rules.json")

for file in "${required_files[@]}"; do
  if [ ! -f "/home/ubuntu/test_data/$file" ]; then
    echo "Warning: $file not found in test data directory."
  fi
done

# Create cost_center_period_allocations.json if it doesn't exist
if [ ! -f "/home/ubuntu/test_data/cost_center_period_allocations.json" ]; then
  echo "Creating empty cost_center_period_allocations.json file..."
  echo "[]" > /home/ubuntu/test_data/cost_center_period_allocations.json
fi

# Create product_costs.json if it doesn't exist
if [ ! -f "/home/ubuntu/test_data/product_costs.json" ]; then
  echo "Creating empty product_costs.json file..."
  echo "[]" > /home/ubuntu/test_data/product_costs.json
fi

# Restart the backend server (if it's running)
echo "Restarting the backend server..."
if pgrep -f "node src/server.js" > /dev/null; then
    pkill -f "node src/server.js"
fi

# Start the server in the background
nohup node src/server.js > server.log 2>&1 &
echo "Backend server started with mock database service."

# Print deployment summary
echo "Mock deployment completed successfully!"
echo "Cost pricing module has been deployed with the following components:"
echo "- Mock Database Service: src/services/mockDatabaseService.js"
echo "- Database Schema (for reference): src/database/cost_pricing_schema_final.sql"
echo "- Test Data: JSON files in /home/ubuntu/test_data/"
echo "- Backend API: Integrated in src/server.js"
echo "- Frontend components: Added to furx_frontend/src/pages/costing/"
echo "- Documentation: docs/cost_pricing_system.md"

echo "You can now access the cost pricing module through the FURX Integrated System."
echo "Note: This deployment uses a mock database service instead of PostgreSQL."
