# FURX Integrated System Documentation

## نظرة عامة (Overview)

نظام FURX المتكامل هو نظام شامل لإدارة الإنتاج والمخزون والموارد البشرية والمبيعات لمجموعة شركات ICC. يدعم النظام هيكل الشركات المتعدد حيث ICC هي الشركة الأم، وتتفرع منها ثلاث شركات:

- **FURX**: شركة التصنيع التي تقوم بعمليات الإنتاج والبيع للشركات التجارية وعملاء آخرين
- **NOAH**: شركة تجارية تمتلك معرضين (التجمع الخامس ومدينة نصر) وموقع إلكتروني للبيع
- **ADAM'S**: شركة تجارية لديها فرع واحد وموقع إلكتروني للبيع

يوفر النظام فصلاً كاملاً للبيانات بين الشركات مع الحفاظ على العلاقات بينها، ويدعم تتبع الإنتاج باستخدام رموز QR، وإدارة المخزون، وإدارة الموارد البشرية والرواتب.

## الميزات الرئيسية (Key Features)

### 1. دعم هيكل الشركات المتعدد (Multi-Company Structure)

- فصل البيانات بين الشركات المختلفة (ICC, FURX, NOAH, ADAM'S)
- دعم العلاقات بين الشركات (الشركة الأم والشركات الفرعية)
- إدارة مركزية للصلاحيات مع تقييد الوصول حسب الشركة

### 2. تتبع الإنتاج (Production Tracking)

- تتبع كل قطعة أثاث بشكل فردي عبر جميع مراحل الإنتاج
- دعم رموز QR فريدة لكل قطعة
- تسجيل حركة القطع بين المراحل والمواقع المختلفة
- تتبع حالة كل قطعة ونسبة إكمالها

### 3. إدارة المخزون (Inventory Management)

- إدارة مخزون المواد الخام والمنتجات النهائية
- تسجيل حركات المخزون (استلام، صرف، تعديل)
- ربط حركات المخزون بأوامر الإنتاج والمستندات ذات الصلة
- تتبع المخزون حسب الموقع والشركة

### 4. إدارة الموارد البشرية والورش (HR & Workshop Management)

- إدارة بيانات الموظفين والعمال
- تعيين الموظفين للأقسام وخطوط الإنتاج والورش
- دعم أنواع مختلفة من الرواتب (شهري، أسبوعي)
- ربط الموظفين بعمليات الإنتاج
- **إدارة الورش**: إنشاء ورش جديدة، تحديث بياناتها، وإغلاق (تعطيل) الورش القديمة بواسطة المستخدم الرئيسي

## المتطلبات التقنية (Technical Requirements)

### متطلبات النظام (System Requirements)

- **نظام التشغيل**: Linux/Windows/macOS
- **Node.js**: الإصدار 14.0.0 أو أحدث
- **PostgreSQL**: الإصدار 12.0 أو أحدث

### متطلبات التثبيت (Installation Requirements)

1. تثبيت Node.js وnpm
2. تثبيت PostgreSQL وإنشاء قاعدة بيانات
3. تكوين متغيرات البيئة في ملف .env

## دليل التثبيت (Installation Guide)

### 1. استنساخ المستودع (Clone Repository)

```bash
git clone https://github.com/your-organization/furx-integrated-system.git
cd furx-integrated-system
```

### 2. تثبيت التبعيات (Install Dependencies)

```bash
npm install
```

### 3. إعداد ملف البيئة (Setup Environment File)

قم بإنشاء ملف `.env` في المجلد الرئيسي وأضف المتغيرات التالية:

```
PORT=3000
NODE_ENV=development
DB_USER=postgres
DB_PASSWORD=your_password
DB_HOST=localhost
DB_PORT=5432
DB_NAME=furx_integrated
JWT_SECRET=your_secret_key
JWT_EXPIRES_IN=1d
CORS_ORIGIN=*
```

### 4. إعداد قاعدة البيانات (Setup Database)

```bash
npm run setup-db
```

هذا الأمر سينشئ جميع الجداول اللازمة ويدخل البيانات الأولية للشركات.

### 5. تشغيل النظام (Run the System)

```bash
npm start
```

سيبدأ الخادم على المنفذ المحدد في ملف `.env` (افتراضياً 3000).

## هيكل API (API Structure)

### 1. إدارة الشركات (Companies Management)

- `GET /api/companies`: الحصول على جميع الشركات
- `GET /api/companies/:id`: الحصول على شركة محددة
- `POST /api/companies`: إنشاء شركة جديدة
- `PUT /api/companies/:id`: تحديث شركة
- `GET /api/companies/:id/children`: الحصول على الشركات الفرعية

### 2. إدارة الموظفين (Employees Management)

- `GET /api/employees?company_id=X`: الحصول على جميع الموظفين لشركة محددة
- `GET /api/employees/:id`: الحصول على موظف محدد
- `POST /api/employees`: إنشاء موظف جديد
- `PUT /api/employees/:id`: تحديث موظف

### 3. إدارة الأقسام (Departments Management)

- `GET /api/departments?company_id=X`: الحصول على جميع الأقسام لشركة محددة
- `GET /api/departments/:id`: الحصول على قسم محدد
- `POST /api/departments`: إنشاء قسم جديد
- `PUT /api/departments/:id`: تحديث قسم

### 4. إدارة الورش (Workshops Management)

- `GET /api/workshops?company_id=X&only_active=true|false`: الحصول على جميع الورش لشركة محددة (مع خيار عرض الورش النشطة فقط أو جميع الورش)
- `GET /api/workshops/:id`: الحصول على ورشة محددة
- `POST /api/workshops`: إنشاء ورشة جديدة
- `PUT /api/workshops/:id`: تحديث بيانات ورشة
- `POST /api/workshops/:id/deactivate`: إغلاق (تعطيل) ورشة
- `POST /api/workshops/:id/activate`: إعادة تفعيل ورشة

### 5. إدارة قطع الإنتاج (Production Items Management)

- `GET /api/production-items?company_id=X`: الحصول على جميع قطع الإنتاج لشركة محددة
- `GET /api/production-items/:id`: الحصول على قطعة إنتاج محددة
- `GET /api/production-items/qr/:qrCode`: البحث عن قطعة إنتاج باستخدام رمز QR
- `POST /api/production-items`: إنشاء قطعة إنتاج جديدة
- `PUT /api/production-items/:id`: تحديث قطعة إنتاج
- `POST /api/production-items/:id/move`: تسجيل حركة قطعة إنتاج
- `GET /api/production-items/order/:orderId`: الحصول على قطع الإنتاج لأمر إنتاج محدد
- `GET /api/production-items/stage/:stageId?company_id=X`: الحصول على قطع الإنتاج في مرحلة محددة

### 6. إدارة المخزون (Inventory Management)

- `GET /api/inventory/materials?company_id=X`: الحصول على مخزون المواد الخام لشركة محددة
- `GET /api/inventory/products?company_id=X`: الحصول على مخزون المنتجات لشركة محددة
- `POST /api/inventory/materials/transaction`: تسجيل حركة مخزون للمواد الخام
- `POST /api/inventory/products/transaction`: تسجيل حركة مخزون للمنتجات
- `GET /api/inventory/history?company_id=X`: الحصول على سجل حركات المخزون

## نموذج قاعدة البيانات (Database Model)

النظام يستخدم قاعدة بيانات PostgreSQL مع الجداول التالية:

1. `companies`: تخزين معلومات الشركات
2. `departments`: تخزين معلومات الأقسام
3. `production_lines`: تخزين معلومات خطوط الإنتاج
4. `workshops`: تخزين معلومات الورش
5. `employees`: تخزين معلومات الموظفين
6. `inventory_locations`: تخزين معلومات مواقع التخزين
7. `materials`: تخزين معلومات المواد الخام
8. `products`: تخزين معلومات المنتجات
9. `material_inventory`: تتبع مخزون المواد الخام
10. `product_inventory`: تتبع مخزون المنتجات
11. `production_stages`: تخزين معلومات مراحل الإنتاج
12. `production_orders`: تخزين معلومات أوامر الإنتاج
13. `production_items`: تتبع قطع الإنتاج الفردية
14. `item_movement_log`: سجل حركة قطع الإنتاج
15. `inventory_transactions`: سجل حركات المخزون

## الخطوات التالية للتطوير (Next Development Steps)

بناءً على خطة التنفيذ المرحلية، يمكن تطوير النظام بشكل أكبر من خلال:

1. **تطوير واجهة المستخدم**: إنشاء واجهة مستخدم متكاملة للنظام
2. **تكامل المبيعات و CRM**: إضافة وحدات إدارة علاقات العملاء والمبيعات
3. **بوابة العملاء**: تطوير بوابة للعملاء لتتبع طلباتهم
4. **تحليلات متقدمة**: إضافة تقارير وتحليلات متقدمة للإنتاج والمخزون
5. **تكامل الرواتب**: تطوير نظام متكامل لحساب الرواتب بناءً على الإنتاجية

## الدعم والمساعدة (Support and Help)

للحصول على المساعدة أو الإبلاغ عن مشكلات، يرجى التواصل مع:

- البريد الإلكتروني: support@furx.com
- الهاتف: +20 123 456 789
