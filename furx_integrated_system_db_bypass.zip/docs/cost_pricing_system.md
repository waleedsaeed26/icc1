# نظام التكاليف والتسعير (Cost Pricing System)

## نظرة عامة (Overview)

نظام التكاليف والتسعير هو وحدة متكاملة ضمن نظام FURX المتكامل، تم تصميمها لإدارة وحساب تكاليف المنتجات وتسعيرها بدقة. يتيح النظام توزيع التكاليف المباشرة وغير المباشرة على مراكز التكلفة المختلفة (الورش والأقسام)، وحساب تكلفة المنتجات بناءً على مكوناتها وتكاليف التشغيل، وتطبيق قواعد التسعير المختلفة.

The Cost Pricing System is an integrated module within the FURX Integrated System, designed to manage and calculate product costs and pricing accurately. The system allows for the distribution of direct and indirect costs to different cost centers (workshops and departments), calculating product costs based on their components and operational costs, and applying various pricing rules.

## المميزات الرئيسية (Key Features)

- **إدارة مراكز التكلفة**: إنشاء وإدارة مراكز التكلفة المختلفة (الورش والأقسام).
- **إدارة التكاليف الثابتة والمتغيرة**: تسجيل وإدارة التكاليف الثابتة (مثل الإيجارات والرواتب الإدارية) والتكاليف المتغيرة.
- **توزيع التكاليف**: توزيع التكاليف غير المباشرة على مراكز التكلفة بنسب قابلة للتعديل.
- **إدارة تكاليف المواد والعمالة**: تسجيل وإدارة تكاليف المواد الخام والعمالة.
- **قوالب التكلفة**: إنشاء قوالب تكلفة قياسية للمنتجات المتشابهة.
- **حساب تكلفة المنتج**: حساب تكلفة المنتجات بناءً على مكوناتها والتكاليف غير المباشرة.
- **قواعد التسعير**: إنشاء وتطبيق قواعد تسعير مختلفة بناءً على فئة المنتج أو العميل.
- **تقارير التكاليف والربحية**: عرض تقارير مفصلة عن تكاليف المنتجات وربحيتها.

- **Cost Center Management**: Create and manage different cost centers (workshops and departments).
- **Fixed and Variable Cost Management**: Record and manage fixed costs (such as rent and administrative salaries) and variable costs.
- **Cost Distribution**: Distribute indirect costs to cost centers with adjustable percentages.
- **Material and Labor Cost Management**: Record and manage raw material and labor costs.
- **Cost Templates**: Create standard cost templates for similar products.
- **Product Cost Calculation**: Calculate product costs based on their components and indirect costs.
- **Pricing Rules**: Create and apply different pricing rules based on product category or customer.
- **Cost and Profitability Reports**: View detailed reports on product costs and profitability.

## هيكل قاعدة البيانات (Database Structure)

يستخدم النظام الجداول التالية:

1. **cost_centers**: مراكز التكلفة (الورش والأقسام).
2. **fixed_costs**: التكاليف الثابتة (الإيجارات، الرواتب الإدارية، إلخ).
3. **variable_costs**: التكاليف المتغيرة التي تتغير مع حجم الإنتاج.
4. **cost_allocations**: توزيع التكاليف على مراكز التكلفة.
5. **cost_center_period_allocations**: نتائج توزيع التكاليف لكل فترة زمنية.
6. **material_costs**: تكاليف المواد الخام.
7. **labor_costs**: تكاليف العمالة.
8. **operational_costs**: تكاليف التشغيل.
9. **cost_templates**: قوالب التكلفة للمنتجات.
10. **cost_template_components**: مكونات قوالب التكلفة.
11. **product_costs**: تكاليف المنتجات المحسوبة.
12. **product_cost_components**: مكونات تكلفة المنتج.
13. **product_cost_centers**: العلاقة بين المنتجات ومراكز التكلفة.
14. **pricing_rules**: قواعد التسعير.
15. **invoice_costs**: تكاليف الفواتير.
16. **historical_cost_data**: بيانات التكاليف التاريخية.

The system uses the following tables:

1. **cost_centers**: Cost centers (workshops and departments).
2. **fixed_costs**: Fixed costs (rent, administrative salaries, etc.).
3. **variable_costs**: Variable costs that change with production volume.
4. **cost_allocations**: Distribution of costs to cost centers.
5. **cost_center_period_allocations**: Results of cost distribution for each period.
6. **material_costs**: Raw material costs.
7. **labor_costs**: Labor costs.
8. **operational_costs**: Operational costs.
9. **cost_templates**: Cost templates for products.
10. **cost_template_components**: Components of cost templates.
11. **product_costs**: Calculated product costs.
12. **product_cost_components**: Components of product cost.
13. **product_cost_centers**: Relationship between products and cost centers.
14. **pricing_rules**: Pricing rules.
15. **invoice_costs**: Invoice costs.
16. **historical_cost_data**: Historical cost data.

## منطق حساب التكاليف (Cost Calculation Logic)

### توزيع التكاليف غير المباشرة (Indirect Cost Distribution)

1. **تحديد التكاليف الثابتة**: يتم تحديد التكاليف الثابتة (مثل الإيجارات والرواتب الإدارية) للفترة المحددة.
2. **تحديد نسب التوزيع**: يتم تحديد نسب توزيع هذه التكاليف على مراكز التكلفة المختلفة.
3. **حساب التكاليف الموزعة**: يتم حساب التكاليف الموزعة لكل مركز تكلفة بناءً على النسب المحددة.
4. **تخزين النتائج**: يتم تخزين نتائج التوزيع في جدول `cost_center_period_allocations`.

1. **Identify Fixed Costs**: Fixed costs (such as rent and administrative salaries) are identified for the specified period.
2. **Determine Distribution Percentages**: Distribution percentages of these costs to different cost centers are determined.
3. **Calculate Distributed Costs**: Distributed costs for each cost center are calculated based on the specified percentages.
4. **Store Results**: Distribution results are stored in the `cost_center_period_allocations` table.

### حساب تكلفة المنتج (Product Cost Calculation)

1. **تحديد المكونات المباشرة**: يتم تحديد مكونات المنتج المباشرة (المواد، العمالة، التشغيل).
2. **حساب التكاليف المباشرة**: يتم حساب تكلفة كل مكون مع مراعاة نسب الهدر.
3. **تحديد مراكز التكلفة**: يتم تحديد مراكز التكلفة المرتبطة بالمنتج.
4. **تخصيص التكاليف غير المباشرة**: يتم تخصيص جزء من التكاليف غير المباشرة للمنتج بناءً على مراكز التكلفة المرتبطة به.
5. **حساب التكلفة الإجمالية**: يتم حساب التكلفة الإجمالية للمنتج بجمع التكاليف المباشرة وغير المباشرة.
6. **تخزين النتائج**: يتم تخزين نتائج الحساب في جدول `product_costs`.

1. **Identify Direct Components**: Direct components of the product (materials, labor, operations) are identified.
2. **Calculate Direct Costs**: The cost of each component is calculated, taking into account wastage percentages.
3. **Identify Cost Centers**: Cost centers associated with the product are identified.
4. **Allocate Indirect Costs**: A portion of indirect costs is allocated to the product based on its associated cost centers.
5. **Calculate Total Cost**: The total cost of the product is calculated by adding direct and indirect costs.
6. **Store Results**: Calculation results are stored in the `product_costs` table.

### تطبيق قواعد التسعير (Applying Pricing Rules)

1. **تحديد قواعد التسعير**: يتم تحديد قواعد التسعير المنطبقة على المنتج بناءً على فئة المنتج وفئة العميل.
2. **ترتيب القواعد**: يتم ترتيب القواعد حسب الأولوية.
3. **تطبيق القاعدة**: يتم تطبيق القاعدة ذات الأولوية الأعلى لحساب سعر البيع.
4. **التحقق من هامش الربح**: يتم التحقق من أن هامش الربح لا يقل عن الحد الأدنى المحدد.

1. **Identify Pricing Rules**: Pricing rules applicable to the product are identified based on product category and customer category.
2. **Sort Rules**: Rules are sorted by priority.
3. **Apply Rule**: The highest priority rule is applied to calculate the selling price.
4. **Verify Profit Margin**: It is verified that the profit margin is not less than the specified minimum.

## واجهات برمجة التطبيقات (APIs)

### مراكز التكلفة (Cost Centers)

- `GET /api/cost-centers`: الحصول على جميع مراكز التكلفة.
- `GET /api/cost-centers/:id`: الحصول على مركز تكلفة محدد.
- `POST /api/cost-centers`: إنشاء مركز تكلفة جديد.
- `PUT /api/cost-centers/:id`: تحديث مركز تكلفة.
- `DELETE /api/cost-centers/:id`: حذف مركز تكلفة.

### توزيع التكاليف (Cost Allocations)

- `POST /api/cost-calculations/distribute`: توزيع التكاليف غير المباشرة على مراكز التكلفة.
- `GET /api/cost-calculations/allocations`: الحصول على توزيعات التكاليف لفترة محددة.
- `GET /api/cost-calculations/allocations/:costCenterId`: الحصول على توزيعات التكاليف لمركز تكلفة محدد.

### تكاليف المنتجات (Product Costs)

- `GET /api/product-costs`: الحصول على جميع تكاليف المنتجات.
- `GET /api/product-costs/:id`: الحصول على تكلفة منتج محدد.
- `GET /api/product-costs/product/:productId`: الحصول على تكلفة منتج بواسطة معرف المنتج.
- `POST /api/product-costs/calculate/:productId`: حساب تكلفة منتج.
- `POST /api/product-costs`: إنشاء تكلفة منتج يدوياً.
- `PUT /api/product-costs/:id`: تحديث تكلفة منتج.
- `DELETE /api/product-costs/:id`: حذف تكلفة منتج.

### قواعد التسعير (Pricing Rules)

- `GET /api/pricing-rules`: الحصول على جميع قواعد التسعير.
- `GET /api/pricing-rules/:id`: الحصول على قاعدة تسعير محددة.
- `POST /api/pricing-rules`: إنشاء قاعدة تسعير جديدة.
- `PUT /api/pricing-rules/:id`: تحديث قاعدة تسعير.
- `DELETE /api/pricing-rules/:id`: حذف قاعدة تسعير.

## التقارير (Reports)

النظام يوفر التقارير التالية:

1. **تقرير تكلفة المنتج**: يعرض تفاصيل تكلفة كل منتج (مواد، عمالة، تكاليف غير مباشرة موزعة).
2. **تقرير تحليل ربحية المنتج**: يوضح سعر البيع، التكلفة الإجمالية، وهامش الربح لكل منتج.
3. **تقرير ربحية الفواتير**: يلخص التكاليف، الإيرادات، والأرباح لكل فاتورة.
4. **تقرير ملخص التكاليف حسب مركز التكلفة**: يعرض التكاليف المباشرة وغير المباشرة المخصصة لكل ورشة أو قسم.
5. **تقرير ملخص الأرباح حسب الفترة**: يعرض إجمالي الإيرادات والتكاليف والأرباح لفترات زمنية محددة (شهري، ربع سنوي، سنوي).

The system provides the following reports:

1. **Product Cost Report**: Shows details of each product's cost (materials, labor, distributed indirect costs).
2. **Product Profitability Analysis Report**: Shows selling price, total cost, and profit margin for each product.
3. **Invoice Profitability Report**: Summarizes costs, revenues, and profits for each invoice.
4. **Cost Summary by Cost Center Report**: Shows direct and indirect costs allocated to each workshop or department.
5. **Profit Summary by Period Report**: Shows total revenues, costs, and profits for specific time periods (monthly, quarterly, annual).

## كيفية الاستخدام (How to Use)

### إعداد النظام (System Setup)

1. **إنشاء مراكز التكلفة**: قم بإنشاء مراكز التكلفة (الورش والأقسام) التي ستستخدم في توزيع التكاليف.
2. **إدخال التكاليف الثابتة**: قم بإدخال التكاليف الثابتة مثل الإيجارات والرواتب الإدارية.
3. **تحديد نسب التوزيع**: قم بتحديد نسب توزيع التكاليف الثابتة على مراكز التكلفة.
4. **إدخال تكاليف المواد والعمالة**: قم بإدخال تكاليف المواد الخام والعمالة.
5. **إنشاء قوالب التكلفة**: قم بإنشاء قوالب تكلفة للمنتجات المتشابهة.
6. **إنشاء قواعد التسعير**: قم بإنشاء قواعد التسعير المختلفة.

1. **Create Cost Centers**: Create cost centers (workshops and departments) that will be used in cost distribution.
2. **Enter Fixed Costs**: Enter fixed costs such as rent and administrative salaries.
3. **Determine Distribution Percentages**: Determine the percentages for distributing fixed costs to cost centers.
4. **Enter Material and Labor Costs**: Enter raw material and labor costs.
5. **Create Cost Templates**: Create cost templates for similar products.
6. **Create Pricing Rules**: Create different pricing rules.

### العمليات اليومية (Daily Operations)

1. **توزيع التكاليف**: قم بتشغيل عملية توزيع التكاليف في نهاية كل فترة (شهر، ربع سنة).
2. **حساب تكاليف المنتجات**: قم بحساب تكاليف المنتجات الجديدة أو تحديث تكاليف المنتجات الحالية.
3. **تطبيق قواعد التسعير**: قم بتطبيق قواعد التسعير المناسبة على المنتجات.
4. **مراجعة التقارير**: قم بمراجعة تقارير التكاليف والربحية بانتظام.

1. **Distribute Costs**: Run the cost distribution process at the end of each period (month, quarter).
2. **Calculate Product Costs**: Calculate costs for new products or update costs for existing products.
3. **Apply Pricing Rules**: Apply appropriate pricing rules to products.
4. **Review Reports**: Regularly review cost and profitability reports.

## التكامل مع الأنظمة الأخرى (Integration with Other Systems)

يتكامل نظام التكاليف والتسعير مع الأنظمة الأخرى في نظام FURX المتكامل:

- **نظام المخزون**: يستخدم بيانات المواد الخام وأسعارها.
- **نظام الموارد البشرية**: يستخدم بيانات العمال وتكاليف العمالة.
- **نظام الإنتاج**: يستخدم بيانات المنتجات ومكوناتها.
- **نظام المبيعات**: يوفر أسعار البيع للمنتجات.
- **النظام المالي**: يوفر بيانات التكاليف للتحليل المالي.

The Cost Pricing System integrates with other systems in the FURX Integrated System:

- **Inventory System**: Uses raw material data and prices.
- **HR System**: Uses worker data and labor costs.
- **Production System**: Uses product data and components.
- **Sales System**: Provides selling prices for products.
- **Financial System**: Provides cost data for financial analysis.

## الاستنتاج (Conclusion)

نظام التكاليف والتسعير هو أداة قوية لإدارة تكاليف المنتجات وتسعيرها بدقة. يوفر النظام رؤية شاملة لتكاليف الإنتاج ويساعد في اتخاذ قرارات التسعير المناسبة. من خلال توزيع التكاليف بدقة وحساب تكاليف المنتجات بشكل صحيح، يمكن للشركة تحسين ربحيتها وتنافسيتها في السوق.

The Cost Pricing System is a powerful tool for managing product costs and pricing accurately. The system provides a comprehensive view of production costs and helps in making appropriate pricing decisions. By accurately distributing costs and correctly calculating product costs, the company can improve its profitability and competitiveness in the market.
