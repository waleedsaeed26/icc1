const db = require('../config/database');

/**
 * Database setup script
 * Creates all necessary tables for the FURX integrated system
 * Supports multi-company structure
 */
async function setupDatabase() {
  try {
    // Start transaction
    await db.query('BEGIN');

    // Create companies table
    await db.query(`
      CREATE TABLE IF NOT EXISTS companies (
        company_id SERIAL PRIMARY KEY,
        company_name VARCHAR(100) NOT NULL,
        company_code VARCHAR(20) UNIQUE NOT NULL,
        parent_company_id INTEGER REFERENCES companies(company_id),
        description TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP
      )
    `);

    // Create departments table
    await db.query(`
      CREATE TABLE IF NOT EXISTS departments (
        department_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        department_name VARCHAR(100) NOT NULL,
        description TEXT,
        manager_id INTEGER,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP
      )
    `);

    // Create production_lines table
    await db.query(`
      CREATE TABLE IF NOT EXISTS production_lines (
        production_line_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        line_name VARCHAR(100) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP
      )
    `);

    // Create workshops table
    await db.query(`
      CREATE TABLE IF NOT EXISTS workshops (
        workshop_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        workshop_name VARCHAR(100) NOT NULL,
        production_line_id INTEGER REFERENCES production_lines(production_line_id),
        description TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP
      )
    `);

    // Create employees table
    await db.query(`
      CREATE TABLE IF NOT EXISTS employees (
        employee_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        first_name VARCHAR(50) NOT NULL,
        last_name VARCHAR(50) NOT NULL,
        national_id VARCHAR(20) UNIQUE,
        hire_date DATE,
        job_title VARCHAR(100),
        department_id INTEGER REFERENCES departments(department_id),
        production_line_id INTEGER REFERENCES production_lines(production_line_id),
        workshop_id INTEGER REFERENCES workshops(workshop_id),
        contact_info JSONB,
        salary_type VARCHAR(20),
        base_salary_rate DECIMAL(10,2),
        is_active BOOLEAN DEFAULT TRUE,
        user_id INTEGER,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP
      )
    `);

    // Add foreign key constraint for manager_id in departments
    await db.query(`
      ALTER TABLE departments 
      ADD CONSTRAINT fk_department_manager 
      FOREIGN KEY (manager_id) REFERENCES employees(employee_id)
    `);

    // Create inventory_locations table
    await db.query(`
      CREATE TABLE IF NOT EXISTS inventory_locations (
        location_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        location_name VARCHAR(100) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP
      )
    `);

    // Create materials table
    await db.query(`
      CREATE TABLE IF NOT EXISTS materials (
        material_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        material_code VARCHAR(50) NOT NULL,
        material_name VARCHAR(100) NOT NULL,
        description TEXT,
        unit_of_measure VARCHAR(20),
        standard_cost DECIMAL(10,2),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP,
        UNIQUE(company_id, material_code)
      )
    `);

    // Create products table
    await db.query(`
      CREATE TABLE IF NOT EXISTS products (
        product_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        product_sku VARCHAR(50) NOT NULL,
        product_name VARCHAR(100) NOT NULL,
        description TEXT,
        category VARCHAR(50),
        standard_price DECIMAL(10,2),
        standard_production_time_hours DECIMAL(10,2),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP,
        UNIQUE(company_id, product_sku)
      )
    `);

    // Create material_inventory table
    await db.query(`
      CREATE TABLE IF NOT EXISTS material_inventory (
        inventory_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        material_id INTEGER NOT NULL REFERENCES materials(material_id),
        location_id INTEGER NOT NULL REFERENCES inventory_locations(location_id),
        quantity_on_hand DECIMAL(10,2) DEFAULT 0,
        last_updated_at TIMESTAMP DEFAULT NOW(),
        UNIQUE(company_id, material_id, location_id)
      )
    `);

    // Create product_inventory table
    await db.query(`
      CREATE TABLE IF NOT EXISTS product_inventory (
        inventory_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        product_id INTEGER NOT NULL REFERENCES products(product_id),
        location_id INTEGER NOT NULL REFERENCES inventory_locations(location_id),
        quantity_on_hand INTEGER DEFAULT 0,
        last_updated_at TIMESTAMP DEFAULT NOW(),
        UNIQUE(company_id, product_id, location_id)
      )
    `);

    // Create production_stages table
    await db.query(`
      CREATE TABLE IF NOT EXISTS production_stages (
        stage_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        stage_name VARCHAR(100) NOT NULL,
        sequence_order INTEGER,
        workshop_id INTEGER REFERENCES workshops(workshop_id),
        description TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP
      )
    `);

    // Create production_orders table
    await db.query(`
      CREATE TABLE IF NOT EXISTS production_orders (
        production_order_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        order_number VARCHAR(50) NOT NULL,
        product_id INTEGER NOT NULL REFERENCES products(product_id),
        quantity_to_produce INTEGER NOT NULL,
        order_type VARCHAR(30),
        status VARCHAR(30),
        planned_start_date DATE,
        planned_end_date DATE,
        actual_start_date DATE,
        actual_end_date DATE,
        customization_details TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP,
        UNIQUE(company_id, order_number)
      )
    `);

    // Create production_items table
    await db.query(`
      CREATE TABLE IF NOT EXISTS production_items (
        item_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        production_order_id INTEGER NOT NULL REFERENCES production_orders(production_order_id),
        item_qr_code VARCHAR(100) UNIQUE NOT NULL,
        current_stage_id INTEGER REFERENCES production_stages(stage_id),
        current_location_id INTEGER REFERENCES inventory_locations(location_id),
        status VARCHAR(30),
        completion_percentage INTEGER DEFAULT 0,
        notes TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP
      )
    `);

    // Create item_movement_log table
    await db.query(`
      CREATE TABLE IF NOT EXISTS item_movement_log (
        log_id SERIAL PRIMARY KEY,
        production_item_id INTEGER NOT NULL REFERENCES production_items(item_id),
        from_stage_id INTEGER REFERENCES production_stages(stage_id),
        to_stage_id INTEGER REFERENCES production_stages(stage_id),
        from_location_id INTEGER REFERENCES inventory_locations(location_id),
        to_location_id INTEGER REFERENCES inventory_locations(location_id),
        moved_by INTEGER REFERENCES employees(employee_id),
        moved_at TIMESTAMP DEFAULT NOW(),
        notes TEXT
      )
    `);

    // Create inventory_transactions table
    await db.query(`
      CREATE TABLE IF NOT EXISTS inventory_transactions (
        transaction_id SERIAL PRIMARY KEY,
        company_id INTEGER NOT NULL REFERENCES companies(company_id),
        material_id INTEGER REFERENCES materials(material_id),
        product_id INTEGER REFERENCES products(product_id),
        transaction_type VARCHAR(30) NOT NULL,
        quantity DECIMAL(10,2) NOT NULL,
        location_id INTEGER NOT NULL REFERENCES inventory_locations(location_id),
        related_document_id VARCHAR(50),
        employee_id INTEGER REFERENCES employees(employee_id),
        transaction_datetime TIMESTAMP DEFAULT NOW()
      )
    `);

    // Insert initial data - ICC as parent company
    await db.query(`
      INSERT INTO companies (company_name, company_code, description, is_active)
      VALUES ('ICC', 'ICC', 'Parent company', TRUE)
      ON CONFLICT (company_code) DO NOTHING
    `);

    // Get ICC company ID
    const iccResult = await db.query(`SELECT company_id FROM companies WHERE company_code = 'ICC'`);
    const iccId = iccResult.rows[0].company_id;

    // Insert child companies
    await db.query(`
      INSERT INTO companies (company_name, company_code, parent_company_id, description, is_active)
      VALUES 
        ('FURX', 'FURX', $1, 'Manufacturing company', TRUE),
        ('NOAH', 'NOAH', $1, 'Retail company with two showrooms', TRUE),
        ('ADAM''S', 'ADAMS', $1, 'Retail company with one showroom', TRUE)
      ON CONFLICT (company_code) DO NOTHING
    `, [iccId]);

    // Commit transaction
    await db.query('COMMIT');
    
    console.log('Database setup completed successfully');
    return true;
  } catch (error) {
    // Rollback transaction in case of error
    await db.query('ROLLBACK');
    console.error('Database setup failed:', error);
    throw error;
  }
}

module.exports = setupDatabase;
