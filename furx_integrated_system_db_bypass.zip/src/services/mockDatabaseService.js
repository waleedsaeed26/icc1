// Mock Database Service for Cost Pricing Module
// This service uses JSON files as a mock database when PostgreSQL is not available

const fs = require('fs');
const path = require('path');

// Path to test data directory
const TEST_DATA_DIR = '/home/ubuntu/test_data';

// Cache for loaded data
const dataCache = {};

/**
 * Load data from JSON file
 * @param {string} fileName - Name of the JSON file without extension
 * @returns {Array} Array of objects from the JSON file
 */
const loadJsonData = (fileName) => {
  if (dataCache[fileName]) {
    return dataCache[fileName];
  }

  try {
    const filePath = path.join(TEST_DATA_DIR, `${fileName}.json`);
    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    dataCache[fileName] = data;
    return data;
  } catch (error) {
    console.error(`Error loading ${fileName}.json:`, error);
    return [];
  }
};

/**
 * Save data to JSON file
 * @param {string} fileName - Name of the JSON file without extension
 * @param {Array} data - Array of objects to save
 * @returns {boolean} Success status
 */
const saveJsonData = (fileName, data) => {
  try {
    const filePath = path.join(TEST_DATA_DIR, `${fileName}.json`);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    dataCache[fileName] = data;
    return true;
  } catch (error) {
    console.error(`Error saving ${fileName}.json:`, error);
    return false;
  }
};

/**
 * Get all records from a collection
 * @param {string} collection - Collection name (JSON file name without extension)
 * @param {Object} filter - Filter criteria
 * @returns {Array} Filtered array of objects
 */
const getAll = (collection, filter = {}) => {
  const data = loadJsonData(collection);
  
  if (Object.keys(filter).length === 0) {
    return data;
  }
  
  return data.filter(item => {
    for (const key in filter) {
      if (item[key] !== filter[key]) {
        return false;
      }
    }
    return true;
  });
};

/**
 * Get a record by ID from a collection
 * @param {string} collection - Collection name (JSON file name without extension)
 * @param {number} id - Record ID
 * @returns {Object|null} Found object or null
 */
const getById = (collection, id) => {
  const data = loadJsonData(collection);
  return data.find(item => item.id === id) || null;
};

/**
 * Create a new record in a collection
 * @param {string} collection - Collection name (JSON file name without extension)
 * @param {Object} record - Record to create
 * @returns {Object} Created record with ID
 */
const create = (collection, record) => {
  const data = loadJsonData(collection);
  
  // Generate a new ID
  const newId = data.length > 0 ? Math.max(...data.map(item => item.id)) + 1 : 1;
  
  // Add timestamps
  const now = new Date().toISOString();
  const newRecord = {
    ...record,
    id: newId,
    created_at: now,
    updated_at: now
  };
  
  data.push(newRecord);
  saveJsonData(collection, data);
  
  return newRecord;
};

/**
 * Update a record in a collection
 * @param {string} collection - Collection name (JSON file name without extension)
 * @param {number} id - Record ID
 * @param {Object} updates - Fields to update
 * @returns {Object|null} Updated record or null
 */
const update = (collection, id, updates) => {
  const data = loadJsonData(collection);
  const index = data.findIndex(item => item.id === id);
  
  if (index === -1) {
    return null;
  }
  
  // Update the record
  const updatedRecord = {
    ...data[index],
    ...updates,
    updated_at: new Date().toISOString()
  };
  
  data[index] = updatedRecord;
  saveJsonData(collection, data);
  
  return updatedRecord;
};

/**
 * Delete a record from a collection
 * @param {string} collection - Collection name (JSON file name without extension)
 * @param {number} id - Record ID
 * @returns {boolean} Success status
 */
const remove = (collection, id) => {
  const data = loadJsonData(collection);
  const index = data.findIndex(item => item.id === id);
  
  if (index === -1) {
    return false;
  }
  
  data.splice(index, 1);
  return saveJsonData(collection, data);
};

/**
 * Distribute indirect costs to cost centers
 * @param {number} companyId - Company ID
 * @param {string} periodStartDate - Period start date (YYYY-MM-DD)
 * @param {string} periodEndDate - Period end date (YYYY-MM-DD)
 * @returns {Object} Distribution results
 */
const distributeIndirectCosts = async (companyId, periodStartDate, periodEndDate) => {
  try {
    // Load required data
    const costCenters = loadJsonData('cost_centers').filter(cc => cc.company_id === companyId);
    const fixedCosts = loadJsonData('fixed_costs').filter(fc => fc.company_id === companyId);
    const operationalCosts = loadJsonData('operational_costs').filter(oc => oc.company_id === companyId);
    const costAllocations = loadJsonData('cost_allocations').filter(ca => ca.company_id === companyId);
    
    // Initialize results array
    const allocations = [];
    
    // Process each cost center
    for (const center of costCenters) {
      let totalFixedCost = 0;
      let totalOperationalCost = 0;
      
      // Calculate fixed costs allocated to this center
      for (const fixedCost of fixedCosts) {
        const allocation = costAllocations.find(ca => 
          ca.cost_center_id === center.department_id && 
          ca.cost_type === 'fixed' && 
          ca.cost_id === fixedCost.id
        );
        
        if (allocation) {
          const allocatedAmount = fixedCost.amount * (allocation.allocation_percentage / 100);
          totalFixedCost += allocatedAmount;
        }
      }
      
      // Calculate operational costs for this center
      const centerOperationalCosts = operationalCosts.filter(oc => oc.cost_center_id === center.department_id);
      for (const opCost of centerOperationalCosts) {
        totalOperationalCost += opCost.amount;
      }
      
      // Create allocation records
      const fixedCostAllocation = {
        id: allocations.length + 1,
        company_id: companyId,
        cost_center_id: center.department_id,
        period_start_date: periodStartDate,
        period_end_date: periodEndDate,
        cost_type: 'fixed',
        allocated_amount: totalFixedCost,
        allocation_basis: 'percentage',
        calculation_date: new Date().toISOString(),
        notes: `Fixed costs allocated to ${center.center_name}`
      };
      
      const operationalCostAllocation = {
        id: allocations.length + 2,
        company_id: companyId,
        cost_center_id: center.department_id,
        period_start_date: periodStartDate,
        period_end_date: periodEndDate,
        cost_type: 'operational',
        allocated_amount: totalOperationalCost,
        allocation_basis: 'direct',
        calculation_date: new Date().toISOString(),
        notes: `Operational costs allocated to ${center.center_name}`
      };
      
      const totalOverheadAllocation = {
        id: allocations.length + 3,
        company_id: companyId,
        cost_center_id: center.department_id,
        period_start_date: periodStartDate,
        period_end_date: periodEndDate,
        cost_type: 'total_overhead',
        allocated_amount: totalFixedCost + totalOperationalCost,
        allocation_basis: 'combined',
        calculation_date: new Date().toISOString(),
        notes: `Total overhead costs allocated to ${center.center_name}`
      };
      
      allocations.push(fixedCostAllocation, operationalCostAllocation, totalOverheadAllocation);
    }
    
    // Save the allocations
    const existingAllocations = loadJsonData('cost_center_period_allocations') || [];
    const newAllocations = [...existingAllocations, ...allocations];
    saveJsonData('cost_center_period_allocations', newAllocations);
    
    return {
      success: true,
      message: `Successfully distributed costs for period ${periodStartDate} to ${periodEndDate}`,
      allocations_count: allocations.length,
      cost_centers_processed: costCenters.length
    };
  } catch (error) {
    console.error('Error in distributeIndirectCosts:', error);
    return {
      success: false,
      message: `Failed to distribute costs: ${error.message}`
    };
  }
};

/**
 * Calculate product cost
 * @param {number} companyId - Company ID
 * @param {number} productId - Product ID
 * @param {string} periodStartDate - Period start date (YYYY-MM-DD)
 * @param {string} periodEndDate - Period end date (YYYY-MM-DD)
 * @returns {Object} Calculation results
 */
const calculateProductCost = async (companyId, productId, periodStartDate, periodEndDate) => {
  try {
    // Load required data
    const products = loadJsonData('products').filter(p => p.company_id === companyId);
    const product = products.find(p => p.id === productId);
    
    if (!product) {
      throw new Error(`Product with ID ${productId} not found`);
    }
    
    // For demonstration, we'll use random values for material, labor, and operational costs
    const materialCost = Math.random() * 1000 + 500; // Between 500 and 1500
    const laborCost = Math.random() * 800 + 200; // Between 200 and 1000
    const operationalCost = Math.random() * 500 + 100; // Between 100 and 600
    
    // Get cost center allocations for the period
    const allocations = loadJsonData('cost_center_period_allocations').filter(a => 
      a.company_id === companyId && 
      a.period_start_date === periodStartDate && 
      a.period_end_date === periodEndDate &&
      a.cost_type === 'total_overhead'
    );
    
    // Calculate overhead cost (simplified approach)
    let overheadCost = 0;
    if (allocations.length > 0) {
      // Assume the product is associated with the first cost center
      overheadCost = allocations[0].allocated_amount * 0.1; // Allocate 10% of the overhead
    }
    
    // Calculate total cost
    const totalCost = materialCost + laborCost + operationalCost + overheadCost;
    
    // Create or update product cost record
    const productCosts = loadJsonData('product_costs') || [];
    const existingCostIndex = productCosts.findIndex(pc => pc.product_id === productId);
    
    const productCost = {
      company_id: companyId,
      product_id: productId,
      total_material_cost: materialCost,
      total_labor_cost: laborCost,
      total_operational_cost: operationalCost,
      total_overhead_cost: overheadCost,
      total_cost: totalCost,
      calculation_date: new Date().toISOString(),
      notes: `Cost calculated for ${product.product_code || product.noah_name || 'product'}`
    };
    
    if (existingCostIndex >= 0) {
      productCost.id = productCosts[existingCostIndex].id;
      productCosts[existingCostIndex] = productCost;
    } else {
      productCost.id = productCosts.length > 0 ? Math.max(...productCosts.map(pc => pc.id)) + 1 : 1;
      productCosts.push(productCost);
    }
    
    saveJsonData('product_costs', productCosts);
    
    return {
      success: true,
      product_cost: productCost,
      details: {
        material_cost: materialCost,
        labor_cost: laborCost,
        operational_cost: operationalCost,
        overhead_cost: overheadCost,
        total_cost: totalCost
      }
    };
  } catch (error) {
    console.error('Error in calculateProductCost:', error);
    return {
      success: false,
      message: `Failed to calculate product cost: ${error.message}`
    };
  }
};

module.exports = {
  getAll,
  getById,
  create,
  update,
  remove,
  distributeIndirectCosts,
  calculateProductCost
};
