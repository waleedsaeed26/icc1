// Modified Product Cost Calculation Service to use Mock Database Service
const mockDb = require('../services/mockDatabaseService');

/**
 * Service to calculate product costs based on cost center allocations
 */
class ProductCostCalculationService {
  /**
   * Calculate the cost of a product based on its components and allocated overhead costs
   * @param {number} companyId - The company ID
   * @param {number} productId - The product ID
   * @param {string} periodStartDate - The start date of the period (YYYY-MM-DD)
   * @param {string} periodEndDate - The end date of the period (YYYY-MM-DD)
   * @returns {Object} The calculated product cost details
   */
  async calculateProductCost(companyId, productId, periodStartDate, periodEndDate) {
    return mockDb.calculateProductCost(companyId, productId, periodStartDate, periodEndDate);
  }
}

module.exports = new ProductCostCalculationService();
