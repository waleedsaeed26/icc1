// Modified Cost Calculation Service to use Mock Database Service
const mockDb = require('../services/mockDatabaseService');

/**
 * Service for cost calculations and distributions
 */
class CostCalculationService {
  /**
   * Distribute indirect costs to cost centers for a given period
   * @param {number} companyId - Company ID
   * @param {string} periodStartDate - Period start date (YYYY-MM-DD)
   * @param {string} periodEndDate - Period end date (YYYY-MM-DD)
   * @returns {Object} Distribution results
   */
  async distributeIndirectCosts(companyId, periodStartDate, periodEndDate) {
    return mockDb.distributeIndirectCosts(companyId, periodStartDate, periodEndDate);
  }

  /**
   * Get cost allocations for a given period
   * @param {number} companyId - Company ID
   * @param {string} periodStartDate - Period start date (YYYY-MM-DD)
   * @param {string} periodEndDate - Period end date (YYYY-MM-DD)
   * @returns {Array} Array of cost allocations
   */
  async getAllocationsByPeriod(companyId, periodStartDate, periodEndDate) {
    return mockDb.getAll('cost_center_period_allocations', {
      company_id: companyId,
      period_start_date: periodStartDate,
      period_end_date: periodEndDate
    });
  }

  /**
   * Get cost allocations for a specific cost center in a given period
   * @param {number} costCenterId - Cost center ID
   * @param {string} periodStartDate - Period start date (YYYY-MM-DD)
   * @param {string} periodEndDate - Period end date (YYYY-MM-DD)
   * @returns {Array} Array of cost allocations
   */
  async getAllocationsByCostCenterAndPeriod(costCenterId, periodStartDate, periodEndDate) {
    return mockDb.getAll('cost_center_period_allocations', {
      cost_center_id: costCenterId,
      period_start_date: periodStartDate,
      period_end_date: periodEndDate
    });
  }
}

module.exports = new CostCalculationService();
