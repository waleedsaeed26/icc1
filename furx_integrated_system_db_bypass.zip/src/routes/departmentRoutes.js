const express = require('express');
const router = express.Router();
const Department = require('../models/department');

// Middleware to check for company ID in query or body
const checkCompanyId = (req, res, next) => {
  const companyId = req.query.company_id || req.body.company_id;
  if (!companyId) {
    return res.status(400).json({
      success: false,
      message: 'Company ID is required'
    });
  }
  req.companyId = parseInt(companyId, 10);
  next();
};

// Get all departments for a specific company
router.get('/', checkCompanyId, async (req, res, next) => {
  try {
    const departments = await Department.getAllByCompany(req.companyId);
    res.json({
      success: true,
      data: departments
    });
  } catch (error) {
    next(error);
  }
});

// Get department by ID
router.get('/:id', async (req, res, next) => {
  try {
    const department = await Department.getById(req.params.id);
    if (!department) {
      return res.status(404).json({
        success: false,
        message: 'Department not found'
      });
    }
    res.json({
      success: true,
      data: department
    });
  } catch (error) {
    next(error);
  }
});

// Create new department
router.post('/', checkCompanyId, async (req, res, next) => {
  try {
    // Ensure company_id from middleware is used
    const departmentData = { ...req.body, company_id: req.companyId };
    const department = await Department.create(departmentData);
    res.status(201).json({
      success: true,
      data: department
    });
  } catch (error) {
    next(error);
  }
});

// Update department
router.put('/:id', checkCompanyId, async (req, res, next) => {
  try {
    // Ensure company_id from middleware is used for update context
    const existingDepartment = await Department.getById(req.params.id);
    if (!existingDepartment) {
      return res.status(404).json({
        success: false,
        message: 'Department not found'
      });
    }
    
    const departmentData = { ...req.body, company_id: req.companyId };
    const department = await Department.update(req.params.id, departmentData);
    
    res.json({
      success: true,
      data: department
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
