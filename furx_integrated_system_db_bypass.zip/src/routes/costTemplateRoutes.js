const express = require('express');
const router = express.Router();
const CostTemplate = require('../models/costTemplate');
const { authenticateToken, authorizeCompanyAccess } = require('../middleware/auth');

/**
 * @route   GET /api/cost-templates
 * @desc    Get all cost templates for a company
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const activeOnly = req.query.active_only !== 'false';
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const templates = await CostTemplate.getAllByCompany(companyId, activeOnly);
    res.json(templates);
  } catch (error) {
    console.error('Error fetching cost templates:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/cost-templates/:id
 * @desc    Get a cost template by ID
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const template = await CostTemplate.getById(req.params.id);
    
    if (!template) {
      return res.status(404).json({ message: 'Cost template not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, template.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    res.json(template);
  } catch (error) {
    console.error('Error fetching cost template:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/cost-templates/:id/items
 * @desc    Get all items for a cost template
 * @access  Private
 */
router.get('/:id/items', authenticateToken, async (req, res) => {
  try {
    const template = await CostTemplate.getById(req.params.id);
    
    if (!template) {
      return res.status(404).json({ message: 'Cost template not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, template.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const items = await CostTemplate.getAllItems(req.params.id);
    res.json(items);
  } catch (error) {
    console.error('Error fetching cost template items:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/cost-templates/default/:companyId
 * @desc    Get the default cost template for a company
 * @access  Private
 */
router.get('/default/:companyId', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.params.companyId);
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const defaultTemplate = await CostTemplate.getDefault(companyId);
    
    if (!defaultTemplate) {
      return res.status(404).json({ message: 'No default cost template found' });
    }
    
    res.json(defaultTemplate);
  } catch (error) {
    console.error('Error fetching default cost template:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/cost-templates
 * @desc    Create a new cost template
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { 
      company_id, 
      template_name, 
      product_category, 
      is_default, 
      is_active, 
      notes 
    } = req.body;
    
    if (!company_id || !template_name) {
      return res.status(400).json({ 
        message: 'Company ID and template name are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const template = await CostTemplate.create({
      company_id,
      template_name,
      product_category,
      is_default,
      is_active,
      notes
    });
    
    res.status(201).json(template);
  } catch (error) {
    console.error('Error creating cost template:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/cost-templates/:id
 * @desc    Update a cost template
 * @access  Private
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { 
      template_name, 
      product_category, 
      is_default, 
      is_active, 
      notes 
    } = req.body;
    
    // Get existing template to check company access
    const existingTemplate = await CostTemplate.getById(req.params.id);
    
    if (!existingTemplate) {
      return res.status(404).json({ message: 'Cost template not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingTemplate.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const updatedTemplate = await CostTemplate.update(req.params.id, {
      template_name,
      product_category,
      is_default,
      is_active,
      notes
    });
    
    res.json(updatedTemplate);
  } catch (error) {
    console.error('Error updating cost template:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/cost-templates/:id
 * @desc    Delete a cost template
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Get existing template to check company access
    const existingTemplate = await CostTemplate.getById(req.params.id);
    
    if (!existingTemplate) {
      return res.status(404).json({ message: 'Cost template not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingTemplate.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await CostTemplate.delete(req.params.id);
    
    if (success) {
      res.json({ message: 'Cost template deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete cost template' });
    }
  } catch (error) {
    console.error('Error deleting cost template:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/cost-templates/:id/items
 * @desc    Add an item to a cost template
 * @access  Private
 */
router.post('/:id/items', authenticateToken, async (req, res) => {
  try {
    const templateId = parseInt(req.params.id);
    const { cost_type, cost_id, allocation_percentage, notes } = req.body;
    
    if (!cost_type || !cost_id) {
      return res.status(400).json({ 
        message: 'Cost type and cost ID are required' 
      });
    }
    
    // Get existing template to check company access
    const existingTemplate = await CostTemplate.getById(templateId);
    
    if (!existingTemplate) {
      return res.status(404).json({ message: 'Cost template not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingTemplate.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const item = await CostTemplate.addItem({
      template_id: templateId,
      cost_type,
      cost_id,
      allocation_percentage,
      notes
    });
    
    res.status(201).json(item);
  } catch (error) {
    console.error('Error adding item to cost template:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/cost-templates/items/:itemId
 * @desc    Update a template item
 * @access  Private
 */
router.put('/items/:itemId', authenticateToken, async (req, res) => {
  try {
    const itemId = parseInt(req.params.itemId);
    const { cost_type, cost_id, allocation_percentage, notes } = req.body;
    
    // Get the item to get the template ID
    const items = await CostTemplate.getAllItems(null); // This is not ideal, but we need to get the item first
    const item = items.find(i => i.id === itemId);
    
    if (!item) {
      return res.status(404).json({ message: 'Template item not found' });
    }
    
    // Get the template to check company access
    const template = await CostTemplate.getById(item.template_id);
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, template.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const updatedItem = await CostTemplate.updateItem(itemId, {
      cost_type,
      cost_id,
      allocation_percentage,
      notes
    });
    
    res.json(updatedItem);
  } catch (error) {
    console.error('Error updating template item:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/cost-templates/items/:itemId
 * @desc    Delete a template item
 * @access  Private
 */
router.delete('/items/:itemId', authenticateToken, async (req, res) => {
  try {
    const itemId = parseInt(req.params.itemId);
    
    // Get the item to get the template ID
    const items = await CostTemplate.getAllItems(null); // This is not ideal, but we need to get the item first
    const item = items.find(i => i.id === itemId);
    
    if (!item) {
      return res.status(404).json({ message: 'Template item not found' });
    }
    
    // Get the template to check company access
    const template = await CostTemplate.getById(item.template_id);
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, template.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await CostTemplate.deleteItem(itemId);
    
    if (success) {
      res.json({ message: 'Template item deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete template item' });
    }
  } catch (error) {
    console.error('Error deleting template item:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
