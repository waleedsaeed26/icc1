const express = require('express');
const router = express.Router();
const FixedCost = require('../models/fixedCost');
const { authenticateToken, authorizeCompanyAccess } = require('../middleware/auth');

/**
 * @route   GET /api/fixed-costs
 * @desc    Get all fixed costs for a company
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const activeOnly = req.query.active_only !== 'false';
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const fixedCosts = await FixedCost.getAllByCompany(companyId, activeOnly);
    res.json(fixedCosts);
  } catch (error) {
    console.error('Error fetching fixed costs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/fixed-costs/:id
 * @desc    Get a fixed cost by ID
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const fixedCost = await FixedCost.getById(req.params.id);
    
    if (!fixedCost) {
      return res.status(404).json({ message: 'Fixed cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, fixedCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    res.json(fixedCost);
  } catch (error) {
    console.error('Error fetching fixed cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/fixed-costs
 * @desc    Create a new fixed cost
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { 
      company_id, 
      cost_name, 
      cost_category, 
      amount, 
      frequency, 
      allocation_method, 
      allocation_basis, 
      start_date, 
      end_date, 
      is_active, 
      notes 
    } = req.body;
    
    if (!company_id || !cost_name || !cost_category || amount === undefined || !frequency || !allocation_method || !start_date) {
      return res.status(400).json({ 
        message: 'Company ID, cost name, cost category, amount, frequency, allocation method, and start date are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const fixedCost = await FixedCost.create({
      company_id,
      cost_name,
      cost_category,
      amount,
      frequency,
      allocation_method,
      allocation_basis,
      start_date,
      end_date,
      is_active,
      notes
    });
    
    res.status(201).json(fixedCost);
  } catch (error) {
    console.error('Error creating fixed cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/fixed-costs/:id
 * @desc    Update a fixed cost
 * @access  Private
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { 
      cost_name, 
      cost_category, 
      amount, 
      frequency, 
      allocation_method, 
      allocation_basis, 
      start_date, 
      end_date, 
      is_active, 
      notes 
    } = req.body;
    
    // Get existing fixed cost to check company access
    const existingFixedCost = await FixedCost.getById(req.params.id);
    
    if (!existingFixedCost) {
      return res.status(404).json({ message: 'Fixed cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingFixedCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const updatedFixedCost = await FixedCost.update(req.params.id, {
      cost_name,
      cost_category,
      amount,
      frequency,
      allocation_method,
      allocation_basis,
      start_date,
      end_date,
      is_active,
      notes
    });
    
    res.json(updatedFixedCost);
  } catch (error) {
    console.error('Error updating fixed cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/fixed-costs/:id
 * @desc    Delete a fixed cost
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Get existing fixed cost to check company access
    const existingFixedCost = await FixedCost.getById(req.params.id);
    
    if (!existingFixedCost) {
      return res.status(404).json({ message: 'Fixed cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingFixedCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await FixedCost.delete(req.params.id);
    
    if (success) {
      res.json({ message: 'Fixed cost deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete fixed cost' });
    }
  } catch (error) {
    console.error('Error deleting fixed cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/fixed-costs/total/:frequency
 * @desc    Get total fixed costs for a company by frequency
 * @access  Private
 */
router.get('/total/:frequency', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const frequency = req.params.frequency;
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const total = await FixedCost.getTotalByFrequency(companyId, frequency);
    res.json({ total });
  } catch (error) {
    console.error('Error calculating total fixed costs:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
