const express = require('express');
const router = express.Router();
const HistoricalCostData = require('../models/historicalCostData');
const { authenticateToken, authorizeCompanyAccess } = require('../middleware/auth');

/**
 * @route   GET /api/historical-costs
 * @desc    Get all historical cost data for a company
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const referencePeriod = req.query.reference_period;
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const historicalData = await HistoricalCostData.getAllByCompany(companyId, referencePeriod);
    res.json(historicalData);
  } catch (error) {
    console.error('Error fetching historical cost data:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/historical-costs/product/:productId
 * @desc    Get historical cost data for a specific product
 * @access  Private
 */
router.get('/product/:productId', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const productId = parseInt(req.params.productId);
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const historicalData = await HistoricalCostData.getByProduct(companyId, productId);
    res.json(historicalData);
  } catch (error) {
    console.error('Error fetching historical cost data for product:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/historical-costs
 * @desc    Create a new historical cost data entry
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { 
      company_id, 
      product_id, 
      direct_labor_cost, 
      material_cost, 
      indirect_cost_allocation, 
      total_cost, 
      reference_period, 
      notes 
    } = req.body;
    
    if (!company_id || !product_id || direct_labor_cost === undefined || 
        material_cost === undefined || indirect_cost_allocation === undefined) {
      return res.status(400).json({ 
        message: 'Company ID, product ID, direct labor cost, material cost, and indirect cost allocation are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    // Calculate total cost if not provided
    const calculatedTotalCost = total_cost || 
      (parseFloat(direct_labor_cost) + parseFloat(material_cost) + parseFloat(indirect_cost_allocation));
    
    const historicalData = await HistoricalCostData.create({
      company_id,
      product_id,
      direct_labor_cost,
      material_cost,
      indirect_cost_allocation,
      total_cost: calculatedTotalCost,
      reference_period,
      is_imported: true,
      notes
    });
    
    res.status(201).json(historicalData);
  } catch (error) {
    console.error('Error creating historical cost data:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/historical-costs/bulk
 * @desc    Bulk import historical cost data
 * @access  Private
 */
router.post('/bulk', authenticateToken, async (req, res) => {
  try {
    const { company_id, data } = req.body;
    
    if (!company_id || !data || !Array.isArray(data) || data.length === 0) {
      return res.status(400).json({ 
        message: 'Company ID and data array are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    // Prepare data for bulk insert
    const preparedData = data.map(item => ({
      company_id,
      product_id: item.product_id,
      direct_labor_cost: item.direct_labor_cost,
      material_cost: item.material_cost,
      indirect_cost_allocation: item.indirect_cost_allocation,
      total_cost: item.total_cost || 
        (parseFloat(item.direct_labor_cost) + parseFloat(item.material_cost) + parseFloat(item.indirect_cost_allocation)),
      reference_period: item.reference_period,
      is_imported: true,
      notes: item.notes
    }));
    
    const insertedCount = await HistoricalCostData.bulkInsert(preparedData);
    
    res.status(201).json({ 
      message: `Successfully imported ${insertedCount} historical cost records`,
      count: insertedCount
    });
  } catch (error) {
    console.error('Error bulk importing historical cost data:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/historical-costs/:id
 * @desc    Delete a historical cost data entry
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Get the historical data to check company access
    const historicalData = await HistoricalCostData.getById(req.params.id);
    
    if (!historicalData) {
      return res.status(404).json({ message: 'Historical cost data not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, historicalData.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await HistoricalCostData.delete(req.params.id);
    
    if (success) {
      res.json({ message: 'Historical cost data deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete historical cost data' });
    }
  } catch (error) {
    console.error('Error deleting historical cost data:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/historical-costs/company/:companyId
 * @desc    Delete all historical cost data for a company
 * @access  Private
 */
router.delete('/company/:companyId', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.params.companyId);
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const deletedCount = await HistoricalCostData.deleteAllByCompany(companyId);
    
    res.json({ 
      message: `Successfully deleted ${deletedCount} historical cost records`,
      count: deletedCount
    });
  } catch (error) {
    console.error('Error deleting all historical cost data for company:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
