const express = require("express");
const router = express.Router();
const Employee = require("../models/employee");

// Middleware to check for company ID in query or body
const checkCompanyId = (req, res, next) => {
  const companyId = req.query.company_id || req.body.company_id;
  if (!companyId) {
    return res.status(400).json({
      success: false,
      message: "Company ID is required",
    });
  }
  req.companyId = parseInt(companyId, 10);
  next();
};

// Get all employees for a specific company
router.get("/", checkCompanyId, async (req, res, next) => {
  try {
    const employees = await Employee.getAllByCompany(req.companyId);
    res.json({
      success: true,
      data: employees,
    });
  } catch (error) {
    next(error);
  }
});

// Get employee by ID
router.get("/:id", async (req, res, next) => {
  try {
    const employee = await Employee.getById(req.params.id);
    if (!employee) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
      });
    }
    res.json({
      success: true,
      data: employee,
    });
  } catch (error) {
    next(error);
  }
});

// Create new employee
router.post("/", checkCompanyId, async (req, res, next) => {
  try {
    // Ensure company_id from middleware is used
    const employeeData = { ...req.body, company_id: req.companyId };
    const employee = await Employee.create(employeeData);
    res.status(201).json({
      success: true,
      data: employee,
    });
  } catch (error) {
    next(error);
  }
});

// Update employee
router.put("/:id", checkCompanyId, async (req, res, next) => {
  try {
    // Ensure company_id from middleware is used for update context if needed
    // Or verify that the employee being updated belongs to the specified company
    const existingEmployee = await Employee.getById(req.params.id);
    if (!existingEmployee) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
      });
    }
    // Optional: Check if existingEmployee.company_id matches req.companyId for authorization
    // if (existingEmployee.company_id !== req.companyId) {
    //   return res.status(403).json({ success: false, message: "Forbidden" });
    // }

    const employeeData = { ...req.body, company_id: req.companyId }; // Ensure company_id is part of the update payload
    const employee = await Employee.update(req.params.id, employeeData);
    
    res.json({
      success: true,
      data: employee,
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
