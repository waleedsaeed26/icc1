const express = require('express');
const router = express.Router();
const VariableCost = require('../models/variableCost');
const { authenticateToken, authorizeCompanyAccess } = require('../middleware/auth');

/**
 * @route   GET /api/variable-costs
 * @desc    Get all variable costs for a company
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const activeOnly = req.query.active_only !== 'false';
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const variableCosts = await VariableCost.getAllByCompany(companyId, activeOnly);
    res.json(variableCosts);
  } catch (error) {
    console.error('Error fetching variable costs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/variable-costs/:id
 * @desc    Get a variable cost by ID
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const variableCost = await VariableCost.getById(req.params.id);
    
    if (!variableCost) {
      return res.status(404).json({ message: 'Variable cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, variableCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    res.json(variableCost);
  } catch (error) {
    console.error('Error fetching variable cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/variable-costs
 * @desc    Create a new variable cost
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { 
      company_id, 
      cost_name, 
      cost_category, 
      unit_of_measure, 
      cost_per_unit, 
      is_active, 
      notes 
    } = req.body;
    
    if (!company_id || !cost_name || !cost_category || !unit_of_measure || cost_per_unit === undefined) {
      return res.status(400).json({ 
        message: 'Company ID, cost name, cost category, unit of measure, and cost per unit are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const variableCost = await VariableCost.create({
      company_id,
      cost_name,
      cost_category,
      unit_of_measure,
      cost_per_unit,
      is_active,
      notes
    });
    
    res.status(201).json(variableCost);
  } catch (error) {
    console.error('Error creating variable cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/variable-costs/:id
 * @desc    Update a variable cost
 * @access  Private
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { 
      cost_name, 
      cost_category, 
      unit_of_measure, 
      cost_per_unit, 
      is_active, 
      notes 
    } = req.body;
    
    // Get existing variable cost to check company access
    const existingVariableCost = await VariableCost.getById(req.params.id);
    
    if (!existingVariableCost) {
      return res.status(404).json({ message: 'Variable cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingVariableCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const updatedVariableCost = await VariableCost.update(req.params.id, {
      cost_name,
      cost_category,
      unit_of_measure,
      cost_per_unit,
      is_active,
      notes
    });
    
    res.json(updatedVariableCost);
  } catch (error) {
    console.error('Error updating variable cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/variable-costs/:id
 * @desc    Delete a variable cost
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Get existing variable cost to check company access
    const existingVariableCost = await VariableCost.getById(req.params.id);
    
    if (!existingVariableCost) {
      return res.status(404).json({ message: 'Variable cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingVariableCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await VariableCost.delete(req.params.id);
    
    if (success) {
      res.json({ message: 'Variable cost deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete variable cost' });
    }
  } catch (error) {
    console.error('Error deleting variable cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/variable-costs/category/:category
 * @desc    Get variable costs by category
 * @access  Private
 */
router.get('/category/:category', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const category = req.params.category;
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const variableCosts = await VariableCost.getByCategory(companyId, category);
    res.json(variableCosts);
  } catch (error) {
    console.error('Error fetching variable costs by category:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
