const express = require('express');
const router = express.Router();
const PricingRule = require('../models/pricingRule');
const { authenticateToken, authorizeCompanyAccess } = require('../middleware/auth');

/**
 * @route   GET /api/pricing-rules
 * @desc    Get all pricing rules for a company
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const activeOnly = req.query.active_only !== 'false';
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const pricingRules = await PricingRule.getAllByCompany(companyId, activeOnly);
    res.json(pricingRules);
  } catch (error) {
    console.error('Error fetching pricing rules:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/pricing-rules/:id
 * @desc    Get a pricing rule by ID
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const pricingRule = await PricingRule.getById(req.params.id);
    
    if (!pricingRule) {
      return res.status(404).json({ message: 'Pricing rule not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, pricingRule.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    res.json(pricingRule);
  } catch (error) {
    console.error('Error fetching pricing rule:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/pricing-rules
 * @desc    Create a new pricing rule
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { 
      company_id, 
      rule_name, 
      product_category, 
      product_id, 
      customer_category, 
      markup_percentage, 
      discount_percentage, 
      min_profit_margin, 
      priority, 
      is_active, 
      start_date, 
      end_date, 
      notes 
    } = req.body;
    
    if (!company_id || !rule_name || markup_percentage === undefined) {
      return res.status(400).json({ 
        message: 'Company ID, rule name, and markup percentage are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const pricingRule = await PricingRule.create({
      company_id,
      rule_name,
      product_category,
      product_id,
      customer_category,
      markup_percentage,
      discount_percentage,
      min_profit_margin,
      priority,
      is_active,
      start_date,
      end_date,
      notes
    });
    
    res.status(201).json(pricingRule);
  } catch (error) {
    console.error('Error creating pricing rule:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/pricing-rules/:id
 * @desc    Update a pricing rule
 * @access  Private
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { 
      rule_name, 
      product_category, 
      product_id, 
      customer_category, 
      markup_percentage, 
      discount_percentage, 
      min_profit_margin, 
      priority, 
      is_active, 
      start_date, 
      end_date, 
      notes 
    } = req.body;
    
    // Get existing pricing rule to check company access
    const existingPricingRule = await PricingRule.getById(req.params.id);
    
    if (!existingPricingRule) {
      return res.status(404).json({ message: 'Pricing rule not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingPricingRule.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const updatedPricingRule = await PricingRule.update(req.params.id, {
      rule_name,
      product_category,
      product_id,
      customer_category,
      markup_percentage,
      discount_percentage,
      min_profit_margin,
      priority,
      is_active,
      start_date,
      end_date,
      notes
    });
    
    res.json(updatedPricingRule);
  } catch (error) {
    console.error('Error updating pricing rule:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/pricing-rules/:id
 * @desc    Delete a pricing rule
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Get existing pricing rule to check company access
    const existingPricingRule = await PricingRule.getById(req.params.id);
    
    if (!existingPricingRule) {
      return res.status(404).json({ message: 'Pricing rule not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingPricingRule.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await PricingRule.delete(req.params.id);
    
    if (success) {
      res.json({ message: 'Pricing rule deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete pricing rule' });
    }
  } catch (error) {
    console.error('Error deleting pricing rule:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/pricing-rules/applicable/:productId
 * @desc    Find applicable pricing rules for a product
 * @access  Private
 */
router.get('/applicable/:productId', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const productId = parseInt(req.params.productId);
    const customerCategory = req.query.customer_category;
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const applicableRules = await PricingRule.findApplicableRules(companyId, productId, customerCategory);
    res.json(applicableRules);
  } catch (error) {
    console.error('Error finding applicable pricing rules:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/pricing-rules/calculate/:productId
 * @desc    Calculate price for a product
 * @access  Private
 */
router.post('/calculate/:productId', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.body.company_id);
    const productId = parseInt(req.params.productId);
    const customerCategory = req.body.customer_category;
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const calculatedPrice = await PricingRule.calculatePrice(companyId, productId, customerCategory);
    res.json(calculatedPrice);
  } catch (error) {
    console.error('Error calculating price:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
