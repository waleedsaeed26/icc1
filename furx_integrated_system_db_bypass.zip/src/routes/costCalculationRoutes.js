const express = require('express');
const router = express.Router();
const CostCalculationService = require('../services/costCalculationService');
const { authenticateToken, checkCompanyAccess } = require('../middleware/auth');

// Middleware to check if user has access to the company
router.use(authenticateToken);
router.use(checkCompanyAccess);

/**
 * @route POST /api/cost-calculations/distribute
 * @desc Distribute indirect costs to cost centers for a given period
 * @access Private
 */
router.post('/distribute', async (req, res) => {
  try {
    const { company_id, period_start_date, period_end_date } = req.body;
    
    if (!company_id || !period_start_date || !period_end_date) {
      return res.status(400).json({ 
        success: false, 
        message: 'Company ID, period start date, and period end date are required' 
      });
    }

    // Validate date format
    const startDate = new Date(period_start_date);
    const endDate = new Date(period_end_date);
    
    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid date format. Use YYYY-MM-DD format.' 
      });
    }

    if (startDate > endDate) {
      return res.status(400).json({ 
        success: false, 
        message: 'Start date must be before end date' 
      });
    }

    const result = await CostCalculationService.distributeIndirectCosts(
      company_id,
      period_start_date,
      period_end_date
    );

    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in cost distribution:', error);
    return res.status(500).json({ 
      success: false, 
      message: 'Failed to distribute costs', 
      error: error.message 
    });
  }
});

/**
 * @route GET /api/cost-calculations/allocations
 * @desc Get cost allocations for a given period
 * @access Private
 */
router.get('/allocations', async (req, res) => {
  try {
    const { company_id, period_start_date, period_end_date } = req.query;
    
    if (!company_id || !period_start_date || !period_end_date) {
      return res.status(400).json({ 
        success: false, 
        message: 'Company ID, period start date, and period end date are required' 
      });
    }

    // Import the model here to avoid circular dependencies
    const CostCenterPeriodAllocation = require('../models/costCenterPeriodAllocation');
    
    const allocations = await CostCenterPeriodAllocation.getByPeriod(
      company_id,
      period_start_date,
      period_end_date
    );

    return res.status(200).json(allocations);
  } catch (error) {
    console.error('Error fetching cost allocations:', error);
    return res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch cost allocations', 
      error: error.message 
    });
  }
});

/**
 * @route GET /api/cost-calculations/allocations/:costCenterId
 * @desc Get cost allocations for a specific cost center in a given period
 * @access Private
 */
router.get('/allocations/:costCenterId', async (req, res) => {
  try {
    const { costCenterId } = req.params;
    const { period_start_date, period_end_date } = req.query;
    
    if (!period_start_date || !period_end_date) {
      return res.status(400).json({ 
        success: false, 
        message: 'Period start date and period end date are required' 
      });
    }

    // Import the model here to avoid circular dependencies
    const CostCenterPeriodAllocation = require('../models/costCenterPeriodAllocation');
    
    const allocations = await CostCenterPeriodAllocation.getByCostCenterAndPeriod(
      costCenterId,
      period_start_date,
      period_end_date
    );

    return res.status(200).json(allocations);
  } catch (error) {
    console.error('Error fetching cost center allocations:', error);
    return res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch cost center allocations', 
      error: error.message 
    });
  }
});

module.exports = router;
