const express = require("express");
const router = express.Router();
const ProductCost = require("../models/productCost");
const ProductCostComponent = require("../models/productCostComponent");
const ProductCostCalculationService = require("../services/productCostCalculationService"); // Import the new service
const { authenticateToken, authorizeCompanyAccess } = require("../middleware/auth");

/**
 * @route   GET /api/product-costs
 * @desc    Get all product costs for a company
 * @access  Private
 */
router.get("/", authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    // const activeOnly = req.query.active_only !== "false"; // Removed as model doesn't support it yet

    if (!companyId) {
      return res.status(400).json({ message: "Company ID is required" });
    }

    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: "Not authorized to access this company data" });
    }

    const productCosts = await ProductCost.getAllByCompany(companyId);
    res.json(productCosts);
  } catch (error) {
    console.error("Error fetching product costs:", error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/product-costs/:id
 * @desc    Get a product cost by ID
 * @access  Private
 */
router.get("/:id", authenticateToken, async (req, res) => {
  try {
    const productCost = await ProductCost.getById(req.params.id);

    if (!productCost) {
      return res.status(404).json({ message: "Product cost not found" });
    }

    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, productCost.company_id)) {
      return res.status(403).json({ message: "Not authorized to access this company data" });
    }

    // Get components (assuming this is still needed for detailed view)
    const components = await ProductCostComponent.getAllByProductCost(productCost.id);

    res.json({
      ...productCost,
      components
    });
  } catch (error) {
    console.error("Error fetching product cost:", error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/product-costs/:id/components
 * @desc    Get components for a specific product cost record
 * @access  Private
 */
router.get("/:id/components", authenticateToken, async (req, res) => {
  try {
    const productCostId = parseInt(req.params.id);
    
    // Get existing product cost to check company access
    const existingProductCost = await ProductCost.getById(productCostId);
    
    if (!existingProductCost) {
      return res.status(404).json({ message: "Product cost not found" });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingProductCost.company_id)) {
      return res.status(403).json({ message: "Not authorized to access this company data" });
    }

    const components = await ProductCostComponent.getAllByProductCost(productCostId);
    res.json(components);
  } catch (error) {
    console.error("Error fetching product cost components:", error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/product-costs/product/:productId
 * @desc    Get a product cost by product ID
 * @access  Private
 */
router.get("/product/:productId", authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const productId = parseInt(req.params.productId);
    // const activeOnly = req.query.active_only !== "false"; // Removed

    if (!companyId) {
      return res.status(400).json({ message: "Company ID is required" });
    }

    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: "Not authorized to access this company data" });
    }

    const productCost = await ProductCost.getByProductId(productId); // Assuming model method takes only productId

    if (!productCost || productCost.company_id !== companyId) {
      return res.status(404).json({ message: "Product cost not found for this company" });
    }

    // Get components
    const components = await ProductCostComponent.getAllByProductCost(productCost.id);

    res.json({
      ...productCost,
      components
    });
  } catch (error) {
    console.error("Error fetching product cost by product ID:", error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/product-costs/calculate/:productId
 * @desc    Calculate cost for a product using the ProductCostCalculationService
 * @access  Private
 */
router.post("/calculate/:productId", authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.body.company_id);
    const productId = parseInt(req.params.productId);
    const { period_start_date, period_end_date } = req.body; // Get period from body

    if (!companyId) {
      return res.status(400).json({ message: "Company ID is required" });
    }

    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: "Not authorized to access this company data" });
    }

    // Validate period dates
    if (!period_start_date || !period_end_date) {
      // Default to current month if not provided?
      // For now, require them
      return res.status(400).json({ message: "Period start date and end date are required for calculation" });
    }
    const startDate = new Date(period_start_date);
    const endDate = new Date(period_end_date);
    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime()) || startDate > endDate) {
      return res.status(400).json({ message: "Invalid period dates" });
    }

    // Use the new service for calculation
    const result = await ProductCostCalculationService.calculateProductCost(
      companyId,
      productId,
      period_start_date,
      period_end_date
    );

    res.json(result); // Return the result from the service

  } catch (error) {
    console.error("Error calculating product cost:", error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * @route   POST /api/product-costs
 * @desc    Create a new product cost manually (Potentially deprecated or for overrides)
 * @access  Private
 */
router.post("/", authenticateToken, async (req, res) => {
  try {
    const {
      company_id,
      product_id,
      cost_template_id,
      total_material_cost,
      total_labor_cost,
      total_operational_cost,
      total_overhead_cost,
      total_cost,
      notes
    } = req.body;

    if (!company_id || !product_id) {
      return res.status(400).json({
        message: "Company ID and product ID are required"
      });
    }

    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: "Not authorized to access this company data" });
    }

    // Calculate total cost if not provided
    const calculatedTotalCost = total_cost ||
      ((parseFloat(total_material_cost) || 0) +
       (parseFloat(total_labor_cost) || 0) +
       (parseFloat(total_operational_cost) || 0) +
       (parseFloat(total_overhead_cost) || 0));

    const productCost = await ProductCost.create({
      company_id,
      product_id,
      cost_template_id,
      total_material_cost: total_material_cost || 0,
      total_labor_cost: total_labor_cost || 0,
      total_operational_cost: total_operational_cost || 0,
      total_overhead_cost: total_overhead_cost || 0,
      total_cost: calculatedTotalCost,
      calculation_date: new Date(),
      notes
    });

    res.status(201).json(productCost);
  } catch (error) {
    console.error("Error creating product cost:", error);
    // Handle potential unique constraint violation (company_id, product_id)
    if (error.code === '23505') { // PostgreSQL unique violation code
        return res.status(409).json({ message: 'Product cost record already exists for this product.' });
    }
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/product-costs/:id
 * @desc    Update a product cost (manual override)
 * @access  Private
 */
router.put("/:id", authenticateToken, async (req, res) => {
  try {
    const {
      cost_template_id,
      total_material_cost,
      total_labor_cost,
      total_operational_cost,
      total_overhead_cost,
      total_cost,
      notes
    } = req.body;

    // Get existing product cost to check company access
    const existingProductCost = await ProductCost.getById(req.params.id);

    if (!existingProductCost) {
      return res.status(404).json({ message: "Product cost not found" });
    }

    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingProductCost.company_id)) {
      return res.status(403).json({ message: "Not authorized to access this company data" });
    }

    // Calculate total cost if not provided
    const calculatedTotalCost = total_cost ||
      ((parseFloat(total_material_cost) || parseFloat(existingProductCost.total_material_cost) || 0) +
       (parseFloat(total_labor_cost) || parseFloat(existingProductCost.total_labor_cost) || 0) +
       (parseFloat(total_operational_cost) || parseFloat(existingProductCost.total_operational_cost) || 0) +
       (parseFloat(total_overhead_cost) || parseFloat(existingProductCost.total_overhead_cost) || 0));

    const updatedProductCost = await ProductCost.update(req.params.id, {
      cost_template_id,
      total_material_cost,
      total_labor_cost,
      total_operational_cost,
      total_overhead_cost,
      total_cost: calculatedTotalCost,
      calculation_date: new Date(), // Update calculation date on manual update
      notes
    });

    res.json(updatedProductCost);
  } catch (error) {
    console.error("Error updating product cost:", error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/product-costs/:id
 * @desc    Delete a product cost
 * @access  Private
 */
router.delete("/:id", authenticateToken, async (req, res) => {
  try {
    // Get existing product cost to check company access
    const existingProductCost = await ProductCost.getById(req.params.id);

    if (!existingProductCost) {
      return res.status(404).json({ message: "Product cost not found" });
    }

    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingProductCost.company_id)) {
      return res.status(403).json({ message: "Not authorized to access this company data" });
    }

    const success = await ProductCost.delete(req.params.id);

    if (success) {
      res.json({ message: "Product cost deleted successfully" });
    } else {
      res.status(500).json({ message: "Failed to delete product cost" });
    }
  } catch (error) {
    console.error("Error deleting product cost:", error);
    res.status(500).json({ message: error.message });
  }
});

// Routes for managing product cost components directly might be less common
// if primarily driven by templates, but could be useful for adjustments.

module.exports = router;

