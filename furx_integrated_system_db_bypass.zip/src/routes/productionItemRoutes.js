const express = require("express");
const router = express.Router();
const ProductionItem = require("../models/productionItem");

// Middleware to check for company ID in query or body
const checkCompanyId = (req, res, next) => {
  const companyId = req.query.company_id || req.body.company_id;
  if (!companyId) {
    return res.status(400).json({
      success: false,
      message: "Company ID is required",
    });
  }
  req.companyId = parseInt(companyId, 10);
  next();
};

// Get all production items for a specific company
router.get("/", checkCompanyId, async (req, res, next) => {
  try {
    const items = await ProductionItem.getAllByCompany(req.companyId);
    res.json({
      success: true,
      data: items,
    });
  } catch (error) {
    next(error);
  }
});

// Get production item by ID
router.get("/:id", async (req, res, next) => {
  try {
    const item = await ProductionItem.getById(req.params.id);
    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Production item not found",
      });
    }
    res.json({
      success: true,
      data: item,
    });
  } catch (error) {
    next(error);
  }
});

// Get production item by QR code
router.get("/qr/:qrCode", async (req, res, next) => {
  try {
    const item = await ProductionItem.getByQrCode(req.params.qrCode);
    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Production item not found for this QR code",
      });
    }
    res.json({
      success: true,
      data: item,
    });
  } catch (error) {
    next(error);
  }
});

// Create new production item
router.post("/", checkCompanyId, async (req, res, next) => {
  try {
    const itemData = { ...req.body, company_id: req.companyId };
    const item = await ProductionItem.create(itemData);
    res.status(201).json({
      success: true,
      data: item,
    });
  } catch (error) {
    next(error);
  }
});

// Update production item status/location
router.put("/:id", async (req, res, next) => {
  try {
    const item = await ProductionItem.update(req.params.id, req.body);
    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Production item not found",
      });
    }
    res.json({
      success: true,
      data: item,
    });
  } catch (error) {
    next(error);
  }
});

// Log movement of a production item
router.post("/:id/move", async (req, res, next) => {
  try {
    const itemId = req.params.id;
    const {
      from_stage_id,
      to_stage_id,
      from_location_id,
      to_location_id,
      moved_by_employee_id,
      notes,
    } = req.body;

    // Fetch the item to ensure it exists
    const item = await ProductionItem.getById(itemId);
    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Production item not found",
      });
    }

    const movementLog = await ProductionItem.logMovement(
      itemId,
      from_stage_id || item.current_stage_id, // Use current if not provided
      to_stage_id,
      from_location_id || item.current_location_id, // Use current if not provided
      to_location_id,
      moved_by_employee_id,
      notes
    );

    // Fetch the updated item to return
    const updatedItem = await ProductionItem.getById(itemId);

    res.json({
      success: true,
      message: "Movement logged successfully",
      data: updatedItem,
      log: movementLog,
    });
  } catch (error) {
    next(error);
  }
});

// Get items by production order ID
router.get("/order/:orderId", async (req, res, next) => {
  try {
    const items = await ProductionItem.getByProductionOrderId(req.params.orderId);
    res.json({
      success: true,
      data: items,
    });
  } catch (error) {
    next(error);
  }
});

// Get items by current stage for a company
router.get("/stage/:stageId", checkCompanyId, async (req, res, next) => {
  try {
    const items = await ProductionItem.getByCurrentStage(req.params.stageId, req.companyId);
    res.json({
      success: true,
      data: items,
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
