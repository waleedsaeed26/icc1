const express = require('express');
const router = express.Router();
const Workshop = require('../models/workshop');

// Middleware to check for company ID in query or body
const checkCompanyId = (req, res, next) => {
  const companyId = req.query.company_id || req.body.company_id;
  if (!companyId) {
    return res.status(400).json({
      success: false,
      message: 'Company ID is required'
    });
  }
  req.companyId = parseInt(companyId, 10);
  next();
};

// Get all workshops for a specific company
router.get('/', checkCompanyId, async (req, res, next) => {
  try {
    // Get the onlyActive parameter from query, default to true
    const onlyActive = req.query.only_active !== 'false';
    const workshops = await Workshop.getAllByCompany(req.companyId, onlyActive);
    res.json({
      success: true,
      data: workshops
    });
  } catch (error) {
    next(error);
  }
});

// Get workshop by ID
router.get('/:id', async (req, res, next) => {
  try {
    const workshop = await Workshop.getById(req.params.id);
    if (!workshop) {
      return res.status(404).json({
        success: false,
        message: 'Workshop not found'
      });
    }
    res.json({
      success: true,
      data: workshop
    });
  } catch (error) {
    next(error);
  }
});

// Create new workshop
router.post('/', checkCompanyId, async (req, res, next) => {
  try {
    // Ensure company_id from middleware is used
    const workshopData = { ...req.body, company_id: req.companyId };
    const workshop = await Workshop.create(workshopData);
    res.status(201).json({
      success: true,
      data: workshop
    });
  } catch (error) {
    next(error);
  }
});

// Update workshop
router.put('/:id', checkCompanyId, async (req, res, next) => {
  try {
    // Ensure company_id from middleware is used for update context
    const workshopData = { ...req.body, company_id: req.companyId };
    const workshop = await Workshop.update(req.params.id, workshopData);
    
    if (!workshop) {
      return res.status(404).json({
        success: false,
        message: 'Workshop not found or not authorized to update'
      });
    }
    
    res.json({
      success: true,
      data: workshop
    });
  } catch (error) {
    next(error);
  }
});

// Deactivate (close) a workshop
router.post('/:id/deactivate', checkCompanyId, async (req, res, next) => {
  try {
    const workshop = await Workshop.deactivate(req.params.id, req.companyId);
    
    if (!workshop) {
      return res.status(404).json({
        success: false,
        message: 'Workshop not found, already inactive, or not authorized'
      });
    }
    
    res.json({
      success: true,
      message: 'Workshop deactivated successfully',
      data: workshop
    });
  } catch (error) {
    next(error);
  }
});

// Activate a workshop
router.post('/:id/activate', checkCompanyId, async (req, res, next) => {
  try {
    const workshop = await Workshop.activate(req.params.id, req.companyId);
    
    if (!workshop) {
      return res.status(404).json({
        success: false,
        message: 'Workshop not found, already active, or not authorized'
      });
    }
    
    res.json({
      success: true,
      message: 'Workshop activated successfully',
      data: workshop
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
