const express = require('express');
const router = express.Router();
const MaterialCost = require('../models/materialCost');
const { authenticateToken, authorizeCompanyAccess } = require('../middleware/auth');

/**
 * @route   GET /api/material-costs
 * @desc    Get all material costs for a company
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const activeOnly = req.query.active_only !== 'false';
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const materialCosts = await MaterialCost.getAllByCompany(companyId, activeOnly);
    res.json(materialCosts);
  } catch (error) {
    console.error('Error fetching material costs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/material-costs/:id
 * @desc    Get a material cost by ID
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const materialCost = await MaterialCost.getById(req.params.id);
    
    if (!materialCost) {
      return res.status(404).json({ message: 'Material cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, materialCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    res.json(materialCost);
  } catch (error) {
    console.error('Error fetching material cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/material-costs/material/:materialId
 * @desc    Get a material cost by material ID
 * @access  Private
 */
router.get('/material/:materialId', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const materialId = parseInt(req.params.materialId);
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const materialCost = await MaterialCost.getByMaterialId(companyId, materialId);
    
    if (!materialCost) {
      return res.status(404).json({ message: 'Material cost not found' });
    }
    
    res.json(materialCost);
  } catch (error) {
    console.error('Error fetching material cost by material ID:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/material-costs
 * @desc    Create or update a material cost
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { 
      company_id, 
      material_id, 
      cost_per_unit, 
      wastage_percentage, 
      last_purchase_date, 
      is_active, 
      notes 
    } = req.body;
    
    if (!company_id || !material_id || cost_per_unit === undefined) {
      return res.status(400).json({ 
        message: 'Company ID, material ID, and cost per unit are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const materialCost = await MaterialCost.upsert({
      company_id,
      material_id,
      cost_per_unit,
      wastage_percentage,
      last_purchase_date,
      is_active,
      notes
    });
    
    res.status(201).json(materialCost);
  } catch (error) {
    console.error('Error creating/updating material cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/material-costs/:id
 * @desc    Update a material cost
 * @access  Private
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { 
      cost_per_unit, 
      wastage_percentage, 
      last_purchase_date, 
      is_active, 
      notes 
    } = req.body;
    
    // Get existing material cost to check company access
    const existingMaterialCost = await MaterialCost.getById(req.params.id);
    
    if (!existingMaterialCost) {
      return res.status(404).json({ message: 'Material cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingMaterialCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const updatedMaterialCost = await MaterialCost.update(req.params.id, {
      cost_per_unit,
      wastage_percentage,
      last_purchase_date,
      is_active,
      notes
    });
    
    res.json(updatedMaterialCost);
  } catch (error) {
    console.error('Error updating material cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/material-costs/:id
 * @desc    Delete a material cost
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Get existing material cost to check company access
    const existingMaterialCost = await MaterialCost.getById(req.params.id);
    
    if (!existingMaterialCost) {
      return res.status(404).json({ message: 'Material cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingMaterialCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await MaterialCost.delete(req.params.id);
    
    if (success) {
      res.json({ message: 'Material cost deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete material cost' });
    }
  } catch (error) {
    console.error('Error deleting material cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/material-costs/effective/:materialId
 * @desc    Get effective cost for a material (including wastage)
 * @access  Private
 */
router.get('/effective/:materialId', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const materialId = parseInt(req.params.materialId);
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const effectiveCost = await MaterialCost.getEffectiveCost(companyId, materialId);
    res.json({ effective_cost: effectiveCost });
  } catch (error) {
    console.error('Error calculating effective material cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/material-costs/bulk
 * @desc    Bulk update material costs
 * @access  Private
 */
router.post('/bulk', authenticateToken, async (req, res) => {
  try {
    const { company_id, materials } = req.body;
    
    if (!company_id || !materials || !Array.isArray(materials) || materials.length === 0) {
      return res.status(400).json({ 
        message: 'Company ID and materials array are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    // Prepare data for bulk update
    const materialCosts = materials.map(material => ({
      company_id,
      material_id: material.material_id,
      cost_per_unit: material.cost_per_unit,
      wastage_percentage: material.wastage_percentage,
      last_purchase_date: material.last_purchase_date || new Date(),
      is_active: material.is_active !== undefined ? material.is_active : true,
      notes: material.notes
    }));
    
    const updatedCount = await MaterialCost.bulkUpdate(materialCosts);
    
    res.status(200).json({ 
      message: `Successfully updated ${updatedCount} material costs`,
      count: updatedCount
    });
  } catch (error) {
    console.error('Error bulk updating material costs:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
