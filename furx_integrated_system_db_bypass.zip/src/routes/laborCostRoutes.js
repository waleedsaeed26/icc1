const express = require('express');
const router = express.Router();
const LaborCost = require('../models/laborCost');
const { authenticateToken, authorizeCompanyAccess } = require('../middleware/auth');

/**
 * @route   GET /api/labor-costs
 * @desc    Get all labor costs for a company
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const activeOnly = req.query.active_only !== 'false';
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const laborCosts = await LaborCost.getAllByCompany(companyId, activeOnly);
    res.json(laborCosts);
  } catch (error) {
    console.error('Error fetching labor costs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/labor-costs/:id
 * @desc    Get a labor cost by ID
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const laborCost = await LaborCost.getById(req.params.id);
    
    if (!laborCost) {
      return res.status(404).json({ message: 'Labor cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, laborCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    res.json(laborCost);
  } catch (error) {
    console.error('Error fetching labor cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/labor-costs
 * @desc    Create a new labor cost
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { 
      company_id, 
      department_id, 
      workshop_id, 
      labor_category, 
      cost_per_hour, 
      overhead_percentage, 
      is_active, 
      notes 
    } = req.body;
    
    if (!company_id || !labor_category || cost_per_hour === undefined) {
      return res.status(400).json({ 
        message: 'Company ID, labor category, and cost per hour are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const laborCost = await LaborCost.create({
      company_id,
      department_id,
      workshop_id,
      labor_category,
      cost_per_hour,
      overhead_percentage,
      is_active,
      notes
    });
    
    res.status(201).json(laborCost);
  } catch (error) {
    console.error('Error creating labor cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/labor-costs/:id
 * @desc    Update a labor cost
 * @access  Private
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { 
      department_id, 
      workshop_id, 
      labor_category, 
      cost_per_hour, 
      overhead_percentage, 
      is_active, 
      notes 
    } = req.body;
    
    // Get existing labor cost to check company access
    const existingLaborCost = await LaborCost.getById(req.params.id);
    
    if (!existingLaborCost) {
      return res.status(404).json({ message: 'Labor cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingLaborCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const updatedLaborCost = await LaborCost.update(req.params.id, {
      department_id,
      workshop_id,
      labor_category,
      cost_per_hour,
      overhead_percentage,
      is_active,
      notes
    });
    
    res.json(updatedLaborCost);
  } catch (error) {
    console.error('Error updating labor cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/labor-costs/:id
 * @desc    Delete a labor cost
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Get existing labor cost to check company access
    const existingLaborCost = await LaborCost.getById(req.params.id);
    
    if (!existingLaborCost) {
      return res.status(404).json({ message: 'Labor cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingLaborCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await LaborCost.delete(req.params.id);
    
    if (success) {
      res.json({ message: 'Labor cost deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete labor cost' });
    }
  } catch (error) {
    console.error('Error deleting labor cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/labor-costs/category/:category
 * @desc    Get labor cost for a specific category in a department/workshop
 * @access  Private
 */
router.get('/category/:category', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const category = req.params.category;
    const departmentId = req.query.department_id ? parseInt(req.query.department_id) : null;
    const workshopId = req.query.workshop_id ? parseInt(req.query.workshop_id) : null;
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const laborCost = await LaborCost.getByCategoryAndLocation(companyId, category, departmentId, workshopId);
    
    if (!laborCost) {
      return res.status(404).json({ message: 'Labor cost not found for the specified category and location' });
    }
    
    res.json(laborCost);
  } catch (error) {
    console.error('Error fetching labor cost by category and location:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/labor-costs/effective/:category
 * @desc    Get effective labor cost per hour (including overhead)
 * @access  Private
 */
router.get('/effective/:category', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const category = req.params.category;
    const departmentId = req.query.department_id ? parseInt(req.query.department_id) : null;
    const workshopId = req.query.workshop_id ? parseInt(req.query.workshop_id) : null;
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const effectiveCost = await LaborCost.getEffectiveCostPerHour(companyId, category, departmentId, workshopId);
    res.json({ effective_cost_per_hour: effectiveCost });
  } catch (error) {
    console.error('Error calculating effective labor cost:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
