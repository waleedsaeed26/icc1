const express = require('express');
const router = express.Router();
const CostCenter = require('../models/costCenter');
const { authenticateToken, authorizeCompanyAccess } = require('../middleware/auth');

/**
 * @route   GET /api/cost-centers
 * @desc    Get all cost centers for a company
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const activeOnly = req.query.active_only !== 'false';
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const costCenters = await CostCenter.getAllByCompany(companyId, activeOnly);
    res.json(costCenters);
  } catch (error) {
    console.error('Error fetching cost centers:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/cost-centers/:id
 * @desc    Get a cost center by ID
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const costCenter = await CostCenter.getById(req.params.id);
    
    if (!costCenter) {
      return res.status(404).json({ message: 'Cost center not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, costCenter.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    res.json(costCenter);
  } catch (error) {
    console.error('Error fetching cost center:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/cost-centers
 * @desc    Create a new cost center
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { company_id, center_name, center_type, department_id, workshop_id, is_active, notes } = req.body;
    
    if (!company_id || !center_name || !center_type) {
      return res.status(400).json({ message: 'Company ID, center name, and center type are required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const costCenter = await CostCenter.create({
      company_id,
      center_name,
      center_type,
      department_id,
      workshop_id,
      is_active,
      notes
    });
    
    res.status(201).json(costCenter);
  } catch (error) {
    console.error('Error creating cost center:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/cost-centers/:id
 * @desc    Update a cost center
 * @access  Private
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { center_name, center_type, department_id, workshop_id, is_active, notes } = req.body;
    
    // Get existing cost center to check company access
    const existingCostCenter = await CostCenter.getById(req.params.id);
    
    if (!existingCostCenter) {
      return res.status(404).json({ message: 'Cost center not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingCostCenter.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const updatedCostCenter = await CostCenter.update(req.params.id, {
      center_name,
      center_type,
      department_id,
      workshop_id,
      is_active,
      notes
    });
    
    res.json(updatedCostCenter);
  } catch (error) {
    console.error('Error updating cost center:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/cost-centers/:id
 * @desc    Delete a cost center
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Get existing cost center to check company access
    const existingCostCenter = await CostCenter.getById(req.params.id);
    
    if (!existingCostCenter) {
      return res.status(404).json({ message: 'Cost center not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingCostCenter.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await CostCenter.delete(req.params.id);
    
    if (success) {
      res.json({ message: 'Cost center deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete cost center' });
    }
  } catch (error) {
    console.error('Error deleting cost center:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/cost-centers/type/:type
 * @desc    Get cost centers by type
 * @access  Private
 */
router.get('/type/:type', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const type = req.params.type;
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const costCenters = await CostCenter.getByType(companyId, type);
    res.json(costCenters);
  } catch (error) {
    console.error('Error fetching cost centers by type:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
