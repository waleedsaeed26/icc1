const express = require('express');
const router = express.Router();
const Company = require('../models/company');

// Get all companies
router.get('/', async (req, res, next) => {
  try {
    const companies = await Company.getAll();
    res.json({
      success: true,
      data: companies
    });
  } catch (error) {
    next(error);
  }
});

// Get company by ID
router.get('/:id', async (req, res, next) => {
  try {
    const company = await Company.getById(req.params.id);
    if (!company) {
      return res.status(404).json({
        success: false,
        message: 'Company not found'
      });
    }
    res.json({
      success: true,
      data: company
    });
  } catch (error) {
    next(error);
  }
});

// Create new company
router.post('/', async (req, res, next) => {
  try {
    const company = await Company.create(req.body);
    res.status(201).json({
      success: true,
      data: company
    });
  } catch (error) {
    next(error);
  }
});

// Update company
router.put('/:id', async (req, res, next) => {
  try {
    const company = await Company.update(req.params.id, req.body);
    if (!company) {
      return res.status(404).json({
        success: false,
        message: 'Company not found'
      });
    }
    res.json({
      success: true,
      data: company
    });
  } catch (error) {
    next(error);
  }
});

// Get child companies
router.get('/:id/children', async (req, res, next) => {
  try {
    const children = await Company.getChildCompanies(req.params.id);
    res.json({
      success: true,
      data: children
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
