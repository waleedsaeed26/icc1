const express = require('express');
const router = express.Router();
const CostAllocation = require('../models/costAllocation');
const { authenticateToken, authorizeCompanyAccess } = require('../middleware/auth');

/**
 * @route   GET /api/cost-allocations
 * @desc    Get all cost allocations for a company
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const activeOnly = req.query.active_only !== 'false';
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const allocations = await CostAllocation.getAllByCompany(companyId, activeOnly);
    res.json(allocations);
  } catch (error) {
    console.error('Error fetching cost allocations:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/cost-allocations/center/:centerId
 * @desc    Get all allocations for a specific cost center
 * @access  Private
 */
router.get('/center/:centerId', authenticateToken, async (req, res) => {
  try {
    const centerId = parseInt(req.params.centerId);
    const activeOnly = req.query.active_only !== 'false';
    
    // Get one allocation to check company access
    const allocations = await CostAllocation.getByCostCenter(centerId, activeOnly);
    
    if (allocations.length > 0) {
      // Check if user has access to this company
      if (!authorizeCompanyAccess(req.user, allocations[0].company_id)) {
        return res.status(403).json({ message: 'Not authorized to access this company data' });
      }
    }
    
    res.json(allocations);
  } catch (error) {
    console.error('Error fetching cost allocations for center:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/cost-allocations/:id
 * @desc    Get a cost allocation by ID
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const allocation = await CostAllocation.getById(req.params.id);
    
    if (!allocation) {
      return res.status(404).json({ message: 'Cost allocation not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, allocation.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    res.json(allocation);
  } catch (error) {
    console.error('Error fetching cost allocation:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/cost-allocations
 * @desc    Create a new cost allocation
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { 
      company_id, 
      cost_center_id, 
      cost_type, 
      cost_id, 
      allocation_percentage, 
      start_date, 
      end_date, 
      is_active, 
      notes 
    } = req.body;
    
    if (!company_id || !cost_center_id || !cost_type || !cost_id || allocation_percentage === undefined) {
      return res.status(400).json({ 
        message: 'Company ID, cost center ID, cost type, cost ID, and allocation percentage are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    // Check if total allocation percentage will exceed 100%
    const currentTotal = await CostAllocation.getTotalAllocationPercentage(company_id, cost_type, cost_id);
    const newTotal = currentTotal + parseFloat(allocation_percentage);
    
    if (newTotal > 100) {
      return res.status(400).json({ 
        message: `Total allocation percentage would exceed 100%. Current total: ${currentTotal}%, New allocation: ${allocation_percentage}%` 
      });
    }
    
    const allocation = await CostAllocation.create({
      company_id,
      cost_center_id,
      cost_type,
      cost_id,
      allocation_percentage,
      start_date,
      end_date,
      is_active,
      notes
    });
    
    res.status(201).json(allocation);
  } catch (error) {
    console.error('Error creating cost allocation:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/cost-allocations/:id
 * @desc    Update a cost allocation
 * @access  Private
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { 
      cost_center_id, 
      cost_type, 
      cost_id, 
      allocation_percentage, 
      start_date, 
      end_date, 
      is_active, 
      notes 
    } = req.body;
    
    // Get existing allocation to check company access
    const existingAllocation = await CostAllocation.getById(req.params.id);
    
    if (!existingAllocation) {
      return res.status(404).json({ message: 'Cost allocation not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingAllocation.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    // Check if total allocation percentage will exceed 100%
    if (allocation_percentage !== undefined && 
        (cost_type !== existingAllocation.cost_type || cost_id !== existingAllocation.cost_id || 
         allocation_percentage !== existingAllocation.allocation_percentage)) {
      
      const currentTotal = await CostAllocation.getTotalAllocationPercentage(
        existingAllocation.company_id, 
        cost_type || existingAllocation.cost_type, 
        cost_id || existingAllocation.cost_id
      );
      
      // Subtract existing allocation if we're updating the same cost type and cost id
      let adjustedTotal = currentTotal;
      if (cost_type === existingAllocation.cost_type && cost_id === existingAllocation.cost_id) {
        adjustedTotal -= parseFloat(existingAllocation.allocation_percentage);
      }
      
      const newTotal = adjustedTotal + parseFloat(allocation_percentage);
      
      if (newTotal > 100) {
        return res.status(400).json({ 
          message: `Total allocation percentage would exceed 100%. Current total: ${adjustedTotal}%, New allocation: ${allocation_percentage}%` 
        });
      }
    }
    
    const updatedAllocation = await CostAllocation.update(req.params.id, {
      cost_center_id,
      cost_type,
      cost_id,
      allocation_percentage,
      start_date,
      end_date,
      is_active,
      notes
    });
    
    res.json(updatedAllocation);
  } catch (error) {
    console.error('Error updating cost allocation:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/cost-allocations/:id
 * @desc    Delete a cost allocation
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Get existing allocation to check company access
    const existingAllocation = await CostAllocation.getById(req.params.id);
    
    if (!existingAllocation) {
      return res.status(404).json({ message: 'Cost allocation not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingAllocation.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await CostAllocation.delete(req.params.id);
    
    if (success) {
      res.json({ message: 'Cost allocation deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete cost allocation' });
    }
  } catch (error) {
    console.error('Error deleting cost allocation:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/cost-allocations/total/:costType/:costId
 * @desc    Get total allocation percentage for a specific cost
 * @access  Private
 */
router.get('/total/:costType/:costId', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const costType = req.params.costType;
    const costId = parseInt(req.params.costId);
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const totalPercentage = await CostAllocation.getTotalAllocationPercentage(companyId, costType, costId);
    res.json({ total_percentage: totalPercentage });
  } catch (error) {
    console.error('Error fetching total allocation percentage:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
