const express = require('express');
const router = express.Router();
const OperationalCost = require('../models/operationalCost');
const { authenticateToken, authorizeCompanyAccess } = require('../middleware/auth');

/**
 * @route   GET /api/operational-costs
 * @desc    Get all operational costs for a company
 * @access  Private
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const activeOnly = req.query.active_only !== 'false';
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const operationalCosts = await OperationalCost.getAllByCompany(companyId, activeOnly);
    res.json(operationalCosts);
  } catch (error) {
    console.error('Error fetching operational costs:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/operational-costs/:id
 * @desc    Get an operational cost by ID
 * @access  Private
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const operationalCost = await OperationalCost.getById(req.params.id);
    
    if (!operationalCost) {
      return res.status(404).json({ message: 'Operational cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, operationalCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    res.json(operationalCost);
  } catch (error) {
    console.error('Error fetching operational cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   POST /api/operational-costs
 * @desc    Create a new operational cost
 * @access  Private
 */
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { 
      company_id, 
      department_id, 
      workshop_id, 
      cost_name, 
      cost_category, 
      amount, 
      frequency, 
      allocation_method, 
      is_active, 
      notes 
    } = req.body;
    
    if (!company_id || !cost_name || !cost_category || amount === undefined || !frequency || !allocation_method) {
      return res.status(400).json({ 
        message: 'Company ID, cost name, cost category, amount, frequency, and allocation method are required' 
      });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const operationalCost = await OperationalCost.create({
      company_id,
      department_id,
      workshop_id,
      cost_name,
      cost_category,
      amount,
      frequency,
      allocation_method,
      is_active,
      notes
    });
    
    res.status(201).json(operationalCost);
  } catch (error) {
    console.error('Error creating operational cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   PUT /api/operational-costs/:id
 * @desc    Update an operational cost
 * @access  Private
 */
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { 
      department_id, 
      workshop_id, 
      cost_name, 
      cost_category, 
      amount, 
      frequency, 
      allocation_method, 
      is_active, 
      notes 
    } = req.body;
    
    // Get existing operational cost to check company access
    const existingOperationalCost = await OperationalCost.getById(req.params.id);
    
    if (!existingOperationalCost) {
      return res.status(404).json({ message: 'Operational cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingOperationalCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const updatedOperationalCost = await OperationalCost.update(req.params.id, {
      department_id,
      workshop_id,
      cost_name,
      cost_category,
      amount,
      frequency,
      allocation_method,
      is_active,
      notes
    });
    
    res.json(updatedOperationalCost);
  } catch (error) {
    console.error('Error updating operational cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   DELETE /api/operational-costs/:id
 * @desc    Delete an operational cost
 * @access  Private
 */
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    // Get existing operational cost to check company access
    const existingOperationalCost = await OperationalCost.getById(req.params.id);
    
    if (!existingOperationalCost) {
      return res.status(404).json({ message: 'Operational cost not found' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, existingOperationalCost.company_id)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const success = await OperationalCost.delete(req.params.id);
    
    if (success) {
      res.json({ message: 'Operational cost deleted successfully' });
    } else {
      res.status(500).json({ message: 'Failed to delete operational cost' });
    }
  } catch (error) {
    console.error('Error deleting operational cost:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/operational-costs/location
 * @desc    Get operational costs for a specific department or workshop
 * @access  Private
 */
router.get('/location', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const departmentId = req.query.department_id ? parseInt(req.query.department_id) : null;
    const workshopId = req.query.workshop_id ? parseInt(req.query.workshop_id) : null;
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const operationalCosts = await OperationalCost.getByLocation(companyId, departmentId, workshopId);
    res.json(operationalCosts);
  } catch (error) {
    console.error('Error fetching operational costs by location:', error);
    res.status(500).json({ message: error.message });
  }
});

/**
 * @route   GET /api/operational-costs/total/:frequency
 * @desc    Calculate total operational costs for a location and frequency
 * @access  Private
 */
router.get('/total/:frequency', authenticateToken, async (req, res) => {
  try {
    const companyId = parseInt(req.query.company_id);
    const frequency = req.params.frequency;
    const departmentId = req.query.department_id ? parseInt(req.query.department_id) : null;
    const workshopId = req.query.workshop_id ? parseInt(req.query.workshop_id) : null;
    
    if (!companyId) {
      return res.status(400).json({ message: 'Company ID is required' });
    }
    
    // Check if user has access to this company
    if (!authorizeCompanyAccess(req.user, companyId)) {
      return res.status(403).json({ message: 'Not authorized to access this company data' });
    }
    
    const total = await OperationalCost.getTotalByFrequencyAndLocation(companyId, frequency, departmentId, workshopId);
    res.json({ total });
  } catch (error) {
    console.error('Error calculating total operational costs:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
