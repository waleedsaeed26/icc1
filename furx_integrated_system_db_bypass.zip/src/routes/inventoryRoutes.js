const express = require("express");
const router = express.Router();
const Inventory = require("../models/inventory");

// Middleware to check for company ID in query
const checkCompanyId = (req, res, next) => {
  const companyId = req.query.company_id;
  if (!companyId) {
    return res.status(400).json({
      success: false,
      message: "Company ID is required in query parameters",
    });
  }
  req.companyId = parseInt(companyId, 10);
  next();
};

// Get material inventory for a specific company
router.get("/materials", checkCompanyId, async (req, res, next) => {
  try {
    const inventory = await Inventory.getMaterialInventoryByCompany(req.companyId);
    res.json({
      success: true,
      data: inventory,
    });
  } catch (error) {
    next(error);
  }
});

// Get product inventory for a specific company
router.get("/products", checkCompanyId, async (req, res, next) => {
  try {
    const inventory = await Inventory.getProductInventoryByCompany(req.companyId);
    res.json({
      success: true,
      data: inventory,
    });
  } catch (error) {
    next(error);
  }
});

// Update material inventory (Receipt, Issue, Adjustment)
router.post("/materials/transaction", checkCompanyId, async (req, res, next) => {
  try {
    const {
      material_id,
      location_id,
      quantity_change,
      transaction_type,
      related_document_id,
      employee_id,
    } = req.body;

    if (!material_id || !location_id || quantity_change === undefined || !transaction_type || !employee_id) {
        return res.status(400).json({ success: false, message: "Missing required fields for material transaction" });
    }

    const updatedInventory = await Inventory.updateMaterialInventory(
      material_id,
      location_id,
      req.companyId, // Use companyId from middleware
      quantity_change,
      transaction_type,
      related_document_id,
      employee_id
    );
    res.json({
      success: true,
      message: "Material inventory updated successfully",
      data: updatedInventory,
    });
  } catch (error) {
    next(error);
  }
});

// Update product inventory (Receipt, Issue, Adjustment)
router.post("/products/transaction", checkCompanyId, async (req, res, next) => {
  try {
    const {
      product_id,
      location_id,
      quantity_change,
      transaction_type,
      related_document_id,
      employee_id,
    } = req.body;

    if (!product_id || !location_id || quantity_change === undefined || !transaction_type || !employee_id) {
        return res.status(400).json({ success: false, message: "Missing required fields for product transaction" });
    }

    const updatedInventory = await Inventory.updateProductInventory(
      product_id,
      location_id,
      req.companyId, // Use companyId from middleware
      quantity_change,
      transaction_type,
      related_document_id,
      employee_id
    );
    res.json({
      success: true,
      message: "Product inventory updated successfully",
      data: updatedInventory,
    });
  } catch (error) {
    next(error);
  }
});

// Get inventory transaction history for a company
router.get("/history", checkCompanyId, async (req, res, next) => {
  try {
    // Extract optional filters from query parameters
    const filters = {
        materialId: req.query.material_id,
        productId: req.query.product_id,
        locationId: req.query.location_id,
        startDate: req.query.start_date,
        endDate: req.query.end_date
    };
    // Remove undefined filters
    Object.keys(filters).forEach(key => filters[key] === undefined && delete filters[key]);

    const history = await Inventory.getTransactionHistory(req.companyId, filters);
    res.json({
      success: true,
      data: history,
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
