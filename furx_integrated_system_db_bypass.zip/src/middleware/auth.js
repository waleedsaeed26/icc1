// Mock authentication middleware for testing purposes
// This file provides mock implementations of authentication functions
// used in the route files

/**
 * Basic authentication middleware
 * For testing purposes, we'll skip authentication
 */
const auth = (req, res, next) => {
  // For testing purposes, we'll skip authentication
  // In a real environment, this would verify JWT tokens or session cookies
  next();
};

/**
 * Authenticate JWT token
 * For testing purposes, we'll add a mock user to the request
 */
const authenticateToken = (req, res, next) => {
  // For testing purposes, we'll add a mock user to the request
  req.user = {
    id: 1,
    username: 'testuser',
    role: 'admin',
    companies: [1, 2, 3, 4] // User has access to these companies
  };
  next();
};

/**
 * Authorize company access
 * Check if user has access to the specified company
 */
const authorizeCompanyAccess = (user, companyId) => {
  // For testing purposes, we'll allow access to all companies
  // In a real environment, this would check if the user has access to the company
  return true;
};

module.exports = {
  auth,
  authenticateToken,
  authorizeCompanyAccess
};
