-- Final Database Schema for Cost Pricing Module
-- This schema includes all tables and relationships needed for the cost pricing system

-- Cost Centers Table
-- Stores information about cost centers (departments, workshops)
CREATE TABLE IF NOT EXISTS cost_centers (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    center_name VARCHAR(100) NOT NULL,
    center_type VARCHAR(50) NOT NULL, -- 'department', 'workshop', etc.
    department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
    workshop_id INTEGER REFERENCES workshops(id) ON DELETE SET NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    CONSTRAINT unique_cost_center_name_per_company UNIQUE (company_id, center_name)
);

-- Fixed Costs Table
-- Stores information about fixed costs (rent, salaries, etc.)
CREATE TABLE IF NOT EXISTS fixed_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    cost_name VARCHAR(100) NOT NULL,
    cost_category VARCHAR(50) NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    frequency VARCHAR(20) NOT NULL, -- 'monthly', 'quarterly', 'annual', etc.
    allocation_method VARCHAR(50) NOT NULL, -- 'percentage', 'direct', 'activity-based', etc.
    allocation_basis VARCHAR(50), -- 'area', 'headcount', 'machine-hours', etc.
    start_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Variable Costs Table
-- Stores information about variable costs that change with production volume
CREATE TABLE IF NOT EXISTS variable_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    cost_name VARCHAR(100) NOT NULL,
    cost_category VARCHAR(50) NOT NULL,
    cost_per_unit DECIMAL(12, 2) NOT NULL,
    unit_type VARCHAR(50) NOT NULL, -- 'piece', 'hour', 'kg', etc.
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Cost Allocations Table
-- Stores allocation percentages for fixed costs to cost centers
CREATE TABLE IF NOT EXISTS cost_allocations (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    cost_center_id INTEGER NOT NULL REFERENCES cost_centers(id) ON DELETE CASCADE,
    cost_type VARCHAR(20) NOT NULL, -- 'fixed', 'variable', etc.
    cost_id INTEGER NOT NULL, -- References fixed_costs(id) or variable_costs(id) based on cost_type
    allocation_percentage DECIMAL(5, 2) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    CONSTRAINT check_allocation_percentage CHECK (allocation_percentage >= 0 AND allocation_percentage <= 100)
);

-- Cost Center Period Allocations Table
-- Stores the results of cost allocations for each period
CREATE TABLE IF NOT EXISTS cost_center_period_allocations (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    cost_center_id INTEGER NOT NULL REFERENCES cost_centers(id) ON DELETE CASCADE,
    period_start_date DATE NOT NULL,
    period_end_date DATE NOT NULL,
    cost_type VARCHAR(50) NOT NULL, -- 'fixed', 'operational', 'total_overhead', etc.
    allocated_amount DECIMAL(12, 2) NOT NULL,
    allocation_basis VARCHAR(50), -- 'percentage', 'direct', etc.
    calculation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    CONSTRAINT unique_cost_center_period_type UNIQUE (cost_center_id, period_start_date, period_end_date, cost_type)
);

-- Material Costs Table
-- Stores information about material costs
CREATE TABLE IF NOT EXISTS material_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    material_id INTEGER REFERENCES inventory(id) ON DELETE SET NULL,
    cost_per_unit DECIMAL(12, 2) NOT NULL,
    wastage_percentage DECIMAL(5, 2) DEFAULT 0,
    last_purchase_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Labor Costs Table
-- Stores information about labor costs
CREATE TABLE IF NOT EXISTS labor_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
    workshop_id INTEGER REFERENCES workshops(id) ON DELETE SET NULL,
    labor_category VARCHAR(50) NOT NULL,
    cost_per_hour DECIMAL(12, 2) NOT NULL,
    overhead_percentage DECIMAL(5, 2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Operational Costs Table
-- Stores information about operational costs
CREATE TABLE IF NOT EXISTS operational_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    cost_center_id INTEGER REFERENCES cost_centers(id) ON DELETE SET NULL,
    cost_name VARCHAR(100) NOT NULL,
    cost_category VARCHAR(50) NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    frequency VARCHAR(20) NOT NULL, -- 'monthly', 'quarterly', 'annual', etc.
    allocation_method VARCHAR(50) NOT NULL, -- 'direct', 'percentage', etc.
    start_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Cost Templates Table
-- Stores templates for product costs
CREATE TABLE IF NOT EXISTS cost_templates (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    template_name VARCHAR(100) NOT NULL,
    template_description TEXT,
    product_category VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_template_name_per_company UNIQUE (company_id, template_name)
);

-- Cost Template Components Table
-- Stores components of cost templates
CREATE TABLE IF NOT EXISTS cost_template_components (
    id SERIAL PRIMARY KEY,
    template_id INTEGER NOT NULL REFERENCES cost_templates(id) ON DELETE CASCADE,
    component_type VARCHAR(50) NOT NULL, -- 'material', 'labor', 'operational', etc.
    component_name VARCHAR(100) NOT NULL,
    cost_category VARCHAR(50),
    quantity DECIMAL(12, 3) NOT NULL,
    unit_cost DECIMAL(12, 2) NOT NULL,
    wastage_percentage DECIMAL(5, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Product Costs Table
-- Stores calculated costs for products
CREATE TABLE IF NOT EXISTS product_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    cost_template_id INTEGER REFERENCES cost_templates(id) ON DELETE SET NULL,
    total_material_cost DECIMAL(12, 2) NOT NULL DEFAULT 0,
    total_labor_cost DECIMAL(12, 2) NOT NULL DEFAULT 0,
    total_operational_cost DECIMAL(12, 2) NOT NULL DEFAULT 0,
    total_overhead_cost DECIMAL(12, 2) NOT NULL DEFAULT 0,
    total_cost DECIMAL(12, 2) NOT NULL DEFAULT 0,
    calculation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    CONSTRAINT unique_product_per_company UNIQUE (company_id, product_id)
);

-- Product Cost Components Table
-- Stores detailed components of product costs
CREATE TABLE IF NOT EXISTS product_cost_components (
    id SERIAL PRIMARY KEY,
    product_cost_id INTEGER NOT NULL REFERENCES product_costs(id) ON DELETE CASCADE,
    component_type VARCHAR(50) NOT NULL, -- 'material', 'labor', 'operational', etc.
    component_name VARCHAR(100) NOT NULL,
    cost_category VARCHAR(50),
    quantity DECIMAL(12, 3) NOT NULL,
    unit_cost DECIMAL(12, 2) NOT NULL,
    total_cost DECIMAL(12, 2) NOT NULL,
    wastage_percentage DECIMAL(5, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Product Cost Centers Table
-- Stores relationships between products and cost centers for allocation
CREATE TABLE IF NOT EXISTS product_cost_centers (
    id SERIAL PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    cost_center_id INTEGER NOT NULL REFERENCES cost_centers(id) ON DELETE CASCADE,
    allocation_percentage DECIMAL(5, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_product_cost_center UNIQUE (product_id, cost_center_id),
    CONSTRAINT check_product_allocation_percentage CHECK (allocation_percentage >= 0 AND allocation_percentage <= 100)
);

-- Pricing Rules Table
-- Stores rules for product pricing
CREATE TABLE IF NOT EXISTS pricing_rules (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    rule_name VARCHAR(100) NOT NULL,
    product_category VARCHAR(50),
    product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
    customer_category VARCHAR(50),
    markup_percentage DECIMAL(5, 2) NOT NULL,
    discount_percentage DECIMAL(5, 2) DEFAULT 0,
    min_profit_margin DECIMAL(5, 2),
    priority INTEGER DEFAULT 100, -- Lower number = higher priority
    is_active BOOLEAN DEFAULT TRUE,
    start_date DATE NOT NULL,
    end_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Invoice Costs Table
-- Stores cost information for invoices
CREATE TABLE IF NOT EXISTS invoice_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    invoice_id INTEGER NOT NULL, -- Would reference invoices table when created
    total_cost DECIMAL(12, 2) NOT NULL,
    total_price DECIMAL(12, 2) NOT NULL,
    profit_amount DECIMAL(12, 2) NOT NULL,
    profit_percentage DECIMAL(5, 2) NOT NULL,
    calculation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    CONSTRAINT unique_invoice_per_company UNIQUE (company_id, invoice_id)
);

-- Historical Cost Data Table
-- Stores historical cost data imported from previous systems
CREATE TABLE IF NOT EXISTS historical_cost_data (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    material_cost DECIMAL(12, 2) NOT NULL,
    labor_cost DECIMAL(12, 2) NOT NULL,
    indirect_cost DECIMAL(12, 2) NOT NULL,
    total_cost DECIMAL(12, 2) NOT NULL,
    record_date DATE NOT NULL,
    import_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_cost_centers_company_id ON cost_centers(company_id);
CREATE INDEX IF NOT EXISTS idx_fixed_costs_company_id ON fixed_costs(company_id);
CREATE INDEX IF NOT EXISTS idx_variable_costs_company_id ON variable_costs(company_id);
CREATE INDEX IF NOT EXISTS idx_cost_allocations_cost_center_id ON cost_allocations(cost_center_id);
CREATE INDEX IF NOT EXISTS idx_cost_center_period_allocations_cost_center_id ON cost_center_period_allocations(cost_center_id);
CREATE INDEX IF NOT EXISTS idx_cost_center_period_allocations_period ON cost_center_period_allocations(period_start_date, period_end_date);
CREATE INDEX IF NOT EXISTS idx_material_costs_company_id ON material_costs(company_id);
CREATE INDEX IF NOT EXISTS idx_labor_costs_company_id ON labor_costs(company_id);
CREATE INDEX IF NOT EXISTS idx_operational_costs_company_id ON operational_costs(company_id);
CREATE INDEX IF NOT EXISTS idx_cost_templates_company_id ON cost_templates(company_id);
CREATE INDEX IF NOT EXISTS idx_cost_template_components_template_id ON cost_template_components(template_id);
CREATE INDEX IF NOT EXISTS idx_product_costs_company_id ON product_costs(company_id);
CREATE INDEX IF NOT EXISTS idx_product_costs_product_id ON product_costs(product_id);
CREATE INDEX IF NOT EXISTS idx_product_cost_components_product_cost_id ON product_cost_components(product_cost_id);
CREATE INDEX IF NOT EXISTS idx_pricing_rules_company_id ON pricing_rules(company_id);
CREATE INDEX IF NOT EXISTS idx_pricing_rules_product_id ON pricing_rules(product_id);
CREATE INDEX IF NOT EXISTS idx_invoice_costs_company_id ON invoice_costs(company_id);
CREATE INDEX IF NOT EXISTS idx_historical_cost_data_company_id ON historical_cost_data(company_id);
CREATE INDEX IF NOT EXISTS idx_historical_cost_data_product_id ON historical_cost_data(product_id);
