#!/usr/bin/env python3
import os
import sys
import psycopg2
from psycopg2.extras import RealDictCursor
import json
from datetime import datetime

# Configuration
DB_CONFIG = {
    "dbname": "furx_db",
    "user": "postgres",
    "password": "postgres",
    "host": "localhost"
}

# Path to SQL schema file
SCHEMA_FILE = '/home/ubuntu/furx_integrated_system/src/database/cost_pricing_schema_final.sql'

# Path to test data directory
TEST_DATA_DIR = '/home/ubuntu/test_data'

def connect_to_db():
    """Connect to the PostgreSQL database"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None

def execute_schema_file(conn, schema_file):
    """Execute SQL schema file to create tables"""
    try:
        cursor = conn.cursor()
        
        # Read the schema file
        with open(schema_file, 'r') as f:
            sql = f.read()
        
        # Execute the SQL
        cursor.execute(sql)
        conn.commit()
        cursor.close()
        
        print(f"Successfully executed schema file: {schema_file}")
        return True
    except Exception as e:
        print(f"Error executing schema file: {e}")
        conn.rollback()
        return False

def load_json_data(file_path):
    """Load data from JSON file"""
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
        return data
    except Exception as e:
        print(f"Error loading JSON data from {file_path}: {e}")
        return []

def insert_test_data(conn, table_name, data):
    """Insert test data into the specified table"""
    if not data:
        print(f"No data to insert into {table_name}")
        return []
        
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    
    # Get column names from the first data item
    columns = list(data[0].keys())
    
    # Create placeholders for the SQL query
    placeholders = ', '.join(['%s'] * len(columns))
    
    # Build the SQL query
    query = f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({placeholders}) RETURNING id"
    
    inserted_ids = []
    for item in data:
        values = [item[col] for col in columns]
        try:
            cursor.execute(query, values)
            inserted_id = cursor.fetchone()['id']
            inserted_ids.append(inserted_id)
        except Exception as e:
            print(f"Error inserting into {table_name}: {e}")
            conn.rollback()
            return []
    
    conn.commit()
    cursor.close()
    
    print(f"Successfully inserted {len(inserted_ids)} records into {table_name}")
    return inserted_ids

def main():
    # Connect to the database
    conn = connect_to_db()
    if not conn:
        print("Failed to connect to the database. Exiting.")
        sys.exit(1)
    
    # Execute schema file
    if not execute_schema_file(conn, SCHEMA_FILE):
        print("Failed to execute schema file. Exiting.")
        conn.close()
        sys.exit(1)
    
    # Load and insert test data
    try:
        # First, clear existing data (optional)
        cursor = conn.cursor()
        tables = [
            "cost_center_period_allocations",
            "cost_allocations",
            "operational_costs",
            "fixed_costs",
            "material_costs",
            "labor_costs",
            "pricing_rules",
            "cost_templates",
            "cost_centers"
        ]
        
        for table in tables:
            try:
                cursor.execute(f"DELETE FROM {table} WHERE company_id = 1")
            except Exception as e:
                print(f"Error clearing table {table}: {e}")
                conn.rollback()
        
        conn.commit()
        cursor.close()
        
        # Load and insert data
        cost_centers = load_json_data(os.path.join(TEST_DATA_DIR, 'cost_centers.json'))
        fixed_costs = load_json_data(os.path.join(TEST_DATA_DIR, 'fixed_costs.json'))
        operational_costs = load_json_data(os.path.join(TEST_DATA_DIR, 'operational_costs.json'))
        cost_allocations = load_json_data(os.path.join(TEST_DATA_DIR, 'cost_allocations.json'))
        material_costs = load_json_data(os.path.join(TEST_DATA_DIR, 'material_costs.json'))
        labor_costs = load_json_data(os.path.join(TEST_DATA_DIR, 'labor_costs.json'))
        cost_templates = load_json_data(os.path.join(TEST_DATA_DIR, 'cost_templates.json'))
        pricing_rules = load_json_data(os.path.join(TEST_DATA_DIR, 'pricing_rules.json'))
        
        # Insert data in the correct order (respecting foreign key constraints)
        cost_center_ids = insert_test_data(conn, "cost_centers", cost_centers)
        fixed_cost_ids = insert_test_data(conn, "fixed_costs", fixed_costs)
        operational_cost_ids = insert_test_data(conn, "operational_costs", operational_costs)
        cost_allocation_ids = insert_test_data(conn, "cost_allocations", cost_allocations)
        material_cost_ids = insert_test_data(conn, "material_costs", material_costs)
        labor_cost_ids = insert_test_data(conn, "labor_costs", labor_costs)
        cost_template_ids = insert_test_data(conn, "cost_templates", cost_templates)
        pricing_rule_ids = insert_test_data(conn, "pricing_rules", pricing_rules)
        
        print("\nDeployment completed successfully!")
        print(f"Deployed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("\nSummary of deployed data:")
        print(f"Cost Centers: {len(cost_center_ids)}")
        print(f"Fixed Costs: {len(fixed_cost_ids)}")
        print(f"Operational Costs: {len(operational_cost_ids)}")
        print(f"Cost Allocations: {len(cost_allocation_ids)}")
        print(f"Material Costs: {len(material_cost_ids)}")
        print(f"Labor Costs: {len(labor_cost_ids)}")
        print(f"Cost Templates: {len(cost_template_ids)}")
        print(f"Pricing Rules: {len(pricing_rule_ids)}")
        
    except Exception as e:
        print(f"Error during deployment: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    main()
