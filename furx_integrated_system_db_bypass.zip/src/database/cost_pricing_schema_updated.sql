-- Updated Database Schema for Cost and Pricing System

-- Cost Centers Table (New)
CREATE TABLE cost_centers (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    center_name VARCHAR(255) NOT NULL,
    center_type VARCHAR(50) NOT NULL, -- 'department', 'workshop', 'other'
    department_id INTEGER REFERENCES departments(id),
    workshop_id INTEGER REFERENCES workshops(id),
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cost Allocations Table (New)
CREATE TABLE cost_allocations (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    cost_center_id INTEGER NOT NULL REFERENCES cost_centers(id),
    cost_type VARCHAR(50) NOT NULL, -- 'fixed', 'variable', 'operational'
    cost_id INTEGER NOT NULL, -- references the respective cost table
    allocation_percentage DECIMAL(5, 2) NOT NULL,
    start_date DATE NOT NULL DEFAULT CURRENT_DATE,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Historical Cost Data Table (New)
CREATE TABLE historical_cost_data (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    product_id INTEGER NOT NULL REFERENCES products(id),
    direct_labor_cost DECIMAL(15, 2) NOT NULL,
    material_cost DECIMAL(15, 2) NOT NULL,
    indirect_cost_allocation DECIMAL(15, 2) NOT NULL,
    total_cost DECIMAL(15, 2) NOT NULL,
    reference_period VARCHAR(100), -- e.g., 'Q1 2024', 'Jan 2025'
    is_imported BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Fixed Costs Table
CREATE TABLE fixed_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    cost_name VARCHAR(255) NOT NULL,
    cost_category VARCHAR(100) NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    frequency VARCHAR(50) NOT NULL, -- monthly, quarterly, yearly
    allocation_method VARCHAR(50) NOT NULL, -- direct, percentage, activity_based
    allocation_basis VARCHAR(50), -- product_count, revenue, etc.
    start_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Variable Costs Table
CREATE TABLE variable_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    cost_name VARCHAR(255) NOT NULL,
    cost_category VARCHAR(100) NOT NULL,
    unit_of_measure VARCHAR(50) NOT NULL,
    cost_per_unit DECIMAL(15, 2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Material Costs Table
CREATE TABLE material_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    material_id INTEGER NOT NULL REFERENCES inventory_items(id),
    cost_per_unit DECIMAL(15, 2) NOT NULL,
    wastage_percentage DECIMAL(5, 2) DEFAULT 0,
    last_purchase_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, material_id)
);

-- Labor Costs Table
CREATE TABLE labor_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    department_id INTEGER REFERENCES departments(id),
    workshop_id INTEGER REFERENCES workshops(id),
    labor_category VARCHAR(100) NOT NULL,
    cost_per_hour DECIMAL(15, 2) NOT NULL,
    overhead_percentage DECIMAL(5, 2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Operational Costs Table
CREATE TABLE operational_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    cost_center_id INTEGER REFERENCES cost_centers(id), -- Link to cost center
    cost_name VARCHAR(255) NOT NULL,
    cost_category VARCHAR(100) NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    frequency VARCHAR(50) NOT NULL, -- daily, weekly, monthly
    allocation_method VARCHAR(50) NOT NULL, -- direct, percentage, activity_based
    start_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cost Templates Table
CREATE TABLE cost_templates (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    template_name VARCHAR(255) NOT NULL,
    template_description TEXT,
    product_category VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cost Template Components Table
CREATE TABLE cost_template_components (
    id SERIAL PRIMARY KEY,
    template_id INTEGER NOT NULL REFERENCES cost_templates(id) ON DELETE CASCADE,
    component_type VARCHAR(50) NOT NULL, -- material, labor, operational, other
    component_name VARCHAR(255) NOT NULL,
    cost_category VARCHAR(100) NOT NULL,
    quantity DECIMAL(10, 2) DEFAULT 1,
    unit_cost DECIMAL(15, 2) DEFAULT 0,
    wastage_percentage DECIMAL(5, 2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Product Costs Table
CREATE TABLE product_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    product_id INTEGER NOT NULL REFERENCES products(id),
    cost_template_id INTEGER REFERENCES cost_templates(id),
    total_material_cost DECIMAL(15, 2) DEFAULT 0,
    total_labor_cost DECIMAL(15, 2) DEFAULT 0,
    total_operational_cost DECIMAL(15, 2) DEFAULT 0,
    total_overhead_cost DECIMAL(15, 2) DEFAULT 0, -- Allocated indirect costs
    total_cost DECIMAL(15, 2) DEFAULT 0,
    calculation_date TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, product_id)
);

-- Product Cost Components Table (Detailed breakdown for calculated product cost)
CREATE TABLE product_cost_components (
    id SERIAL PRIMARY KEY,
    product_cost_id INTEGER NOT NULL REFERENCES product_costs(id) ON DELETE CASCADE,
    component_type VARCHAR(50) NOT NULL, -- material, labor, operational, overhead
    component_name VARCHAR(255) NOT NULL,
    cost_category VARCHAR(100) NOT NULL,
    quantity DECIMAL(10, 2) DEFAULT 1,
    unit_cost DECIMAL(15, 2) DEFAULT 0,
    total_cost DECIMAL(15, 2) DEFAULT 0,
    wastage_percentage DECIMAL(5, 2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pricing Rules Table
CREATE TABLE pricing_rules (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    rule_name VARCHAR(255) NOT NULL,
    product_category VARCHAR(100),
    product_id INTEGER REFERENCES products(id),
    customer_category VARCHAR(100),
    markup_percentage DECIMAL(5, 2) NOT NULL,
    discount_percentage DECIMAL(5, 2) DEFAULT 0,
    min_profit_margin DECIMAL(5, 2) DEFAULT 0,
    priority INTEGER DEFAULT 10, -- Lower number means higher priority
    is_active BOOLEAN DEFAULT TRUE,
    start_date DATE,
    end_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Invoice Costs Table
CREATE TABLE invoice_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    invoice_id INTEGER NOT NULL REFERENCES invoices(id),
    total_material_cost DECIMAL(15, 2) DEFAULT 0,
    total_labor_cost DECIMAL(15, 2) DEFAULT 0,
    total_operational_cost DECIMAL(15, 2) DEFAULT 0,
    total_overhead_cost DECIMAL(15, 2) DEFAULT 0,
    total_cost DECIMAL(15, 2) DEFAULT 0,
    total_price DECIMAL(15, 2) DEFAULT 0,
    gross_profit DECIMAL(15, 2) DEFAULT 0,
    profit_margin_percentage DECIMAL(5, 2) DEFAULT 0,
    calculated_at TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Invoice Item Costs Table
CREATE TABLE invoice_item_costs (
    id SERIAL PRIMARY KEY,
    invoice_cost_id INTEGER NOT NULL REFERENCES invoice_costs(id) ON DELETE CASCADE,
    invoice_item_id INTEGER NOT NULL REFERENCES invoice_items(id),
    product_cost_id INTEGER REFERENCES product_costs(id),
    material_cost DECIMAL(15, 2) DEFAULT 0,
    labor_cost DECIMAL(15, 2) DEFAULT 0,
    operational_cost DECIMAL(15, 2) DEFAULT 0,
    overhead_cost DECIMAL(15, 2) DEFAULT 0,
    total_cost DECIMAL(15, 2) DEFAULT 0,
    price DECIMAL(15, 2) DEFAULT 0,
    quantity INTEGER NOT NULL,
    total_item_cost DECIMAL(15, 2) DEFAULT 0,
    total_item_price DECIMAL(15, 2) DEFAULT 0,
    profit DECIMAL(15, 2) DEFAULT 0,
    profit_margin_percentage DECIMAL(5, 2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cost Calculation History Table
CREATE TABLE cost_calculation_history (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    calculation_type VARCHAR(50) NOT NULL, -- product, invoice, distribution
    reference_id INTEGER NOT NULL, -- product_id, invoice_id, or distribution_run_id
    previous_total_cost DECIMAL(15, 2),
    new_total_cost DECIMAL(15, 2),
    change_percentage DECIMAL(5, 2),
    calculated_by INTEGER REFERENCES users(id),
    calculation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Cost Center Period Allocations Table (New for Step 6)
CREATE TABLE cost_center_period_allocations (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    cost_center_id INTEGER NOT NULL REFERENCES cost_centers(id),
    period_start_date DATE NOT NULL,
    period_end_date DATE NOT NULL,
    cost_type VARCHAR(50) NOT NULL, -- 'fixed', 'operational', 'total_overhead'
    allocated_amount DECIMAL(15, 2) NOT NULL,
    calculation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    UNIQUE(company_id, cost_center_id, period_start_date, period_end_date, cost_type)
);

-- Indexes for performance
CREATE INDEX idx_cost_centers_company ON cost_centers(company_id);
CREATE INDEX idx_cost_centers_dept_workshop ON cost_centers(department_id, workshop_id);
CREATE INDEX idx_cost_allocations_company ON cost_allocations(company_id);
CREATE INDEX idx_cost_allocations_center ON cost_allocations(cost_center_id);
CREATE INDEX idx_historical_cost_data_company_product ON historical_cost_data(company_id, product_id);
CREATE INDEX idx_fixed_costs_company ON fixed_costs(company_id);
CREATE INDEX idx_variable_costs_company ON variable_costs(company_id);
CREATE INDEX idx_material_costs_company_material ON material_costs(company_id, material_id);
CREATE INDEX idx_labor_costs_company_dept_workshop ON labor_costs(company_id, department_id, workshop_id);
CREATE INDEX idx_operational_costs_company_cost_center ON operational_costs(company_id, cost_center_id);
CREATE INDEX idx_cost_templates_company ON cost_templates(company_id);
CREATE INDEX idx_cost_template_items_template ON cost_template_items(template_id);
CREATE INDEX idx_product_costs_company_product ON product_costs(company_id, product_id);
CREATE INDEX idx_product_cost_components_product_cost ON product_cost_components(product_cost_id);
CREATE INDEX idx_pricing_rules_company ON pricing_rules(company_id);
CREATE INDEX idx_pricing_rules_product ON pricing_rules(product_id);
CREATE INDEX idx_invoice_costs_company_invoice ON invoice_costs(company_id, invoice_id);
CREATE INDEX idx_invoice_item_costs_invoice_cost ON invoice_item_costs(invoice_cost_id);
CREATE INDEX idx_cost_calculation_history_company_type_ref ON cost_calculation_history(company_id, calculation_type, reference_id);
CREATE INDEX idx_cost_center_period_allocations_company_center_period ON cost_center_period_allocations(company_id, cost_center_id, period_start_date, period_end_date);

