-- Database Schema for Cost and Pricing System

-- Fixed Costs Table
CREATE TABLE fixed_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    cost_name VARCHAR(255) NOT NULL,
    cost_category VARCHAR(100) NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    frequency VARCHAR(50) NOT NULL, -- monthly, quarterly, yearly
    allocation_method VARCHAR(50) NOT NULL, -- equal, proportional, custom
    allocation_basis VARCHAR(50), -- product_count, revenue, etc.
    start_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Variable Costs Table
CREATE TABLE variable_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    cost_name VARCHAR(255) NOT NULL,
    cost_category VARCHAR(100) NOT NULL,
    unit_of_measure VARCHAR(50) NOT NULL,
    cost_per_unit DECIMAL(15, 2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Material Costs Table
CREATE TABLE material_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    material_id INTEGER NOT NULL REFERENCES inventory_items(id),
    cost_per_unit DECIMAL(15, 2) NOT NULL,
    wastage_percentage DECIMAL(5, 2) DEFAULT 0,
    last_purchase_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Labor Costs Table
CREATE TABLE labor_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    department_id INTEGER REFERENCES departments(id),
    workshop_id INTEGER REFERENCES workshops(id),
    labor_category VARCHAR(100) NOT NULL,
    cost_per_hour DECIMAL(15, 2) NOT NULL,
    overhead_percentage DECIMAL(5, 2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Operational Costs Table
CREATE TABLE operational_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    department_id INTEGER REFERENCES departments(id),
    workshop_id INTEGER REFERENCES workshops(id),
    cost_name VARCHAR(255) NOT NULL,
    cost_category VARCHAR(100) NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    frequency VARCHAR(50) NOT NULL, -- daily, weekly, monthly
    allocation_method VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cost Templates Table
CREATE TABLE cost_templates (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    template_name VARCHAR(255) NOT NULL,
    product_category VARCHAR(100),
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cost Template Items Table
CREATE TABLE cost_template_items (
    id SERIAL PRIMARY KEY,
    template_id INTEGER NOT NULL REFERENCES cost_templates(id),
    cost_type VARCHAR(50) NOT NULL, -- fixed, variable, material, labor, operational
    cost_id INTEGER NOT NULL, -- references the respective cost table
    allocation_percentage DECIMAL(5, 2) DEFAULT 100,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Product Costs Table
CREATE TABLE product_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    product_id INTEGER NOT NULL REFERENCES products(id),
    template_id INTEGER REFERENCES cost_templates(id),
    material_cost DECIMAL(15, 2) DEFAULT 0,
    labor_cost DECIMAL(15, 2) DEFAULT 0,
    operational_cost DECIMAL(15, 2) DEFAULT 0,
    fixed_cost_allocation DECIMAL(15, 2) DEFAULT 0,
    variable_cost DECIMAL(15, 2) DEFAULT 0,
    total_cost DECIMAL(15, 2) DEFAULT 0,
    last_calculated_at TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pricing Rules Table
CREATE TABLE pricing_rules (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    rule_name VARCHAR(255) NOT NULL,
    product_category VARCHAR(100),
    customer_category VARCHAR(100),
    markup_percentage DECIMAL(5, 2) NOT NULL,
    discount_percentage DECIMAL(5, 2) DEFAULT 0,
    min_profit_margin DECIMAL(5, 2) NOT NULL,
    priority INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    start_date DATE,
    end_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Invoice Costs Table
CREATE TABLE invoice_costs (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    invoice_id INTEGER NOT NULL REFERENCES invoices(id),
    total_material_cost DECIMAL(15, 2) DEFAULT 0,
    total_labor_cost DECIMAL(15, 2) DEFAULT 0,
    total_operational_cost DECIMAL(15, 2) DEFAULT 0,
    total_fixed_cost DECIMAL(15, 2) DEFAULT 0,
    total_variable_cost DECIMAL(15, 2) DEFAULT 0,
    total_cost DECIMAL(15, 2) DEFAULT 0,
    total_price DECIMAL(15, 2) DEFAULT 0,
    gross_profit DECIMAL(15, 2) DEFAULT 0,
    profit_margin_percentage DECIMAL(5, 2) DEFAULT 0,
    calculated_at TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Invoice Item Costs Table
CREATE TABLE invoice_item_costs (
    id SERIAL PRIMARY KEY,
    invoice_cost_id INTEGER NOT NULL REFERENCES invoice_costs(id),
    invoice_item_id INTEGER NOT NULL REFERENCES invoice_items(id),
    product_cost_id INTEGER REFERENCES product_costs(id),
    material_cost DECIMAL(15, 2) DEFAULT 0,
    labor_cost DECIMAL(15, 2) DEFAULT 0,
    operational_cost DECIMAL(15, 2) DEFAULT 0,
    fixed_cost DECIMAL(15, 2) DEFAULT 0,
    variable_cost DECIMAL(15, 2) DEFAULT 0,
    total_cost DECIMAL(15, 2) DEFAULT 0,
    price DECIMAL(15, 2) DEFAULT 0,
    quantity INTEGER NOT NULL,
    total_item_cost DECIMAL(15, 2) DEFAULT 0,
    total_item_price DECIMAL(15, 2) DEFAULT 0,
    profit DECIMAL(15, 2) DEFAULT 0,
    profit_margin_percentage DECIMAL(5, 2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cost Calculation History Table
CREATE TABLE cost_calculation_history (
    id SERIAL PRIMARY KEY,
    company_id INTEGER NOT NULL REFERENCES companies(id),
    calculation_type VARCHAR(50) NOT NULL, -- product, invoice
    reference_id INTEGER NOT NULL, -- product_id or invoice_id
    previous_total_cost DECIMAL(15, 2),
    new_total_cost DECIMAL(15, 2),
    change_percentage DECIMAL(5, 2),
    calculated_by INTEGER REFERENCES users(id),
    calculation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Indexes for performance
CREATE INDEX idx_fixed_costs_company ON fixed_costs(company_id);
CREATE INDEX idx_variable_costs_company ON variable_costs(company_id);
CREATE INDEX idx_material_costs_company_material ON material_costs(company_id, material_id);
CREATE INDEX idx_labor_costs_company_dept_workshop ON labor_costs(company_id, department_id, workshop_id);
CREATE INDEX idx_operational_costs_company_dept_workshop ON operational_costs(company_id, department_id, workshop_id);
CREATE INDEX idx_cost_templates_company ON cost_templates(company_id);
CREATE INDEX idx_cost_template_items_template ON cost_template_items(template_id);
CREATE INDEX idx_product_costs_company_product ON product_costs(company_id, product_id);
CREATE INDEX idx_pricing_rules_company ON pricing_rules(company_id);
CREATE INDEX idx_invoice_costs_company_invoice ON invoice_costs(company_id, invoice_id);
CREATE INDEX idx_invoice_item_costs_invoice_cost ON invoice_item_costs(invoice_cost_id);
CREATE INDEX idx_cost_calculation_history_company_type_ref ON cost_calculation_history(company_id, calculation_type, reference_id);
