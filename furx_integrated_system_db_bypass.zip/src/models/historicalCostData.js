const db = require("../config/database");

/**
 * Historical Cost Data Model
 * Handles database operations for imported historical cost data
 */
class HistoricalCostData {
  /**
   * Create a new historical cost data entry
   * @param {Object} historicalData - Historical cost data
   * @returns {Promise<Object>} Created historical data entry
   */
  static async create(historicalData) {
    const query = `
      INSERT INTO historical_cost_data (
        company_id, product_id, direct_labor_cost, material_cost, 
        indirect_cost_allocation, total_cost, reference_period, 
        is_imported, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *
    `;
    
    const values = [
      historicalData.company_id,
      historicalData.product_id,
      historicalData.direct_labor_cost,
      historicalData.material_cost,
      historicalData.indirect_cost_allocation,
      historicalData.total_cost,
      historicalData.reference_period,
      historicalData.is_imported !== undefined ? historicalData.is_imported : true,
      historicalData.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating historical cost data: ${error.message}`);
    }
  }
  
  /**
   * Bulk insert historical cost data
   * @param {Array<Object>} dataList - List of historical cost data objects
   * @returns {Promise<number>} Number of rows inserted
   */
  static async bulkInsert(dataList) {
    if (!dataList || dataList.length === 0) {
      return 0;
    }
    
    const client = await db.getClient();
    try {
      await client.query("BEGIN");
      
      const query = `
        INSERT INTO historical_cost_data (
          company_id, product_id, direct_labor_cost, material_cost, 
          indirect_cost_allocation, total_cost, reference_period, 
          is_imported, notes
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      `;
      
      let insertedCount = 0;
      for (const historicalData of dataList) {
        const values = [
          historicalData.company_id,
          historicalData.product_id,
          historicalData.direct_labor_cost,
          historicalData.material_cost,
          historicalData.indirect_cost_allocation,
          historicalData.total_cost,
          historicalData.reference_period,
          historicalData.is_imported !== undefined ? historicalData.is_imported : true,
          historicalData.notes
        ];
        const result = await client.query(query, values);
        insertedCount += result.rowCount;
      }
      
      await client.query("COMMIT");
      return insertedCount;
    } catch (error) {
      await client.query("ROLLBACK");
      throw new Error(`Error bulk inserting historical cost data: ${error.message}`);
    } finally {
      client.release();
    }
  }
  
  /**
   * Get all historical cost data for a company
   * @param {number} companyId - Company ID
   * @param {string} [referencePeriod] - Filter by reference period
   * @returns {Promise<Array>} List of historical cost data
   */
  static async getAllByCompany(companyId, referencePeriod = null) {
    let query = `
      SELECT hcd.*, p.product_name, p.product_code 
      FROM historical_cost_data hcd
      JOIN products p ON hcd.product_id = p.id
      WHERE hcd.company_id = $1
    `;
    
    const values = [companyId];
    
    if (referencePeriod) {
      query += ` AND hcd.reference_period = $${values.length + 1}`;
      values.push(referencePeriod);
    }
    
    query += ` ORDER BY hcd.reference_period DESC, p.product_name`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching historical cost data: ${error.message}`);
    }
  }
  
  /**
   * Get historical cost data for a specific product
   * @param {number} companyId - Company ID
   * @param {number} productId - Product ID
   * @returns {Promise<Array>} List of historical cost data for the product
   */
  static async getByProduct(companyId, productId) {
    const query = `
      SELECT hcd.*, p.product_name, p.product_code 
      FROM historical_cost_data hcd
      JOIN products p ON hcd.product_id = p.id
      WHERE hcd.company_id = $1 AND hcd.product_id = $2
      ORDER BY hcd.reference_period DESC
    `;
    
    try {
      const result = await db.query(query, [companyId, productId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching historical cost data for product: ${error.message}`);
    }
  }
  
  /**
   * Delete historical cost data
   * @param {number} id - Historical data ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    const query = `
      DELETE FROM historical_cost_data 
      WHERE id = $1
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows.length > 0;
    } catch (error) {
      throw new Error(`Error deleting historical cost data: ${error.message}`);
    }
  }
  
  /**
   * Delete all historical cost data for a company
   * @param {number} companyId - Company ID
   * @returns {Promise<number>} Number of rows deleted
   */
  static async deleteAllByCompany(companyId) {
    const query = `
      DELETE FROM historical_cost_data 
      WHERE company_id = $1
    `;
    
    try {
      const result = await db.query(query, [companyId]);
      return result.rowCount;
    } catch (error) {
      throw new Error(`Error deleting all historical cost data for company: ${error.message}`);
    }
  }
}

module.exports = HistoricalCostData;

