const db = require('../config/database');

/**
 * Inventory Model
 * Handles database operations for inventory management
 * Includes company_id to support multi-company structure
 */
class Inventory {
  /**
   * Get all material inventory items for a specific company
   * @param {number} companyId - Company ID
   * @returns {Promise<Array>} Array of material inventory objects
   */
  static async getMaterialInventoryByCompany(companyId) {
    try {
      const result = await db.query(
        `SELECT mi.*, m.material_name, m.material_code, l.location_name 
         FROM material_inventory mi
         JOIN materials m ON mi.material_id = m.material_id
         JOIN inventory_locations l ON mi.location_id = l.location_id
         WHERE mi.company_id = $1`,
        [companyId]
      );
      return result.rows;
    } catch (error) {
      console.error(`Error in getMaterialInventoryByCompany for company ${companyId}:`, error);
      throw error;
    }
  }

  /**
   * Get all product inventory items for a specific company
   * @param {number} companyId - Company ID
   * @returns {Promise<Array>} Array of product inventory objects
   */
  static async getProductInventoryByCompany(companyId) {
    try {
      const result = await db.query(
        `SELECT pi.*, p.product_name, p.product_sku, l.location_name 
         FROM product_inventory pi
         JOIN products p ON pi.product_id = p.product_id
         JOIN inventory_locations l ON pi.location_id = l.location_id
         WHERE pi.company_id = $1`,
        [companyId]
      );
      return result.rows;
    } catch (error) {
      console.error(`Error in getProductInventoryByCompany for company ${companyId}:`, error);
      throw error;
    }
  }

  /**
   * Update material inventory quantity
   * @param {number} materialId - Material ID
   * @param {number} locationId - Location ID
   * @param {number} companyId - Company ID
   * @param {number} quantityChange - Quantity to add (positive) or subtract (negative)
   * @param {string} transactionType - Type of transaction (Receipt, Issue, Adjustment)
   * @param {string} relatedDocumentId - Related document ID (e.g., PO number)
   * @param {number} employeeId - Employee who performed the transaction
   * @returns {Promise<Object>} Updated inventory record
   */
  static async updateMaterialInventory(materialId, locationId, companyId, quantityChange, transactionType, relatedDocumentId, employeeId) {
    try {
      // Start a transaction
      await db.query('BEGIN');

      // Check if inventory record exists
      const checkResult = await db.query(
        'SELECT * FROM material_inventory WHERE material_id = $1 AND location_id = $2 AND company_id = $3',
        [materialId, locationId, companyId]
      );

      let inventoryRecord;
      
      if (checkResult.rows.length === 0) {
        // Create new inventory record if it doesn't exist
        const insertResult = await db.query(
          `INSERT INTO material_inventory 
          (material_id, location_id, company_id, quantity_on_hand, last_updated_at) 
          VALUES ($1, $2, $3, $4, NOW()) 
          RETURNING *`,
          [materialId, locationId, companyId, quantityChange]
        );
        inventoryRecord = insertResult.rows[0];
      } else {
        // Update existing inventory record
        const updateResult = await db.query(
          `UPDATE material_inventory 
          SET quantity_on_hand = quantity_on_hand + $1, 
              last_updated_at = NOW() 
          WHERE material_id = $2 AND location_id = $3 AND company_id = $4 
          RETURNING *`,
          [quantityChange, materialId, locationId, companyId]
        );
        inventoryRecord = updateResult.rows[0];
      }

      // Log the transaction
      await db.query(
        `INSERT INTO inventory_transactions 
        (material_id, transaction_type, quantity, location_id, company_id, related_document_id, employee_id, transaction_datetime) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
        [materialId, transactionType, quantityChange, locationId, companyId, relatedDocumentId, employeeId]
      );

      // Commit the transaction
      await db.query('COMMIT');

      return inventoryRecord;
    } catch (error) {
      // Rollback in case of error
      await db.query('ROLLBACK');
      console.error(`Error in updateMaterialInventory for material ${materialId}:`, error);
      throw error;
    }
  }

  /**
   * Update product inventory quantity
   * @param {number} productId - Product ID
   * @param {number} locationId - Location ID
   * @param {number} companyId - Company ID
   * @param {number} quantityChange - Quantity to add (positive) or subtract (negative)
   * @param {string} transactionType - Type of transaction (Receipt, Issue, Adjustment)
   * @param {string} relatedDocumentId - Related document ID (e.g., production order ID)
   * @param {number} employeeId - Employee who performed the transaction
   * @returns {Promise<Object>} Updated inventory record
   */
  static async updateProductInventory(productId, locationId, companyId, quantityChange, transactionType, relatedDocumentId, employeeId) {
    try {
      // Start a transaction
      await db.query('BEGIN');

      // Check if inventory record exists
      const checkResult = await db.query(
        'SELECT * FROM product_inventory WHERE product_id = $1 AND location_id = $2 AND company_id = $3',
        [productId, locationId, companyId]
      );

      let inventoryRecord;
      
      if (checkResult.rows.length === 0) {
        // Create new inventory record if it doesn't exist
        const insertResult = await db.query(
          `INSERT INTO product_inventory 
          (product_id, location_id, company_id, quantity_on_hand, last_updated_at) 
          VALUES ($1, $2, $3, $4, NOW()) 
          RETURNING *`,
          [productId, locationId, companyId, quantityChange]
        );
        inventoryRecord = insertResult.rows[0];
      } else {
        // Update existing inventory record
        const updateResult = await db.query(
          `UPDATE product_inventory 
          SET quantity_on_hand = quantity_on_hand + $1, 
              last_updated_at = NOW() 
          WHERE product_id = $2 AND location_id = $3 AND company_id = $4 
          RETURNING *`,
          [quantityChange, productId, locationId, companyId]
        );
        inventoryRecord = updateResult.rows[0];
      }

      // Log the transaction
      await db.query(
        `INSERT INTO inventory_transactions 
        (product_id, transaction_type, quantity, location_id, company_id, related_document_id, employee_id, transaction_datetime) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
        [productId, transactionType, quantityChange, locationId, companyId, relatedDocumentId, employeeId]
      );

      // Commit the transaction
      await db.query('COMMIT');

      return inventoryRecord;
    } catch (error) {
      // Rollback in case of error
      await db.query('ROLLBACK');
      console.error(`Error in updateProductInventory for product ${productId}:`, error);
      throw error;
    }
  }

  /**
   * Get inventory transaction history for a company
   * @param {number} companyId - Company ID
   * @param {Object} filters - Optional filters (materialId, productId, locationId, startDate, endDate)
   * @returns {Promise<Array>} Array of transaction objects
   */
  static async getTransactionHistory(companyId, filters = {}) {
    try {
      let query = `
        SELECT t.*, 
               m.material_name, m.material_code,
               p.product_name, p.product_sku,
               l.location_name,
               CONCAT(e.first_name, ' ', e.last_name) as employee_name
        FROM inventory_transactions t
        LEFT JOIN materials m ON t.material_id = m.material_id
        LEFT JOIN products p ON t.product_id = p.product_id
        JOIN inventory_locations l ON t.location_id = l.location_id
        JOIN employees e ON t.employee_id = e.employee_id
        WHERE t.company_id = $1
      `;
      
      const queryParams = [companyId];
      let paramIndex = 2;
      
      if (filters.materialId) {
        query += ` AND t.material_id = $${paramIndex}`;
        queryParams.push(filters.materialId);
        paramIndex++;
      }
      
      if (filters.productId) {
        query += ` AND t.product_id = $${paramIndex}`;
        queryParams.push(filters.productId);
        paramIndex++;
      }
      
      if (filters.locationId) {
        query += ` AND t.location_id = $${paramIndex}`;
        queryParams.push(filters.locationId);
        paramIndex++;
      }
      
      if (filters.startDate) {
        query += ` AND t.transaction_datetime >= $${paramIndex}`;
        queryParams.push(filters.startDate);
        paramIndex++;
      }
      
      if (filters.endDate) {
        query += ` AND t.transaction_datetime <= $${paramIndex}`;
        queryParams.push(filters.endDate);
        paramIndex++;
      }
      
      query += ` ORDER BY t.transaction_datetime DESC`;
      
      const result = await db.query(query, queryParams);
      return result.rows;
    } catch (error) {
      console.error(`Error in getTransactionHistory for company ${companyId}:`, error);
      throw error;
    }
  }
}

module.exports = Inventory;
