const db = require("../config/database");

/**
 * Material Costs Model
 * Handles database operations for material costs
 */
class MaterialCost {
  /**
   * Create or update a material cost
   * @param {Object} materialCost - Material cost data
   * @returns {Promise<Object>} Created or updated material cost
   */
  static async upsert(materialCost) {
    const query = `
      INSERT INTO material_costs (
        company_id, material_id, cost_per_unit, wastage_percentage, 
        last_purchase_date, is_active, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      ON CONFLICT (company_id, material_id) 
      DO UPDATE SET 
        cost_per_unit = EXCLUDED.cost_per_unit,
        wastage_percentage = EXCLUDED.wastage_percentage,
        last_purchase_date = EXCLUDED.last_purchase_date,
        is_active = EXCLUDED.is_active,
        notes = EXCLUDED.notes,
        updated_at = CURRENT_TIMESTAMP
      RETURNING *
    `;
    
    const values = [
      materialCost.company_id,
      materialCost.material_id,
      materialCost.cost_per_unit,
      materialCost.wastage_percentage || 0,
      materialCost.last_purchase_date,
      materialCost.is_active !== undefined ? materialCost.is_active : true,
      materialCost.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error upserting material cost: ${error.message}`);
    }
  }
  
  /**
   * Get all material costs for a company
   * @param {number} companyId - Company ID
   * @param {boolean} activeOnly - Get only active material costs
   * @returns {Promise<Array>} List of material costs with item details
   */
  static async getAllByCompany(companyId, activeOnly = true) {
    let query = `
      SELECT mc.*, ii.item_name, ii.unit_of_measure 
      FROM material_costs mc
      JOIN inventory_items ii ON mc.material_id = ii.id
      WHERE mc.company_id = $1
    `;
    
    const values = [companyId];
    
    if (activeOnly) {
      query += ` AND mc.is_active = true`;
    }
    
    query += ` ORDER BY ii.item_name`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching material costs: ${error.message}`);
    }
  }
  
  /**
   * Get a material cost by material ID
   * @param {number} companyId - Company ID
   * @param {number} materialId - Material ID (inventory_item_id)
   * @returns {Promise<Object>} Material cost
   */
  static async getByMaterialId(companyId, materialId) {
    const query = `
      SELECT mc.*, ii.item_name, ii.unit_of_measure 
      FROM material_costs mc
      JOIN inventory_items ii ON mc.material_id = ii.id
      WHERE mc.company_id = $1 AND mc.material_id = $2
    `;
    
    try {
      const result = await db.query(query, [companyId, materialId]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching material cost: ${error.message}`);
    }
  }
  
  /**
   * Get a material cost by ID
   * @param {number} id - Material cost ID
   * @returns {Promise<Object>} Material cost with item details
   */
  static async getById(id) {
    const query = `
      SELECT mc.*, ii.item_name, ii.unit_of_measure 
      FROM material_costs mc
      JOIN inventory_items ii ON mc.material_id = ii.id
      WHERE mc.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching material cost: ${error.message}`);
    }
  }
  
  /**
   * Update a material cost
   * @param {number} id - Material cost ID
   * @param {Object} materialCost - Updated material cost data
   * @returns {Promise<Object>} Updated material cost
   */
  static async update(id, materialCost) {
    const query = `
      UPDATE material_costs 
      SET 
        cost_per_unit = $1,
        wastage_percentage = $2,
        last_purchase_date = $3,
        is_active = $4,
        notes = $5,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $6
      RETURNING *
    `;
    
    const values = [
      materialCost.cost_per_unit,
      materialCost.wastage_percentage,
      materialCost.last_purchase_date,
      materialCost.is_active,
      materialCost.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating material cost: ${error.message}`);
    }
  }
  
  /**
   * Delete a material cost
   * @param {number} id - Material cost ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    const query = `
      DELETE FROM material_costs 
      WHERE id = $1
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows.length > 0;
    } catch (error) {
      throw new Error(`Error deleting material cost: ${error.message}`);
    }
  }
  
  /**
   * Get the cost for a specific material, considering wastage
   * @param {number} companyId - Company ID
   * @param {number} materialId - Material ID
   * @returns {Promise<number>} Effective cost per unit
   */
  static async getEffectiveCost(companyId, materialId) {
    try {
      const materialCost = await this.getByMaterialId(companyId, materialId);
      if (!materialCost || !materialCost.is_active) {
        return 0; // Or throw an error if cost is required
      }
      
      const cost = parseFloat(materialCost.cost_per_unit || 0);
      const wastage = parseFloat(materialCost.wastage_percentage || 0);
      
      // Effective cost = Cost / (1 - Wastage Percentage)
      const effectiveCost = cost / (1 - wastage / 100);
      
      return effectiveCost;
    } catch (error) {
      throw new Error(`Error calculating effective material cost: ${error.message}`);
    }
  }
  
  /**
   * Bulk update material costs
   * @param {Array<Object>} materialCosts - Array of material cost objects
   * @returns {Promise<number>} Number of updated records
   */
  static async bulkUpdate(materialCosts) {
    if (!materialCosts || materialCosts.length === 0) {
      return 0;
    }
    
    const client = await db.getClient();
    try {
      await client.query("BEGIN");
      
      let updatedCount = 0;
      for (const materialCost of materialCosts) {
        const result = await this.upsert(materialCost);
        if (result) {
          updatedCount++;
        }
      }
      
      await client.query("COMMIT");
      return updatedCount;
    } catch (error) {
      await client.query("ROLLBACK");
      throw new Error(`Error bulk updating material costs: ${error.message}`);
    } finally {
      client.release();
    }
  }
}

module.exports = MaterialCost;
