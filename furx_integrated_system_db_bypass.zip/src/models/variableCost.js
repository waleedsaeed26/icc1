const db = require("../config/database");

/**
 * Variable Costs Model
 * Handles database operations for variable costs
 */
class VariableCost {
  /**
   * Create a new variable cost
   * @param {Object} variableCost - Variable cost data
   * @returns {Promise<Object>} Created variable cost
   */
  static async create(variableCost) {
    const query = `
      INSERT INTO variable_costs (
        company_id, cost_name, cost_category, unit_of_measure, 
        cost_per_unit, is_active, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `;
    
    const values = [
      variableCost.company_id,
      variableCost.cost_name,
      variableCost.cost_category,
      variableCost.unit_of_measure,
      variableCost.cost_per_unit,
      variableCost.is_active !== undefined ? variableCost.is_active : true,
      variableCost.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating variable cost: ${error.message}`);
    }
  }
  
  /**
   * Get all variable costs for a company
   * @param {number} companyId - Company ID
   * @param {boolean} activeOnly - Get only active variable costs
   * @returns {Promise<Array>} List of variable costs
   */
  static async getAllByCompany(companyId, activeOnly = true) {
    let query = `
      SELECT * FROM variable_costs 
      WHERE company_id = $1
    `;
    
    const values = [companyId];
    
    if (activeOnly) {
      query += ` AND is_active = true`;
    }
    
    query += ` ORDER BY cost_category, cost_name`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching variable costs: ${error.message}`);
    }
  }
  
  /**
   * Get a variable cost by ID
   * @param {number} id - Variable cost ID
   * @returns {Promise<Object>} Variable cost
   */
  static async getById(id) {
    const query = `
      SELECT * FROM variable_costs 
      WHERE id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching variable cost: ${error.message}`);
    }
  }
  
  /**
   * Update a variable cost
   * @param {number} id - Variable cost ID
   * @param {Object} variableCost - Updated variable cost data
   * @returns {Promise<Object>} Updated variable cost
   */
  static async update(id, variableCost) {
    const query = `
      UPDATE variable_costs 
      SET 
        cost_name = $1,
        cost_category = $2,
        unit_of_measure = $3,
        cost_per_unit = $4,
        is_active = $5,
        notes = $6,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $7
      RETURNING *
    `;
    
    const values = [
      variableCost.cost_name,
      variableCost.cost_category,
      variableCost.unit_of_measure,
      variableCost.cost_per_unit,
      variableCost.is_active,
      variableCost.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating variable cost: ${error.message}`);
    }
  }
  
  /**
   * Delete a variable cost
   * @param {number} id - Variable cost ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    const query = `
      DELETE FROM variable_costs 
      WHERE id = $1
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows.length > 0;
    } catch (error) {
      throw new Error(`Error deleting variable cost: ${error.message}`);
    }
  }
  
  /**
   * Get variable costs by category
   * @param {number} companyId - Company ID
   * @param {string} category - Cost category
   * @returns {Promise<Array>} List of variable costs
   */
  static async getByCategory(companyId, category) {
    const query = `
      SELECT * FROM variable_costs 
      WHERE company_id = $1 
        AND cost_category = $2
        AND is_active = true
      ORDER BY cost_name
    `;
    
    try {
      const result = await db.query(query, [companyId, category]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching variable costs by category: ${error.message}`);
    }
  }
}

module.exports = VariableCost;

