const db = require("../config/database");

/**
 * Pricing Rule Model
 * Handles database operations for pricing rules
 */
class PricingRule {
  /**
   * Create a new pricing rule
   * @param {Object} rule - Pricing rule data
   * @returns {Promise<Object>} Created pricing rule
   */
  static async create(rule) {
    const query = `
      INSERT INTO pricing_rules (
        company_id, rule_name, product_category, product_id, 
        customer_category, markup_percentage, discount_percentage, 
        min_profit_margin, priority, is_active, start_date, end_date, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
      RETURNING *
    `;
    
    const values = [
      rule.company_id,
      rule.rule_name,
      rule.product_category,
      rule.product_id,
      rule.customer_category,
      rule.markup_percentage,
      rule.discount_percentage || 0,
      rule.min_profit_margin,
      rule.priority || 0,
      rule.is_active !== undefined ? rule.is_active : true,
      rule.start_date,
      rule.end_date,
      rule.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating pricing rule: ${error.message}`);
    }
  }
  
  /**
   * Get all pricing rules for a company
   * @param {number} companyId - Company ID
   * @param {boolean} activeOnly - Get only active pricing rules
   * @returns {Promise<Array>} List of pricing rules
   */
  static async getAllByCompany(companyId, activeOnly = true) {
    let query = `
      SELECT pr.*, p.product_name 
      FROM pricing_rules pr
      LEFT JOIN products p ON pr.product_id = p.id
      WHERE pr.company_id = $1
    `;
    
    const values = [companyId];
    
    if (activeOnly) {
      query += ` AND pr.is_active = true`;
      query += ` AND (pr.end_date IS NULL OR pr.end_date >= CURRENT_DATE)`;
    }
    
    query += ` ORDER BY pr.priority DESC, pr.rule_name`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching pricing rules: ${error.message}`);
    }
  }
  
  /**
   * Get a pricing rule by ID
   * @param {number} id - Pricing rule ID
   * @returns {Promise<Object>} Pricing rule
   */
  static async getById(id) {
    const query = `
      SELECT pr.*, p.product_name 
      FROM pricing_rules pr
      LEFT JOIN products p ON pr.product_id = p.id
      WHERE pr.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching pricing rule: ${error.message}`);
    }
  }
  
  /**
   * Update a pricing rule
   * @param {number} id - Pricing rule ID
   * @param {Object} rule - Updated pricing rule data
   * @returns {Promise<Object>} Updated pricing rule
   */
  static async update(id, rule) {
    const query = `
      UPDATE pricing_rules 
      SET 
        rule_name = $1,
        product_category = $2,
        product_id = $3,
        customer_category = $4,
        markup_percentage = $5,
        discount_percentage = $6,
        min_profit_margin = $7,
        priority = $8,
        is_active = $9,
        start_date = $10,
        end_date = $11,
        notes = $12,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $13
      RETURNING *
    `;
    
    const values = [
      rule.rule_name,
      rule.product_category,
      rule.product_id,
      rule.customer_category,
      rule.markup_percentage,
      rule.discount_percentage,
      rule.min_profit_margin,
      rule.priority,
      rule.is_active,
      rule.start_date,
      rule.end_date,
      rule.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating pricing rule: ${error.message}`);
    }
  }
  
  /**
   * Delete a pricing rule
   * @param {number} id - Pricing rule ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    const query = `
      DELETE FROM pricing_rules 
      WHERE id = $1
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows.length > 0;
    } catch (error) {
      throw new Error(`Error deleting pricing rule: ${error.message}`);
    }
  }
  
  /**
   * Find applicable pricing rules for a product and customer
   * @param {number} companyId - Company ID
   * @param {number} productId - Product ID
   * @param {string} [customerCategory] - Customer category
   * @returns {Promise<Array>} List of applicable pricing rules
   */
  static async findApplicableRules(companyId, productId, customerCategory = null) {
    // Get product details
    const productQuery = `SELECT * FROM products WHERE id = $1`;
    const productResult = await db.query(productQuery, [productId]);
    const product = productResult.rows[0];
    
    if (!product) {
      throw new Error(`Product not found`);
    }
    
    let query = `
      SELECT * FROM pricing_rules 
      WHERE company_id = $1 
        AND is_active = true
        AND (end_date IS NULL OR end_date >= CURRENT_DATE)
        AND (
          (product_id = $2) OR
          (product_id IS NULL AND product_category = $3) OR
          (product_id IS NULL AND product_category IS NULL)
        )
    `;
    
    const values = [companyId, productId, product.product_category];
    
    if (customerCategory) {
      query += ` AND (customer_category = $${values.length + 1} OR customer_category IS NULL)`;
      values.push(customerCategory);
    } else {
      query += ` AND customer_category IS NULL`;
    }
    
    query += ` ORDER BY priority DESC, 
      CASE 
        WHEN product_id IS NOT NULL THEN 3
        WHEN product_category IS NOT NULL THEN 2
        ELSE 1
      END DESC,
      CASE 
        WHEN customer_category IS NOT NULL THEN 2
        ELSE 1
      END DESC
    `;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error finding applicable pricing rules: ${error.message}`);
    }
  }
  
  /**
   * Calculate price for a product
   * @param {number} companyId - Company ID
   * @param {number} productId - Product ID
   * @param {string} [customerCategory] - Customer category
   * @returns {Promise<Object>} Calculated price details
   */
  static async calculatePrice(companyId, productId, customerCategory = null) {
    try {
      // Get product cost
      const productCostQuery = `
        SELECT * FROM product_costs 
        WHERE company_id = $1 AND product_id = $2 AND is_active = true
        ORDER BY last_calculated_at DESC
        LIMIT 1
      `;
      const productCostResult = await db.query(productCostQuery, [companyId, productId]);
      const productCost = productCostResult.rows[0];
      
      if (!productCost) {
        throw new Error(`Product cost not found. Please calculate cost first.`);
      }
      
      // Find applicable pricing rules
      const rules = await this.findApplicableRules(companyId, productId, customerCategory);
      
      if (rules.length === 0) {
        throw new Error(`No applicable pricing rules found`);
      }
      
      // Use the highest priority rule
      const rule = rules[0];
      
      const cost = parseFloat(productCost.total_cost || 0);
      const markup = parseFloat(rule.markup_percentage || 0);
      const discount = parseFloat(rule.discount_percentage || 0);
      const minProfitMargin = parseFloat(rule.min_profit_margin || 0);
      
      // Calculate price: Cost * (1 + Markup%) * (1 - Discount%)
      const basePrice = cost * (1 + markup / 100);
      const discountedPrice = basePrice * (1 - discount / 100);
      
      // Ensure minimum profit margin
      const profit = discountedPrice - cost;
      const profitMargin = cost > 0 ? (profit / discountedPrice * 100) : 0;
      
      let finalPrice = discountedPrice;
      if (profitMargin < minProfitMargin) {
        // Adjust price to meet minimum profit margin
        finalPrice = cost / (1 - minProfitMargin / 100);
      }
      
      return {
        product_id: productId,
        cost: cost,
        base_price: basePrice,
        discounted_price: discountedPrice,
        final_price: finalPrice,
        profit: finalPrice - cost,
        profit_margin: cost > 0 ? ((finalPrice - cost) / finalPrice * 100) : 0,
        applied_rule: rule,
        calculation_date: new Date()
      };
    } catch (error) {
      throw new Error(`Error calculating price: ${error.message}`);
    }
  }
}

module.exports = PricingRule;
