const db = require("../config/database");

/**
 * Product Cost Model
 * Handles database operations for product costs
 */
class ProductCost {
  /**
   * Create a new product cost entry
   * @param {Object} productCost - Product cost data
   * @returns {Promise<Object>} Created product cost entry
   */
  static async create(productCost) {
    const query = `
      INSERT INTO product_costs (
        company_id, product_id, template_id, material_cost, labor_cost, 
        operational_cost, fixed_cost_allocation, variable_cost, total_cost, 
        last_calculated_at, is_active, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `;
    
    const values = [
      productCost.company_id,
      productCost.product_id,
      productCost.template_id,
      productCost.material_cost || 0,
      productCost.labor_cost || 0,
      productCost.operational_cost || 0,
      productCost.fixed_cost_allocation || 0,
      productCost.variable_cost || 0,
      productCost.total_cost || 0,
      productCost.last_calculated_at || new Date(),
      productCost.is_active !== undefined ? productCost.is_active : true,
      productCost.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating product cost: ${error.message}`);
    }
  }
  
  /**
   * Get all product costs for a company
   * @param {number} companyId - Company ID
   * @param {boolean} activeOnly - Get only active product costs
   * @returns {Promise<Array>} List of product costs with product details
   */
  static async getAllByCompany(companyId, activeOnly = true) {
    let query = `
      SELECT pc.*, p.product_name, p.product_code, ct.template_name 
      FROM product_costs pc
      JOIN products p ON pc.product_id = p.id
      LEFT JOIN cost_templates ct ON pc.template_id = ct.id
      WHERE pc.company_id = $1
    `;
    
    const values = [companyId];
    
    if (activeOnly) {
      query += ` AND pc.is_active = true`;
    }
    
    query += ` ORDER BY p.product_name`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching product costs: ${error.message}`);
    }
  }
  
  /**
   * Get a product cost by ID
   * @param {number} id - Product cost ID
   * @returns {Promise<Object>} Product cost with product details
   */
  static async getById(id) {
    const query = `
      SELECT pc.*, p.product_name, p.product_code, ct.template_name 
      FROM product_costs pc
      JOIN products p ON pc.product_id = p.id
      LEFT JOIN cost_templates ct ON pc.template_id = ct.id
      WHERE pc.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching product cost: ${error.message}`);
    }
  }
  
  /**
   * Get a product cost by product ID
   * @param {number} companyId - Company ID
   * @param {number} productId - Product ID
   * @param {boolean} activeOnly - Get only active product costs
   * @returns {Promise<Object>} Product cost with product details
   */
  static async getByProductId(companyId, productId, activeOnly = true) {
    let query = `
      SELECT pc.*, p.product_name, p.product_code, ct.template_name 
      FROM product_costs pc
      JOIN products p ON pc.product_id = p.id
      LEFT JOIN cost_templates ct ON pc.template_id = ct.id
      WHERE pc.company_id = $1 AND pc.product_id = $2
    `;
    
    const values = [companyId, productId];
    
    if (activeOnly) {
      query += ` AND pc.is_active = true`;
    }
    
    query += ` ORDER BY pc.last_calculated_at DESC LIMIT 1`;
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching product cost by product ID: ${error.message}`);
    }
  }
  
  /**
   * Update a product cost
   * @param {number} id - Product cost ID
   * @param {Object} productCost - Updated product cost data
   * @returns {Promise<Object>} Updated product cost
   */
  static async update(id, productCost) {
    const query = `
      UPDATE product_costs 
      SET 
        template_id = $1,
        material_cost = $2,
        labor_cost = $3,
        operational_cost = $4,
        fixed_cost_allocation = $5,
        variable_cost = $6,
        total_cost = $7,
        last_calculated_at = $8,
        is_active = $9,
        notes = $10,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $11
      RETURNING *
    `;
    
    const values = [
      productCost.template_id,
      productCost.material_cost,
      productCost.labor_cost,
      productCost.operational_cost,
      productCost.fixed_cost_allocation,
      productCost.variable_cost,
      productCost.total_cost,
      productCost.last_calculated_at || new Date(),
      productCost.is_active,
      productCost.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating product cost: ${error.message}`);
    }
  }
  
  /**
   * Delete a product cost
   * @param {number} id - Product cost ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    const client = await db.getClient();
    try {
      await client.query("BEGIN");
      
      // Delete associated cost components
      const deleteComponentsQuery = `
        DELETE FROM product_cost_components 
        WHERE product_cost_id = $1
      `;
      await client.query(deleteComponentsQuery, [id]);
      
      // Delete the product cost
      const deleteQuery = `
        DELETE FROM product_costs 
        WHERE id = $1
        RETURNING id
      `;
      const result = await client.query(deleteQuery, [id]);
      
      await client.query("COMMIT");
      return result.rows.length > 0;
    } catch (error) {
      await client.query("ROLLBACK");
      throw new Error(`Error deleting product cost: ${error.message}`);
    } finally {
      client.release();
    }
  }
  
  /**
   * Calculate cost for a product
   * @param {number} companyId - Company ID
   * @param {number} productId - Product ID
   * @param {number} [templateId] - Template ID (optional)
   * @returns {Promise<Object>} Calculated product cost
   */
  static async calculateForProduct(companyId, productId, templateId = null) {
    const client = await db.getClient();
    try {
      await client.query("BEGIN");
      
      // Get product details
      const productQuery = `SELECT * FROM products WHERE id = $1 AND company_id = $2`;
      const productResult = await client.query(productQuery, [productId, companyId]);
      const product = productResult.rows[0];
      
      if (!product) {
        throw new Error(`Product not found`);
      }
      
      // Get cost template
      let template;
      if (templateId) {
        const templateQuery = `SELECT * FROM cost_templates WHERE id = $1 AND company_id = $2`;
        const templateResult = await client.query(templateQuery, [templateId, companyId]);
        template = templateResult.rows[0];
      } else {
        // Try to find a template for the product category
        const categoryTemplateQuery = `
          SELECT * FROM cost_templates 
          WHERE company_id = $1 
            AND product_category = $2 
            AND is_active = true
          LIMIT 1
        `;
        const categoryTemplateResult = await client.query(categoryTemplateQuery, [companyId, product.product_category]);
        
        if (categoryTemplateResult.rows.length > 0) {
          template = categoryTemplateResult.rows[0];
        } else {
          // Use default template
          const defaultTemplateQuery = `
            SELECT * FROM cost_templates 
            WHERE company_id = $1 
              AND is_default = true 
              AND is_active = true
            LIMIT 1
          `;
          const defaultTemplateResult = await client.query(defaultTemplateQuery, [companyId]);
          template = defaultTemplateResult.rows[0];
        }
      }
      
      if (!template) {
        throw new Error(`No suitable cost template found`);
      }
      
      // Create or update product cost
      let productCost = await this.getByProductId(companyId, productId, false);
      
      const newProductCost = {
        company_id: companyId,
        product_id: productId,
        template_id: template.id,
        material_cost: 0,
        labor_cost: 0,
        operational_cost: 0,
        fixed_cost_allocation: 0,
        variable_cost: 0,
        total_cost: 0,
        last_calculated_at: new Date(),
        is_active: true,
        notes: `Calculated using template: ${template.template_name}`
      };
      
      if (productCost) {
        // Update existing
        productCost = await this.update(productCost.id, {
          ...productCost,
          ...newProductCost
        });
        
        // Delete existing components
        const deleteComponentsQuery = `
          DELETE FROM product_cost_components 
          WHERE product_cost_id = $1
        `;
        await client.query(deleteComponentsQuery, [productCost.id]);
      } else {
        // Create new
        productCost = await this.create(newProductCost);
      }
      
      // Get template items
      const templateItemsQuery = `
        SELECT cti.*, 
          CASE 
            WHEN cti.cost_type = 'fixed' THEN fc.cost_name
            WHEN cti.cost_type = 'variable' THEN vc.cost_name
            WHEN cti.cost_type = 'material' THEN (
              SELECT ii.item_name FROM material_costs mc
              JOIN inventory_items ii ON mc.material_id = ii.id
              WHERE mc.id = cti.cost_id
            )
            WHEN cti.cost_type = 'labor' THEN lc.labor_category
            WHEN cti.cost_type = 'operational' THEN oc.cost_name
            ELSE NULL
          END as cost_name
        FROM cost_template_items cti
        LEFT JOIN fixed_costs fc ON cti.cost_type = 'fixed' AND cti.cost_id = fc.id
        LEFT JOIN variable_costs vc ON cti.cost_type = 'variable' AND cti.cost_id = vc.id
        LEFT JOIN labor_costs lc ON cti.cost_type = 'labor' AND cti.cost_id = lc.id
        LEFT JOIN operational_costs oc ON cti.cost_type = 'operational' AND cti.cost_id = oc.id
        WHERE cti.template_id = $1
      `;
      const templateItemsResult = await client.query(templateItemsQuery, [template.id]);
      const templateItems = templateItemsResult.rows;
      
      // Calculate costs for each component type
      let materialCost = 0;
      let laborCost = 0;
      let operationalCost = 0;
      let fixedCostAllocation = 0;
      let variableCost = 0;
      
      for (const item of templateItems) {
        let componentCost = 0;
        let unitCost = 0;
        let quantity = 1;
        
        switch (item.cost_type) {
          case 'material':
            const materialQuery = `
              SELECT mc.*, ii.item_name, ii.unit_of_measure 
              FROM material_costs mc
              JOIN inventory_items ii ON mc.material_id = ii.id
              WHERE mc.id = $1
            `;
            const materialResult = await client.query(materialQuery, [item.cost_id]);
            const material = materialResult.rows[0];
            
            if (material) {
              unitCost = parseFloat(material.cost_per_unit || 0);
              const wastage = parseFloat(material.wastage_percentage || 0);
              const effectiveCost = unitCost * (1 + wastage / 100);
              componentCost = effectiveCost * quantity;
              materialCost += componentCost;
            }
            break;
            
          case 'labor':
            const laborQuery = `SELECT * FROM labor_costs WHERE id = $1`;
            const laborResult = await client.query(laborQuery, [item.cost_id]);
            const labor = laborResult.rows[0];
            
            if (labor) {
              unitCost = parseFloat(labor.cost_per_hour || 0);
              const overhead = parseFloat(labor.overhead_percentage || 0);
              const effectiveCost = unitCost * (1 + overhead / 100);
              componentCost = effectiveCost * quantity;
              laborCost += componentCost;
            }
            break;
            
          case 'operational':
            const operationalQuery = `SELECT * FROM operational_costs WHERE id = $1`;
            const operationalResult = await client.query(operationalQuery, [item.cost_id]);
            const operational = operationalResult.rows[0];
            
            if (operational) {
              componentCost = parseFloat(operational.amount || 0) * (parseFloat(item.allocation_percentage || 100) / 100);
              operationalCost += componentCost;
            }
            break;
            
          case 'fixed':
            const fixedQuery = `SELECT * FROM fixed_costs WHERE id = $1`;
            const fixedResult = await client.query(fixedQuery, [item.cost_id]);
            const fixed = fixedResult.rows[0];
            
            if (fixed) {
              componentCost = parseFloat(fixed.amount || 0) * (parseFloat(item.allocation_percentage || 100) / 100);
              fixedCostAllocation += componentCost;
            }
            break;
            
          case 'variable':
            const variableQuery = `SELECT * FROM variable_costs WHERE id = $1`;
            const variableResult = await client.query(variableQuery, [item.cost_id]);
            const variable = variableResult.rows[0];
            
            if (variable) {
              unitCost = parseFloat(variable.cost_per_unit || 0);
              componentCost = unitCost * quantity;
              variableCost += componentCost;
            }
            break;
        }
        
        // Add component to product cost
        if (componentCost > 0) {
          const addComponentQuery = `
            INSERT INTO product_cost_components (
              product_cost_id, component_type, component_id, 
              quantity, unit_cost, total_cost, notes
            ) VALUES ($1, $2, $3, $4, $5, $6, $7)
          `;
          
          const componentValues = [
            productCost.id,
            item.cost_type,
            item.cost_id,
            quantity,
            unitCost,
            componentCost,
            `From template item: ${item.id}`
          ];
          
          await client.query(addComponentQuery, componentValues);
        }
      }
      
      // Update product cost with calculated values
      const totalCost = materialCost + laborCost + operationalCost + fixedCostAllocation + variableCost;
      
      const updateQuery = `
        UPDATE product_costs 
        SET 
          material_cost = $1,
          labor_cost = $2,
          operational_cost = $3,
          fixed_cost_allocation = $4,
          variable_cost = $5,
          total_cost = $6,
          last_calculated_at = $7,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $8
        RETURNING *
      `;
      
      const updateValues = [
        materialCost,
        laborCost,
        operationalCost,
        fixedCostAllocation,
        variableCost,
        totalCost,
        new Date(),
        productCost.id
      ];
      
      const updateResult = await client.query(updateQuery, updateValues);
      const updatedProductCost = updateResult.rows[0];
      
      // Record calculation history
      const historyQuery = `
        INSERT INTO cost_calculation_history (
          company_id, calculation_type, reference_id, 
          previous_total_cost, new_total_cost, 
          change_percentage, calculation_date, notes
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      `;
      
      const previousCost = parseFloat(productCost.total_cost || 0);
      const newCost = parseFloat(updatedProductCost.total_cost || 0);
      const changePercentage = previousCost > 0 ? ((newCost - previousCost) / previousCost * 100) : 0;
      
      const historyValues = [
        companyId,
        'product',
        productId,
        previousCost,
        newCost,
        changePercentage,
        new Date(),
        `Calculated using template: ${template.template_name}`
      ];
      
      await client.query(historyQuery, historyValues);
      
      await client.query("COMMIT");
      
      // Get the updated product cost with components
      const result = await this.getById(updatedProductCost.id);
      
      // Get components
      const componentsQuery = `
        SELECT pcc.*,
          CASE 
            WHEN pcc.component_type = 'material' THEN (
              SELECT ii.item_name FROM material_costs mc
              JOIN inventory_items ii ON mc.material_id = ii.id
              WHERE mc.id = pcc.component_id
            )
            WHEN pcc.component_type = 'labor' THEN (
              SELECT lc.labor_category FROM labor_costs lc
              WHERE lc.id = pcc.component_id
            )
            WHEN pcc.component_type = 'operational' THEN (
              SELECT oc.cost_name FROM operational_costs oc
              WHERE oc.id = pcc.component_id
            )
            WHEN pcc.component_type = 'fixed' THEN (
              SELECT fc.cost_name FROM fixed_costs fc
              WHERE fc.id = pcc.component_id
            )
            WHEN pcc.component_type = 'variable' THEN (
              SELECT vc.cost_name FROM variable_costs vc
              WHERE vc.id = pcc.component_id
            )
            ELSE NULL
          END as component_name
        FROM product_cost_components pcc
        WHERE pcc.product_cost_id = $1
        ORDER BY pcc.component_type, pcc.id
      `;
      
      const componentsResult = await db.query(componentsQuery, [result.id]);
      
      return {
        ...result,
        components: componentsResult.rows
      };
    } catch (error) {
      await client.query("ROLLBACK");
      throw new Error(`Error calculating product cost: ${error.message}`);
    } finally {
      client.release();
    }
  }
  
  /**
   * Get product costs by category
   * @param {number} companyId - Company ID
   * @param {string} category - Product category
   * @returns {Promise<Array>} List of product costs
   */
  static async getByCategory(companyId, category) {
    const query = `
      SELECT pc.*, p.product_name, p.product_code, ct.template_name 
      FROM product_costs pc
      JOIN products p ON pc.product_id = p.id
      LEFT JOIN cost_templates ct ON pc.template_id = ct.id
      WHERE pc.company_id = $1 
        AND p.product_category = $2
        AND pc.is_active = true
      ORDER BY p.product_name
    `;
    
    try {
      const result = await db.query(query, [companyId, category]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching product costs by category: ${error.message}`);
    }
  }
}

module.exports = ProductCost;
