const db = require("../config/database");

/**
 * Product Cost Component Model
 * Handles database operations for product cost components
 */
class ProductCostComponent {
  /**
   * Create a new product cost component
   * @param {Object} component - Product cost component data
   * @returns {Promise<Object>} Created product cost component
   */
  static async create(component) {
    const query = `
      INSERT INTO product_cost_components (
        product_cost_id, component_type, component_id, 
        quantity, unit_cost, total_cost, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `;
    
    const values = [
      component.product_cost_id,
      component.component_type, // 'material', 'labor', 'overhead'
      component.component_id,
      component.quantity || 1,
      component.unit_cost || 0,
      component.total_cost || (component.unit_cost * component.quantity) || 0,
      component.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating product cost component: ${error.message}`);
    }
  }
  
  /**
   * Get all components for a product cost
   * @param {number} productCostId - Product cost ID
   * @returns {Promise<Array>} List of product cost components
   */
  static async getAllByProductCost(productCostId) {
    const query = `
      SELECT pcc.*,
        CASE 
          WHEN pcc.component_type = 'material' THEN (
            SELECT ii.item_name FROM material_costs mc
            JOIN inventory_items ii ON mc.material_id = ii.id
            WHERE mc.id = pcc.component_id
          )
          WHEN pcc.component_type = 'labor' THEN (
            SELECT lc.labor_category FROM labor_costs lc
            WHERE lc.id = pcc.component_id
          )
          WHEN pcc.component_type = 'overhead' THEN (
            SELECT oc.cost_name FROM operational_costs oc
            WHERE oc.id = pcc.component_id
          )
          ELSE NULL
        END as component_name
      FROM product_cost_components pcc
      WHERE pcc.product_cost_id = $1
      ORDER BY pcc.component_type, pcc.id
    `;
    
    try {
      const result = await db.query(query, [productCostId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching product cost components: ${error.message}`);
    }
  }
  
  /**
   * Get a product cost component by ID
   * @param {number} id - Product cost component ID
   * @returns {Promise<Object>} Product cost component
   */
  static async getById(id) {
    const query = `
      SELECT pcc.*,
        CASE 
          WHEN pcc.component_type = 'material' THEN (
            SELECT ii.item_name FROM material_costs mc
            JOIN inventory_items ii ON mc.material_id = ii.id
            WHERE mc.id = pcc.component_id
          )
          WHEN pcc.component_type = 'labor' THEN (
            SELECT lc.labor_category FROM labor_costs lc
            WHERE lc.id = pcc.component_id
          )
          WHEN pcc.component_type = 'overhead' THEN (
            SELECT oc.cost_name FROM operational_costs oc
            WHERE oc.id = pcc.component_id
          )
          ELSE NULL
        END as component_name
      FROM product_cost_components pcc
      WHERE pcc.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching product cost component: ${error.message}`);
    }
  }
  
  /**
   * Update a product cost component
   * @param {number} id - Product cost component ID
   * @param {Object} component - Updated product cost component data
   * @returns {Promise<Object>} Updated product cost component
   */
  static async update(id, component) {
    const query = `
      UPDATE product_cost_components 
      SET 
        component_type = $1,
        component_id = $2,
        quantity = $3,
        unit_cost = $4,
        total_cost = $5,
        notes = $6,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $7
      RETURNING *
    `;
    
    const values = [
      component.component_type,
      component.component_id,
      component.quantity,
      component.unit_cost,
      component.total_cost || (component.unit_cost * component.quantity) || 0,
      component.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating product cost component: ${error.message}`);
    }
  }
  
  /**
   * Delete a product cost component
   * @param {number} id - Product cost component ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    const query = `
      DELETE FROM product_cost_components 
      WHERE id = $1
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows.length > 0;
    } catch (error) {
      throw new Error(`Error deleting product cost component: ${error.message}`);
    }
  }
  
  /**
   * Delete all components for a product cost
   * @param {number} productCostId - Product cost ID
   * @returns {Promise<number>} Number of components deleted
   */
  static async deleteAllByProductCost(productCostId) {
    const query = `
      DELETE FROM product_cost_components 
      WHERE product_cost_id = $1
    `;
    
    try {
      const result = await db.query(query, [productCostId]);
      return result.rowCount;
    } catch (error) {
      throw new Error(`Error deleting product cost components: ${error.message}`);
    }
  }
  
  /**
   * Calculate total cost for all components of a product cost
   * @param {number} productCostId - Product cost ID
   * @returns {Promise<Object>} Total costs by component type
   */
  static async calculateTotalCosts(productCostId) {
    const query = `
      SELECT 
        SUM(CASE WHEN component_type = 'material' THEN total_cost ELSE 0 END) as material_cost,
        SUM(CASE WHEN component_type = 'labor' THEN total_cost ELSE 0 END) as labor_cost,
        SUM(CASE WHEN component_type = 'overhead' THEN total_cost ELSE 0 END) as overhead_cost,
        SUM(total_cost) as total_cost
      FROM product_cost_components
      WHERE product_cost_id = $1
    `;
    
    try {
      const result = await db.query(query, [productCostId]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error calculating total component costs: ${error.message}`);
    }
  }
}

module.exports = ProductCostComponent;
