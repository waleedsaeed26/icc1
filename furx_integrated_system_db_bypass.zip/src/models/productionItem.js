const db = require('../config/database');

/**
 * ProductionItem Model
 * Handles database operations for the production_items table
 * Includes company_id to support multi-company structure
 */
class ProductionItem {
  /**
   * Get all production items for a specific company
   * @param {number} companyId - Company ID
   * @returns {Promise<Array>} Array of production item objects
   */
  static async getAllByCompany(companyId) {
    try {
      const result = await db.query(
        'SELECT * FROM production_items WHERE company_id = $1 ORDER BY item_id',
        [companyId]
      );
      return result.rows;
    } catch (error) {
      console.error(`Error in getAllByCompany production items for company ${companyId}:`, error);
      throw error;
    }
  }

  /**
   * Get a production item by ID
   * @param {number} id - Production Item ID
   * @returns {Promise<Object>} Production Item object
   */
  static async getById(id) {
    try {
      const result = await db.query(
        'SELECT * FROM production_items WHERE item_id = $1',
        [id]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in getById production item ${id}:`, error);
      throw error;
    }
  }

  /**
   * Get a production item by QR code
   * @param {string} qrCode - QR code
   * @returns {Promise<Object>} Production Item object
   */
  static async getByQrCode(qrCode) {
    try {
      const result = await db.query(
        'SELECT * FROM production_items WHERE item_qr_code = $1',
        [qrCode]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in getByQrCode production item ${qrCode}:`, error);
      throw error;
    }
  }

  /**
   * Create a new production item
   * @param {Object} item - Production Item data
   * @returns {Promise<Object>} Created production item object
   */
  static async create(item) {
    try {
      const { 
        company_id,
        production_order_id, 
        item_qr_code, 
        current_stage_id, 
        current_location_id,
        status,
        completion_percentage,
        notes
      } = item;
      
      const result = await db.query(
        `INSERT INTO production_items 
        (company_id, production_order_id, item_qr_code, current_stage_id, 
         current_location_id, status, completion_percentage, notes, created_at) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW()) 
        RETURNING *`,
        [
          company_id,
          production_order_id, 
          item_qr_code, 
          current_stage_id, 
          current_location_id,
          status,
          completion_percentage || 0,
          notes
        ]
      );
      return result.rows[0];
    } catch (error) {
      console.error('Error in create production item:', error);
      throw error;
    }
  }

  /**
   * Update a production item
   * @param {number} id - Production Item ID
   * @param {Object} item - Updated production item data
   * @returns {Promise<Object>} Updated production item object
   */
  static async update(id, item) {
    try {
      const { 
        current_stage_id, 
        current_location_id,
        status,
        completion_percentage,
        notes
      } = item;
      
      const result = await db.query(
        `UPDATE production_items 
        SET current_stage_id = $1, 
            current_location_id = $2, 
            status = $3, 
            completion_percentage = $4, 
            notes = $5, 
            updated_at = NOW() 
        WHERE item_id = $6 
        RETURNING *`,
        [
          current_stage_id, 
          current_location_id,
          status,
          completion_percentage,
          notes,
          id
        ]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in update production item ${id}:`, error);
      throw error;
    }
  }

  /**
   * Get production items by production order ID
   * @param {number} orderId - Production Order ID
   * @returns {Promise<Array>} Array of production item objects
   */
  static async getByProductionOrderId(orderId) {
    try {
      const result = await db.query(
        'SELECT * FROM production_items WHERE production_order_id = $1',
        [orderId]
      );
      return result.rows;
    } catch (error) {
      console.error(`Error in getByProductionOrderId ${orderId}:`, error);
      throw error;
    }
  }

  /**
   * Get production items by current stage
   * @param {number} stageId - Production Stage ID
   * @param {number} companyId - Company ID
   * @returns {Promise<Array>} Array of production item objects
   */
  static async getByCurrentStage(stageId, companyId) {
    try {
      const result = await db.query(
        'SELECT * FROM production_items WHERE current_stage_id = $1 AND company_id = $2',
        [stageId, companyId]
      );
      return result.rows;
    } catch (error) {
      console.error(`Error in getByCurrentStage ${stageId} for company ${companyId}:`, error);
      throw error;
    }
  }

  /**
   * Log movement of a production item
   * @param {number} itemId - Production Item ID
   * @param {number} fromStageId - From Stage ID
   * @param {number} toStageId - To Stage ID
   * @param {number} fromLocationId - From Location ID
   * @param {number} toLocationId - To Location ID
   * @param {number} movedByEmployeeId - Employee ID who moved the item
   * @param {string} notes - Notes about the movement
   * @returns {Promise<Object>} Movement log entry
   */
  static async logMovement(itemId, fromStageId, toStageId, fromLocationId, toLocationId, movedByEmployeeId, notes) {
    try {
      // First update the production item
      await db.query(
        `UPDATE production_items 
         SET current_stage_id = $1, 
             current_location_id = $2,
             updated_at = NOW() 
         WHERE item_id = $3`,
        [toStageId, toLocationId, itemId]
      );
      
      // Then log the movement
      const result = await db.query(
        `INSERT INTO item_movement_log 
        (production_item_id, from_stage_id, to_stage_id, from_location_id, to_location_id, moved_by, moved_at, notes) 
        VALUES ($1, $2, $3, $4, $5, $6, NOW(), $7) 
        RETURNING *`,
        [itemId, fromStageId, toStageId, fromLocationId, toLocationId, movedByEmployeeId, notes]
      );
      
      return result.rows[0];
    } catch (error) {
      console.error(`Error in logMovement for item ${itemId}:`, error);
      throw error;
    }
  }
}

module.exports = ProductionItem;
