const db = require("../config/database");

/**
 * Fixed Costs Model
 * Handles database operations for fixed costs
 */
class FixedCost {
  /**
   * Create a new fixed cost
   * @param {Object} fixedCost - Fixed cost data
   * @returns {Promise<Object>} Created fixed cost
   */
  static async create(fixedCost) {
    const query = `
      INSERT INTO fixed_costs (
        company_id, cost_name, cost_category, amount, frequency, 
        allocation_method, allocation_basis, start_date, end_date, 
        is_active, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *
    `;
    
    const values = [
      fixedCost.company_id,
      fixedCost.cost_name,
      fixedCost.cost_category,
      fixedCost.amount,
      fixedCost.frequency,
      fixedCost.allocation_method,
      fixedCost.allocation_basis,
      fixedCost.start_date,
      fixedCost.end_date,
      fixedCost.is_active !== undefined ? fixedCost.is_active : true,
      fixedCost.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating fixed cost: ${error.message}`);
    }
  }
  
  /**
   * Get all fixed costs for a company
   * @param {number} companyId - Company ID
   * @param {boolean} activeOnly - Get only active fixed costs
   * @returns {Promise<Array>} List of fixed costs
   */
  static async getAllByCompany(companyId, activeOnly = true) {
    let query = `
      SELECT * FROM fixed_costs 
      WHERE company_id = $1
    `;
    
    const values = [companyId];
    
    if (activeOnly) {
      query += ` AND is_active = true`;
      query += ` AND (end_date IS NULL OR end_date >= CURRENT_DATE)`;
    }
    
    query += ` ORDER BY cost_category, cost_name`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching fixed costs: ${error.message}`);
    }
  }
  
  /**
   * Get a fixed cost by ID
   * @param {number} id - Fixed cost ID
   * @returns {Promise<Object>} Fixed cost
   */
  static async getById(id) {
    const query = `
      SELECT * FROM fixed_costs 
      WHERE id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching fixed cost: ${error.message}`);
    }
  }
  
  /**
   * Update a fixed cost
   * @param {number} id - Fixed cost ID
   * @param {Object} fixedCost - Updated fixed cost data
   * @returns {Promise<Object>} Updated fixed cost
   */
  static async update(id, fixedCost) {
    const query = `
      UPDATE fixed_costs 
      SET 
        cost_name = $1,
        cost_category = $2,
        amount = $3,
        frequency = $4,
        allocation_method = $5,
        allocation_basis = $6,
        start_date = $7,
        end_date = $8,
        is_active = $9,
        notes = $10,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $11
      RETURNING *
    `;
    
    const values = [
      fixedCost.cost_name,
      fixedCost.cost_category,
      fixedCost.amount,
      fixedCost.frequency,
      fixedCost.allocation_method,
      fixedCost.allocation_basis,
      fixedCost.start_date,
      fixedCost.end_date,
      fixedCost.is_active,
      fixedCost.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating fixed cost: ${error.message}`);
    }
  }
  
  /**
   * Delete a fixed cost
   * @param {number} id - Fixed cost ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    // Need to handle related cost allocations before deleting
    const checkAllocationsQuery = `SELECT COUNT(*) FROM cost_allocations WHERE cost_type = 'fixed' AND cost_id = $1`;
    const client = await db.getClient();
    try {
      await client.query("BEGIN");
      const allocationResult = await client.query(checkAllocationsQuery, [id]);
      if (parseInt(allocationResult.rows[0].count, 10) > 0) {
        throw new Error("Cannot delete fixed cost with active allocations. Please remove allocations first.");
      }
      
      const deleteQuery = `
        DELETE FROM fixed_costs 
        WHERE id = $1
        RETURNING id
      `;
      const result = await client.query(deleteQuery, [id]);
      await client.query("COMMIT");
      return result.rows.length > 0;
    } catch (error) {
      await client.query("ROLLBACK");
      throw new Error(`Error deleting fixed cost: ${error.message}`);
    } finally {
      client.release();
    }
  }
  
  /**
   * Get total fixed costs for a company by frequency
   * @param {number} companyId - Company ID
   * @param {string} frequency - Frequency (monthly, quarterly, yearly)
   * @returns {Promise<number>} Total fixed costs
   */
  static async getTotalByFrequency(companyId, frequency) {
    const query = `
      SELECT SUM(amount) as total 
      FROM fixed_costs 
      WHERE company_id = $1 
        AND frequency = $2 
        AND is_active = true
        AND (end_date IS NULL OR end_date >= CURRENT_DATE)
    `;
    
    try {
      const result = await db.query(query, [companyId, frequency]);
      return parseFloat(result.rows[0]?.total || 0);
    } catch (error) {
      throw new Error(`Error calculating total fixed costs: ${error.message}`);
    }
  }
}

module.exports = FixedCost;

