const db = require("../config/database");

/**
 * Cost Allocation Model
 * Handles database operations for allocating costs to cost centers
 */
class CostAllocation {
  /**
   * Create a new cost allocation
   * @param {Object} allocation - Allocation data
   * @returns {Promise<Object>} Created allocation
   */
  static async create(allocation) {
    const query = `
      INSERT INTO cost_allocations (
        company_id, cost_center_id, cost_type, cost_id, 
        allocation_percentage, start_date, end_date, is_active, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *
    `;
    
    const values = [
      allocation.company_id,
      allocation.cost_center_id,
      allocation.cost_type, // e.g., 'fixed', 'operational'
      allocation.cost_id, // ID from fixed_costs or operational_costs table
      allocation.allocation_percentage,
      allocation.start_date || new Date(),
      allocation.end_date,
      allocation.is_active !== undefined ? allocation.is_active : true,
      allocation.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating cost allocation: ${error.message}`);
    }
  }
  
  /**
   * Get all allocations for a company
   * @param {number} companyId - Company ID
   * @param {boolean} activeOnly - Get only active allocations
   * @returns {Promise<Array>} List of allocations
   */
  static async getAllByCompany(companyId, activeOnly = true) {
    let query = `
      SELECT ca.*, cc.center_name, 
        CASE 
          WHEN ca.cost_type = 'fixed' THEN fc.cost_name
          WHEN ca.cost_type = 'operational' THEN oc.cost_name
          ELSE 'N/A'
        END as cost_name
      FROM cost_allocations ca
      JOIN cost_centers cc ON ca.cost_center_id = cc.id
      LEFT JOIN fixed_costs fc ON ca.cost_type = 'fixed' AND ca.cost_id = fc.id
      LEFT JOIN operational_costs oc ON ca.cost_type = 'operational' AND ca.cost_id = oc.id
      WHERE ca.company_id = $1
    `;
    
    const values = [companyId];
    
    if (activeOnly) {
      query += ` AND ca.is_active = true`;
      query += ` AND (ca.end_date IS NULL OR ca.end_date >= CURRENT_DATE)`;
    }
    
    query += ` ORDER BY cc.center_name, ca.cost_type`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching cost allocations: ${error.message}`);
    }
  }
  
  /**
   * Get all allocations for a specific cost center
   * @param {number} costCenterId - Cost Center ID
   * @param {boolean} activeOnly - Get only active allocations
   * @returns {Promise<Array>} List of allocations
   */
  static async getByCostCenter(costCenterId, activeOnly = true) {
    let query = `
      SELECT ca.*, cc.center_name, 
        CASE 
          WHEN ca.cost_type = 'fixed' THEN fc.cost_name
          WHEN ca.cost_type = 'operational' THEN oc.cost_name
          ELSE 'N/A'
        END as cost_name
      FROM cost_allocations ca
      JOIN cost_centers cc ON ca.cost_center_id = cc.id
      LEFT JOIN fixed_costs fc ON ca.cost_type = 'fixed' AND ca.cost_id = fc.id
      LEFT JOIN operational_costs oc ON ca.cost_type = 'operational' AND ca.cost_id = oc.id
      WHERE ca.cost_center_id = $1
    `;
    
    const values = [costCenterId];
    
    if (activeOnly) {
      query += ` AND ca.is_active = true`;
      query += ` AND (ca.end_date IS NULL OR ca.end_date >= CURRENT_DATE)`;
    }
    
    query += ` ORDER BY ca.cost_type`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching cost allocations for cost center: ${error.message}`);
    }
  }
  
  /**
   * Get a specific allocation by ID
   * @param {number} id - Allocation ID
   * @returns {Promise<Object>} Allocation
   */
  static async getById(id) {
    const query = `
      SELECT ca.*, cc.center_name, 
        CASE 
          WHEN ca.cost_type = 'fixed' THEN fc.cost_name
          WHEN ca.cost_type = 'operational' THEN oc.cost_name
          ELSE 'N/A'
        END as cost_name
      FROM cost_allocations ca
      JOIN cost_centers cc ON ca.cost_center_id = cc.id
      LEFT JOIN fixed_costs fc ON ca.cost_type = 'fixed' AND ca.cost_id = fc.id
      LEFT JOIN operational_costs oc ON ca.cost_type = 'operational' AND ca.cost_id = oc.id
      WHERE ca.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching cost allocation: ${error.message}`);
    }
  }
  
  /**
   * Update a cost allocation
   * @param {number} id - Allocation ID
   * @param {Object} allocation - Updated allocation data
   * @returns {Promise<Object>} Updated allocation
   */
  static async update(id, allocation) {
    const query = `
      UPDATE cost_allocations 
      SET 
        cost_center_id = $1,
        cost_type = $2,
        cost_id = $3,
        allocation_percentage = $4,
        start_date = $5,
        end_date = $6,
        is_active = $7,
        notes = $8,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $9
      RETURNING *
    `;
    
    const values = [
      allocation.cost_center_id,
      allocation.cost_type,
      allocation.cost_id,
      allocation.allocation_percentage,
      allocation.start_date,
      allocation.end_date,
      allocation.is_active,
      allocation.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating cost allocation: ${error.message}`);
    }
  }
  
  /**
   * Delete a cost allocation
   * @param {number} id - Allocation ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    const query = `
      DELETE FROM cost_allocations 
      WHERE id = $1
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows.length > 0;
    } catch (error) {
      throw new Error(`Error deleting cost allocation: ${error.message}`);
    }
  }
  
  /**
   * Get total allocated percentage for a specific cost
   * @param {number} companyId - Company ID
   * @param {string} costType - Type of cost ('fixed', 'operational')
   * @param {number} costId - ID of the cost
   * @returns {Promise<number>} Total allocated percentage
   */
  static async getTotalAllocationPercentage(companyId, costType, costId) {
    const query = `
      SELECT SUM(allocation_percentage) as total_percentage
      FROM cost_allocations
      WHERE company_id = $1
        AND cost_type = $2
        AND cost_id = $3
        AND is_active = true
        AND (end_date IS NULL OR end_date >= CURRENT_DATE)
    `;
    
    try {
      const result = await db.query(query, [companyId, costType, costId]);
      return parseFloat(result.rows[0]?.total_percentage || 0);
    } catch (error) {
      throw new Error(`Error getting total allocation percentage: ${error.message}`);
    }
  }
}

module.exports = CostAllocation;

