const db = require("../config/database");

/**
 * Cost Templates Model
 * Handles database operations for cost templates
 */
class CostTemplate {
  /**
   * Create a new cost template
   * @param {Object} template - Template data
   * @returns {Promise<Object>} Created template
   */
  static async create(template) {
    const query = `
      INSERT INTO cost_templates (
        company_id, template_name, product_category, is_default, 
        is_active, notes
      ) VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `;
    
    const values = [
      template.company_id,
      template.template_name,
      template.product_category,
      template.is_default || false,
      template.is_active !== undefined ? template.is_active : true,
      template.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating cost template: ${error.message}`);
    }
  }
  
  /**
   * Get all cost templates for a company
   * @param {number} companyId - Company ID
   * @param {boolean} activeOnly - Get only active templates
   * @returns {Promise<Array>} List of cost templates
   */
  static async getAllByCompany(companyId, activeOnly = true) {
    let query = `
      SELECT * FROM cost_templates 
      WHERE company_id = $1
    `;
    
    const values = [companyId];
    
    if (activeOnly) {
      query += ` AND is_active = true`;
    }
    
    query += ` ORDER BY template_name`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching cost templates: ${error.message}`);
    }
  }
  
  /**
   * Get a cost template by ID
   * @param {number} id - Template ID
   * @returns {Promise<Object>} Cost template
   */
  static async getById(id) {
    const query = `
      SELECT * FROM cost_templates 
      WHERE id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching cost template: ${error.message}`);
    }
  }
  
  /**
   * Update a cost template
   * @param {number} id - Template ID
   * @param {Object} template - Updated template data
   * @returns {Promise<Object>} Updated template
   */
  static async update(id, template) {
    const query = `
      UPDATE cost_templates 
      SET 
        template_name = $1,
        product_category = $2,
        is_default = $3,
        is_active = $4,
        notes = $5,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $6
      RETURNING *
    `;
    
    const values = [
      template.template_name,
      template.product_category,
      template.is_default,
      template.is_active,
      template.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating cost template: ${error.message}`);
    }
  }
  
  /**
   * Delete a cost template
   * @param {number} id - Template ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    const client = await db.getClient();
    try {
      await client.query("BEGIN");
      // Need to delete associated template items first
      await this.deleteAllItems(id, client);
      
      const query = `
        DELETE FROM cost_templates 
        WHERE id = $1
        RETURNING id
      `;
      const result = await client.query(query, [id]);
      await client.query("COMMIT");
      return result.rows.length > 0;
    } catch (error) {
      await client.query("ROLLBACK");
      throw new Error(`Error deleting cost template: ${error.message}`);
    } finally {
      client.release();
    }
  }
  
  /**
   * Add an item to a cost template
   * @param {Object} item - Template item data
   * @returns {Promise<Object>} Added template item
   */
  static async addItem(item) {
    const query = `
      INSERT INTO cost_template_items (
        template_id, cost_type, cost_id, allocation_percentage, notes
      ) VALUES ($1, $2, $3, $4, $5)
      RETURNING *
    `;
    
    const values = [
      item.template_id,
      item.cost_type,
      item.cost_id,
      item.allocation_percentage || 100,
      item.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error adding item to cost template: ${error.message}`);
    }
  }
  
  /**
   * Get all items for a cost template
   * @param {number} templateId - Template ID
   * @returns {Promise<Array>} List of template items
   */
  static async getAllItems(templateId) {
    const query = `
      SELECT cti.*,
        CASE 
          WHEN cti.cost_type = 'fixed' THEN fc.cost_name
          WHEN cti.cost_type = 'variable' THEN vc.cost_name
          WHEN cti.cost_type = 'material' THEN (
            SELECT ii.item_name FROM material_costs mc
            JOIN inventory_items ii ON mc.material_id = ii.id
            WHERE mc.id = cti.cost_id
          )
          WHEN cti.cost_type = 'labor' THEN lc.labor_category
          WHEN cti.cost_type = 'operational' THEN oc.cost_name
          ELSE NULL
        END as cost_name
      FROM cost_template_items cti
      LEFT JOIN fixed_costs fc ON cti.cost_type = 'fixed' AND cti.cost_id = fc.id
      LEFT JOIN variable_costs vc ON cti.cost_type = 'variable' AND cti.cost_id = vc.id
      LEFT JOIN labor_costs lc ON cti.cost_type = 'labor' AND cti.cost_id = lc.id
      LEFT JOIN operational_costs oc ON cti.cost_type = 'operational' AND cti.cost_id = oc.id
      WHERE cti.template_id = $1
      ORDER BY cti.cost_type
    `;
    
    try {
      const result = await db.query(query, [templateId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching cost template items: ${error.message}`);
    }
  }
  
  /**
   * Update a template item
   * @param {number} itemId - Template item ID
   * @param {Object} item - Updated item data
   * @returns {Promise<Object>} Updated template item
   */
  static async updateItem(itemId, item) {
    const query = `
      UPDATE cost_template_items 
      SET 
        cost_type = $1,
        cost_id = $2,
        allocation_percentage = $3,
        notes = $4,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $5
      RETURNING *
    `;
    
    const values = [
      item.cost_type,
      item.cost_id,
      item.allocation_percentage,
      item.notes,
      itemId
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating cost template item: ${error.message}`);
    }
  }
  
  /**
   * Delete a template item
   * @param {number} itemId - Template item ID
   * @returns {Promise<boolean>} Success status
   */
  static async deleteItem(itemId) {
    const query = `
      DELETE FROM cost_template_items 
      WHERE id = $1
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [itemId]);
      return result.rows.length > 0;
    } catch (error) {
      throw new Error(`Error deleting cost template item: ${error.message}`);
    }
  }
  
  /**
   * Delete all items for a template
   * @param {number} templateId - Template ID
   * @param {Object} [client] - Optional database client for transactions
   * @returns {Promise<number>} Number of items deleted
   */
  static async deleteAllItems(templateId, client = db) {
    const query = `
      DELETE FROM cost_template_items 
      WHERE template_id = $1
    `;
    
    try {
      const result = await client.query(query, [templateId]);
      return result.rowCount;
    } catch (error) {
      throw new Error(`Error deleting all items for cost template: ${error.message}`);
    }
  }
  
  /**
   * Get the default cost template for a company
   * @param {number} companyId - Company ID
   * @returns {Promise<Object>} Default cost template
   */
  static async getDefault(companyId) {
    const query = `
      SELECT * FROM cost_templates 
      WHERE company_id = $1 
        AND is_default = true 
        AND is_active = true
      LIMIT 1
    `;
    
    try {
      const result = await db.query(query, [companyId]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching default cost template: ${error.message}`);
    }
  }
}

module.exports = CostTemplate;

