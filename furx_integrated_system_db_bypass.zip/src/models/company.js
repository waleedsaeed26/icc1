const db = require('../config/database');

/**
 * Company Model
 * Handles database operations for the companies table
 * This supports the multi-company structure (ICC, FURX, NOAH, ADAM'S)
 */
class Company {
  /**
   * Get all companies
   * @returns {Promise<Array>} Array of company objects
   */
  static async getAll() {
    try {
      const result = await db.query(
        'SELECT * FROM companies ORDER BY company_id'
      );
      return result.rows;
    } catch (error) {
      console.error('Error in getAll companies:', error);
      throw error;
    }
  }

  /**
   * Get a company by ID
   * @param {number} id - Company ID
   * @returns {Promise<Object>} Company object
   */
  static async getById(id) {
    try {
      const result = await db.query(
        'SELECT * FROM companies WHERE company_id = $1',
        [id]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in getById company ${id}:`, error);
      throw error;
    }
  }

  /**
   * Create a new company
   * @param {Object} company - Company data
   * @returns {Promise<Object>} Created company object
   */
  static async create(company) {
    try {
      const { company_name, company_code, parent_company_id, description, is_active } = company;
      const result = await db.query(
        `INSERT INTO companies 
        (company_name, company_code, parent_company_id, description, is_active, created_at) 
        VALUES ($1, $2, $3, $4, $5, NOW()) 
        RETURNING *`,
        [company_name, company_code, parent_company_id, description, is_active]
      );
      return result.rows[0];
    } catch (error) {
      console.error('Error in create company:', error);
      throw error;
    }
  }

  /**
   * Update a company
   * @param {number} id - Company ID
   * @param {Object} company - Updated company data
   * @returns {Promise<Object>} Updated company object
   */
  static async update(id, company) {
    try {
      const { company_name, company_code, parent_company_id, description, is_active } = company;
      const result = await db.query(
        `UPDATE companies 
        SET company_name = $1, 
            company_code = $2, 
            parent_company_id = $3, 
            description = $4, 
            is_active = $5, 
            updated_at = NOW() 
        WHERE company_id = $6 
        RETURNING *`,
        [company_name, company_code, parent_company_id, description, is_active, id]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in update company ${id}:`, error);
      throw error;
    }
  }

  /**
   * Get child companies of a parent company
   * @param {number} parentId - Parent company ID
   * @returns {Promise<Array>} Array of child company objects
   */
  static async getChildCompanies(parentId) {
    try {
      const result = await db.query(
        'SELECT * FROM companies WHERE parent_company_id = $1',
        [parentId]
      );
      return result.rows;
    } catch (error) {
      console.error(`Error in getChildCompanies for parent ${parentId}:`, error);
      throw error;
    }
  }
}

module.exports = Company;
