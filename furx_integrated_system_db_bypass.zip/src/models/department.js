const db = require('../config/database');

/**
 * Department Model
 * Handles database operations for the departments table
 * Includes company_id to support multi-company structure
 */
class Department {
  /**
   * Get all departments for a specific company
   * @param {number} companyId - Company ID
   * @returns {Promise<Array>} Array of department objects
   */
  static async getAllByCompany(companyId) {
    try {
      const result = await db.query(
        'SELECT * FROM departments WHERE company_id = $1 ORDER BY department_id',
        [companyId]
      );
      return result.rows;
    } catch (error) {
      console.error(`Error in getAllByCompany departments for company ${companyId}:`, error);
      throw error;
    }
  }

  /**
   * Get a department by ID
   * @param {number} id - Department ID
   * @returns {Promise<Object>} Department object
   */
  static async getById(id) {
    try {
      const result = await db.query(
        'SELECT * FROM departments WHERE department_id = $1',
        [id]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in getById department ${id}:`, error);
      throw error;
    }
  }

  /**
   * Create a new department
   * @param {Object} department - Department data
   * @returns {Promise<Object>} Created department object
   */
  static async create(department) {
    try {
      const { company_id, department_name, description, manager_id } = department;
      const result = await db.query(
        `INSERT INTO departments 
        (company_id, department_name, description, manager_id, created_at) 
        VALUES ($1, $2, $3, $4, NOW()) 
        RETURNING *`,
        [company_id, department_name, description, manager_id]
      );
      return result.rows[0];
    } catch (error) {
      console.error('Error in create department:', error);
      throw error;
    }
  }

  /**
   * Update a department
   * @param {number} id - Department ID
   * @param {Object} department - Updated department data
   * @returns {Promise<Object>} Updated department object
   */
  static async update(id, department) {
    try {
      const { company_id, department_name, description, manager_id } = department;
      const result = await db.query(
        `UPDATE departments 
        SET company_id = $1, 
            department_name = $2, 
            description = $3, 
            manager_id = $4, 
            updated_at = NOW() 
        WHERE department_id = $5 
        RETURNING *`,
        [company_id, department_name, description, manager_id, id]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in update department ${id}:`, error);
      throw error;
    }
  }
}

module.exports = Department;
