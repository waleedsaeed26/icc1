// Modified Cost Center Model to use Mock Database Service
const mockDb = require('../services/mockDatabaseService');

class CostCenter {
  /**
   * Get all cost centers for a company
   * @param {number} companyId - Company ID
   * @returns {Array} Array of cost centers
   */
  static async getAllByCompany(companyId) {
    return mockDb.getAll('cost_centers', { company_id: companyId });
  }

  /**
   * Get a cost center by ID
   * @param {number} id - Cost center ID
   * @returns {Object|null} Cost center object or null
   */
  static async getById(id) {
    return mockDb.getById('cost_centers', parseInt(id));
  }

  /**
   * Create a new cost center
   * @param {Object} costCenter - Cost center data
   * @returns {Object} Created cost center
   */
  static async create(costCenter) {
    return mockDb.create('cost_centers', costCenter);
  }

  /**
   * Update a cost center
   * @param {number} id - Cost center ID
   * @param {Object} updates - Fields to update
   * @returns {Object|null} Updated cost center or null
   */
  static async update(id, updates) {
    return mockDb.update('cost_centers', parseInt(id), updates);
  }

  /**
   * Delete a cost center
   * @param {number} id - Cost center ID
   * @returns {boolean} Success status
   */
  static async delete(id) {
    return mockDb.remove('cost_centers', parseInt(id));
  }

  /**
   * Get cost centers by department ID
   * @param {number} departmentId - Department ID
   * @returns {Array} Array of cost centers
   */
  static async getByDepartment(departmentId) {
    return mockDb.getAll('cost_centers', { department_id: departmentId });
  }

  /**
   * Get cost centers by workshop ID
   * @param {number} workshopId - Workshop ID
   * @returns {Array} Array of cost centers
   */
  static async getByWorkshop(workshopId) {
    return mockDb.getAll('cost_centers', { workshop_id: workshopId });
  }
}

module.exports = CostCenter;
