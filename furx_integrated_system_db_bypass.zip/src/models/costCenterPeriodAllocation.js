const db = require("../config/database");

const CostCenterPeriodAllocation = {
  async create(data) {
    const { 
      company_id, 
      cost_center_id, 
      period_start_date, 
      period_end_date, 
      cost_type, 
      allocated_amount, 
      notes 
    } = data;
    
    const query = `
      INSERT INTO cost_center_period_allocations (
        company_id, cost_center_id, period_start_date, period_end_date, 
        cost_type, allocated_amount, notes
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      ON CONFLICT (company_id, cost_center_id, period_start_date, period_end_date, cost_type)
      DO UPDATE SET
        allocated_amount = EXCLUDED.allocated_amount,
        calculation_date = CURRENT_TIMESTAMP,
        notes = EXCLUDED.notes
      RETURNING *;
    `;
    
    const values = [
      company_id, 
      cost_center_id, 
      period_start_date, 
      period_end_date, 
      cost_type, 
      allocated_amount, 
      notes
    ];
    
    try {
      const { rows } = await db.query(query, values);
      return rows[0];
    } catch (error) {
      console.error("Error creating or updating cost center period allocation:", error);
      throw error;
    }
  },

  async getByPeriod(companyId, startDate, endDate) {
    const query = `
      SELECT 
        ccpa.*, 
        cc.center_name
      FROM cost_center_period_allocations ccpa
      JOIN cost_centers cc ON ccpa.cost_center_id = cc.id
      WHERE ccpa.company_id = $1 
        AND ccpa.period_start_date >= $2 
        AND ccpa.period_end_date <= $3
      ORDER BY ccpa.period_start_date, cc.center_name, ccpa.cost_type;
    `;
    
    try {
      const { rows } = await db.query(query, [companyId, startDate, endDate]);
      return rows;
    } catch (error) {
      console.error("Error fetching cost center period allocations:", error);
      throw error;
    }
  },
  
  async getByCostCenterAndPeriod(costCenterId, startDate, endDate) {
    const query = `
      SELECT * 
      FROM cost_center_period_allocations 
      WHERE cost_center_id = $1 
        AND period_start_date >= $2 
        AND period_end_date <= $3
      ORDER BY period_start_date, cost_type;
    `;
    
    try {
      const { rows } = await db.query(query, [costCenterId, startDate, endDate]);
      return rows;
    } catch (error) {
      console.error("Error fetching cost center period allocations for center:", error);
      throw error;
    }
  }
};

module.exports = CostCenterPeriodAllocation;

