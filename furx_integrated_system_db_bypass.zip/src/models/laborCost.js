const db = require("../config/database");

/**
 * Labor Costs Model
 * Handles database operations for labor costs
 */
class LaborCost {
  /**
   * Create a new labor cost entry
   * @param {Object} laborCost - Labor cost data
   * @returns {Promise<Object>} Created labor cost entry
   */
  static async create(laborCost) {
    const query = `
      INSERT INTO labor_costs (
        company_id, department_id, workshop_id, labor_category, 
        cost_per_hour, overhead_percentage, is_active, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;
    
    const values = [
      laborCost.company_id,
      laborCost.department_id, // Can be null if workshop_id is set or company-wide
      laborCost.workshop_id,   // Can be null if department_id is set or company-wide
      laborCost.labor_category,
      laborCost.cost_per_hour,
      laborCost.overhead_percentage || 0,
      laborCost.is_active !== undefined ? laborCost.is_active : true,
      laborCost.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating labor cost: ${error.message}`);
    }
  }
  
  /**
   * Get all labor costs for a company
   * @param {number} companyId - Company ID
   * @param {boolean} activeOnly - Get only active labor costs
   * @returns {Promise<Array>} List of labor costs with department/workshop names
   */
  static async getAllByCompany(companyId, activeOnly = true) {
    let query = `
      SELECT lc.*, d.department_name, w.workshop_name 
      FROM labor_costs lc
      LEFT JOIN departments d ON lc.department_id = d.id
      LEFT JOIN workshops w ON lc.workshop_id = w.id
      WHERE lc.company_id = $1
    `;
    
    const values = [companyId];
    
    if (activeOnly) {
      query += ` AND lc.is_active = true`;
    }
    
    query += ` ORDER BY lc.labor_category`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching labor costs: ${error.message}`);
    }
  }
  
  /**
   * Get a labor cost entry by ID
   * @param {number} id - Labor cost ID
   * @returns {Promise<Object>} Labor cost entry
   */
  static async getById(id) {
    const query = `
      SELECT lc.*, d.department_name, w.workshop_name 
      FROM labor_costs lc
      LEFT JOIN departments d ON lc.department_id = d.id
      LEFT JOIN workshops w ON lc.workshop_id = w.id
      WHERE lc.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching labor cost: ${error.message}`);
    }
  }
  
  /**
   * Update a labor cost entry
   * @param {number} id - Labor cost ID
   * @param {Object} laborCost - Updated labor cost data
   * @returns {Promise<Object>} Updated labor cost entry
   */
  static async update(id, laborCost) {
    const query = `
      UPDATE labor_costs 
      SET 
        department_id = $1,
        workshop_id = $2,
        labor_category = $3,
        cost_per_hour = $4,
        overhead_percentage = $5,
        is_active = $6,
        notes = $7,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $8
      RETURNING *
    `;
    
    const values = [
      laborCost.department_id,
      laborCost.workshop_id,
      laborCost.labor_category,
      laborCost.cost_per_hour,
      laborCost.overhead_percentage,
      laborCost.is_active,
      laborCost.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating labor cost: ${error.message}`);
    }
  }
  
  /**
   * Delete a labor cost entry
   * @param {number} id - Labor cost ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    const query = `
      DELETE FROM labor_costs 
      WHERE id = $1
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows.length > 0;
    } catch (error) {
      throw new Error(`Error deleting labor cost: ${error.message}`);
    }
  }
  
  /**
   * Get labor cost for a specific category in a department/workshop
   * @param {number} companyId - Company ID
   * @param {string} category - Labor category
   * @param {number} [departmentId] - Department ID
   * @param {number} [workshopId] - Workshop ID
   * @returns {Promise<Object>} Labor cost entry
   */
  static async getByCategoryAndLocation(companyId, category, departmentId = null, workshopId = null) {
    let query = `
      SELECT * FROM labor_costs 
      WHERE company_id = $1 
        AND labor_category = $2
        AND is_active = true
    `;
    const values = [companyId, category];
    
    if (workshopId) {
      query += ` AND workshop_id = $${values.length + 1}`;
      values.push(workshopId);
    } else if (departmentId) {
      query += ` AND department_id = $${values.length + 1}`;
      values.push(departmentId);
    } else {
      // Fallback to company-wide if no specific location
      query += ` AND department_id IS NULL AND workshop_id IS NULL`;
    }
    
    query += ` LIMIT 1`; // Assuming one cost per category/location
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching labor cost by category and location: ${error.message}`);
    }
  }
  
  /**
   * Calculate effective labor cost per hour (including overhead)
   * @param {number} companyId - Company ID
   * @param {string} category - Labor category
   * @param {number} [departmentId] - Department ID
   * @param {number} [workshopId] - Workshop ID
   * @returns {Promise<number>} Effective labor cost per hour
   */
  static async getEffectiveCostPerHour(companyId, category, departmentId = null, workshopId = null) {
    try {
      const laborCost = await this.getByCategoryAndLocation(companyId, category, departmentId, workshopId);
      if (!laborCost) {
        return 0; // Or throw error if cost is required
      }
      
      const baseCost = parseFloat(laborCost.cost_per_hour || 0);
      const overhead = parseFloat(laborCost.overhead_percentage || 0);
      
      const effectiveCost = baseCost * (1 + overhead / 100);
      
      return effectiveCost;
    } catch (error) {
      throw new Error(`Error calculating effective labor cost: ${error.message}`);
    }
  }
}

module.exports = LaborCost;

