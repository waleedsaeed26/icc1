const db = require("../config/database");

/**
 * Operational Costs Model
 * Handles database operations for operational costs
 */
class OperationalCost {
  /**
   * Create a new operational cost entry
   * @param {Object} operationalCost - Operational cost data
   * @returns {Promise<Object>} Created operational cost entry
   */
  static async create(operationalCost) {
    const query = `
      INSERT INTO operational_costs (
        company_id, department_id, workshop_id, cost_name, cost_category, 
        amount, frequency, allocation_method, is_active, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `;
    
    const values = [
      operationalCost.company_id,
      operationalCost.department_id, // Can be null if workshop_id is set or company-wide
      operationalCost.workshop_id,   // Can be null if department_id is set or company-wide
      operationalCost.cost_name,
      operationalCost.cost_category,
      operationalCost.amount,
      operationalCost.frequency,
      operationalCost.allocation_method,
      operationalCost.is_active !== undefined ? operationalCost.is_active : true,
      operationalCost.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating operational cost: ${error.message}`);
    }
  }
  
  /**
   * Get all operational costs for a company
   * @param {number} companyId - Company ID
   * @param {boolean} activeOnly - Get only active operational costs
   * @returns {Promise<Array>} List of operational costs with department/workshop names
   */
  static async getAllByCompany(companyId, activeOnly = true) {
    let query = `
      SELECT oc.*, d.department_name, w.workshop_name 
      FROM operational_costs oc
      LEFT JOIN departments d ON oc.department_id = d.id
      LEFT JOIN workshops w ON oc.workshop_id = w.id
      WHERE oc.company_id = $1
    `;
    
    const values = [companyId];
    
    if (activeOnly) {
      query += ` AND oc.is_active = true`;
    }
    
    query += ` ORDER BY oc.cost_category, oc.cost_name`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching operational costs: ${error.message}`);
    }
  }
  
  /**
   * Get an operational cost entry by ID
   * @param {number} id - Operational cost ID
   * @returns {Promise<Object>} Operational cost entry
   */
  static async getById(id) {
    const query = `
      SELECT oc.*, d.department_name, w.workshop_name 
      FROM operational_costs oc
      LEFT JOIN departments d ON oc.department_id = d.id
      LEFT JOIN workshops w ON oc.workshop_id = w.id
      WHERE oc.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching operational cost: ${error.message}`);
    }
  }
  
  /**
   * Update an operational cost entry
   * @param {number} id - Operational cost ID
   * @param {Object} operationalCost - Updated operational cost data
   * @returns {Promise<Object>} Updated operational cost entry
   */
  static async update(id, operationalCost) {
    const query = `
      UPDATE operational_costs 
      SET 
        department_id = $1,
        workshop_id = $2,
        cost_name = $3,
        cost_category = $4,
        amount = $5,
        frequency = $6,
        allocation_method = $7,
        is_active = $8,
        notes = $9,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $10
      RETURNING *
    `;
    
    const values = [
      operationalCost.department_id,
      operationalCost.workshop_id,
      operationalCost.cost_name,
      operationalCost.cost_category,
      operationalCost.amount,
      operationalCost.frequency,
      operationalCost.allocation_method,
      operationalCost.is_active,
      operationalCost.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating operational cost: ${error.message}`);
    }
  }
  
  /**
   * Delete an operational cost entry
   * @param {number} id - Operational cost ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    // Need to handle related cost allocations before deleting
    const checkAllocationsQuery = `SELECT COUNT(*) FROM cost_allocations WHERE cost_type = 'operational' AND cost_id = $1`;
    const client = await db.getClient();
    try {
      await client.query("BEGIN");
      const allocationResult = await client.query(checkAllocationsQuery, [id]);
      if (parseInt(allocationResult.rows[0].count, 10) > 0) {
        throw new Error("Cannot delete operational cost with active allocations. Please remove allocations first.");
      }
      
      const deleteQuery = `
        DELETE FROM operational_costs 
        WHERE id = $1
        RETURNING id
      `;
      const result = await client.query(deleteQuery, [id]);
      await client.query("COMMIT");
      return result.rows.length > 0;
    } catch (error) {
      await client.query("ROLLBACK");
      throw new Error(`Error deleting operational cost: ${error.message}`);
    } finally {
      client.release();
    }
  }
  
  /**
   * Get operational costs for a specific department or workshop
   * @param {number} companyId - Company ID
   * @param {number} [departmentId] - Department ID
   * @param {number} [workshopId] - Workshop ID
   * @returns {Promise<Array>} List of operational costs
   */
  static async getByLocation(companyId, departmentId = null, workshopId = null) {
    let query = `
      SELECT * FROM operational_costs 
      WHERE company_id = $1 
        AND is_active = true
    `;
    const values = [companyId];
    
    if (workshopId) {
      query += ` AND workshop_id = $${values.length + 1}`;
      values.push(workshopId);
    } else if (departmentId) {
      query += ` AND department_id = $${values.length + 1}`;
      values.push(departmentId);
    } else {
      // Company-wide costs
      query += ` AND department_id IS NULL AND workshop_id IS NULL`;
    }
    
    query += ` ORDER BY cost_category, cost_name`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching operational costs by location: ${error.message}`);
    }
  }
  
  /**
   * Calculate total operational costs for a location and frequency
   * @param {number} companyId - Company ID
   * @param {string} frequency - Frequency (daily, weekly, monthly)
   * @param {number} [departmentId] - Department ID
   * @param {number} [workshopId] - Workshop ID
   * @returns {Promise<number>} Total operational costs
   */
  static async getTotalByFrequencyAndLocation(companyId, frequency, departmentId = null, workshopId = null) {
    let query = `
      SELECT SUM(amount) as total 
      FROM operational_costs 
      WHERE company_id = $1 
        AND frequency = $2 
        AND is_active = true
    `;
    const values = [companyId, frequency];
    
    if (workshopId) {
      query += ` AND workshop_id = $${values.length + 1}`;
      values.push(workshopId);
    } else if (departmentId) {
      query += ` AND department_id = $${values.length + 1}`;
      values.push(departmentId);
    } else {
      query += ` AND department_id IS NULL AND workshop_id IS NULL`;
    }
    
    try {
      const result = await db.query(query, values);
      return parseFloat(result.rows[0]?.total || 0);
    } catch (error) {
      throw new Error(`Error calculating total operational costs: ${error.message}`);
    }
  }
}

module.exports = OperationalCost;

