const db = require("../config/database");

/**
 * Workshop Model
 * Handles database operations for the workshops table
 * Includes company_id and is_active flag
 */
class Workshop {
  /**
   * Get all workshops for a specific company
   * @param {number} companyId - Company ID
   * @param {boolean} onlyActive - Optional flag to return only active workshops (default: true)
   * @returns {Promise<Array>} Array of workshop objects
   */
  static async getAllByCompany(companyId, onlyActive = true) {
    try {
      let query = "SELECT * FROM workshops WHERE company_id = $1";
      const params = [companyId];
      if (onlyActive) {
        query += " AND is_active = TRUE";
      }
      query += " ORDER BY workshop_id";
      
      const result = await db.query(query, params);
      return result.rows;
    } catch (error) {
      console.error(
        `Error in getAllByCompany workshops for company ${companyId}:`,
        error
      );
      throw error;
    }
  }

  /**
   * Get a workshop by ID
   * @param {number} id - Workshop ID
   * @returns {Promise<Object>} Workshop object
   */
  static async getById(id) {
    try {
      const result = await db.query(
        "SELECT * FROM workshops WHERE workshop_id = $1",
        [id]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in getById workshop ${id}:`, error);
      throw error;
    }
  }

  /**
   * Create a new workshop
   * @param {Object} workshop - Workshop data
   * @returns {Promise<Object>} Created workshop object
   */
  static async create(workshop) {
    try {
      const {
        company_id,
        workshop_name,
        production_line_id,
        description,
      } = workshop;
      const result = await db.query(
        `INSERT INTO workshops 
        (company_id, workshop_name, production_line_id, description, is_active, created_at) 
        VALUES ($1, $2, $3, $4, TRUE, NOW()) 
        RETURNING *`,
        [company_id, workshop_name, production_line_id, description]
      );
      return result.rows[0];
    } catch (error) {
      console.error("Error in create workshop:", error);
      throw error;
    }
  }

  /**
   * Update a workshop (including activation/deactivation)
   * @param {number} id - Workshop ID
   * @param {Object} workshop - Updated workshop data
   * @returns {Promise<Object>} Updated workshop object
   */
  static async update(id, workshop) {
    try {
      const {
        company_id, // Keep company_id for context/validation if needed
        workshop_name,
        production_line_id,
        description,
        is_active, // Allow updating the active status
      } = workshop;
      
      // Fetch current workshop to compare is_active status if needed
      const currentWorkshop = await this.getById(id);
      if (!currentWorkshop) return null; // Workshop not found

      const result = await db.query(
        `UPDATE workshops 
        SET workshop_name = $1, 
            production_line_id = $2, 
            description = $3, 
            is_active = $4, 
            updated_at = NOW() 
        WHERE workshop_id = $5 AND company_id = $6
        RETURNING *`,
        [
          workshop_name,
          production_line_id,
          description,
          is_active !== undefined ? is_active : currentWorkshop.is_active, // Use provided value or keep current
          id,
          company_id // Ensure update is within the correct company context
        ]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in update workshop ${id}:`, error);
      throw error;
    }
  }

  /**
   * Deactivate (close) a workshop
   * @param {number} id - Workshop ID
   * @param {number} companyId - Company ID for validation
   * @returns {Promise<Object>} Deactivated workshop object
   */
  static async deactivate(id, companyId) {
    try {
      // Add checks here: e.g., ensure no active production items are in this workshop
      // This logic needs further definition based on business rules.
      
      const result = await db.query(
        `UPDATE workshops 
        SET is_active = FALSE, 
            updated_at = NOW() 
        WHERE workshop_id = $1 AND company_id = $2 AND is_active = TRUE
        RETURNING *`,
        [id, companyId]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in deactivate workshop ${id}:`, error);
      throw error;
    }
  }

  /**
   * Activate a workshop
   * @param {number} id - Workshop ID
   * @param {number} companyId - Company ID for validation
   * @returns {Promise<Object>} Activated workshop object
   */
  static async activate(id, companyId) {
    try {
      const result = await db.query(
        `UPDATE workshops 
        SET is_active = TRUE, 
            updated_at = NOW() 
        WHERE workshop_id = $1 AND company_id = $2 AND is_active = FALSE
        RETURNING *`,
        [id, companyId]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in activate workshop ${id}:`, error);
      throw error;
    }
  }
}

module.exports = Workshop;
