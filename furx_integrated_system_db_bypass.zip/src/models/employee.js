const db = require("../config/database");

/**
 * Employee Model
 * Handles database operations for the employees table
 * Includes company_id to support multi-company structure
 */
class Employee {
  /**
   * Get all employees for a specific company
   * @param {number} companyId - Company ID
   * @returns {Promise<Array>} Array of employee objects
   */
  static async getAllByCompany(companyId) {
    try {
      const result = await db.query(
        "SELECT * FROM employees WHERE company_id = $1 ORDER BY employee_id",
        [companyId]
      );
      return result.rows;
    } catch (error) {
      console.error(`Error in getAllByCompany employees for company ${companyId}:`, error);
      throw error;
    }
  }

  /**
   * Get an employee by ID
   * @param {number} id - Employee ID
   * @returns {Promise<Object>} Employee object
   */
  static async getById(id) {
    try {
      const result = await db.query(
        "SELECT * FROM employees WHERE employee_id = $1",
        [id]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in getById employee ${id}:`, error);
      throw error;
    }
  }

  /**
   * Create a new employee
   * @param {Object} employee - Employee data
   * @returns {Promise<Object>} Created employee object
   */
  static async create(employee) {
    const {
      company_id, // Added for multi-company support
      first_name,
      last_name,
      national_id,
      hire_date,
      job_title,
      department_id,
      production_line_id,
      workshop_id,
      contact_info,
      salary_type,
      base_salary_rate,
      is_active,
      user_id,
    } = employee;
    try {
      const result = await db.query(
        `INSERT INTO employees (
          company_id, first_name, last_name, national_id, hire_date, job_title, 
          department_id, production_line_id, workshop_id, contact_info, 
          salary_type, base_salary_rate, is_active, user_id, created_at
        ) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW()) 
        RETURNING *`,
        [
          company_id,
          first_name,
          last_name,
          national_id,
          hire_date,
          job_title,
          department_id,
          production_line_id,
          workshop_id,
          contact_info,
          salary_type,
          base_salary_rate,
          is_active,
          user_id,
        ]
      );
      return result.rows[0];
    } catch (error) {
      console.error("Error in create employee:", error);
      throw error;
    }
  }

  /**
   * Update an employee
   * @param {number} id - Employee ID
   * @param {Object} employee - Updated employee data
   * @returns {Promise<Object>} Updated employee object
   */
  static async update(id, employee) {
    const {
      company_id,
      first_name,
      last_name,
      national_id,
      hire_date,
      job_title,
      department_id,
      production_line_id,
      workshop_id,
      contact_info,
      salary_type,
      base_salary_rate,
      is_active,
      user_id,
    } = employee;
    try {
      const result = await db.query(
        `UPDATE employees 
        SET company_id = $1, 
            first_name = $2, 
            last_name = $3, 
            national_id = $4, 
            hire_date = $5, 
            job_title = $6, 
            department_id = $7, 
            production_line_id = $8, 
            workshop_id = $9, 
            contact_info = $10, 
            salary_type = $11, 
            base_salary_rate = $12, 
            is_active = $13, 
            user_id = $14, 
            updated_at = NOW() 
        WHERE employee_id = $15 
        RETURNING *`,
        [
          company_id,
          first_name,
          last_name,
          national_id,
          hire_date,
          job_title,
          department_id,
          production_line_id,
          workshop_id,
          contact_info,
          salary_type,
          base_salary_rate,
          is_active,
          user_id,
          id,
        ]
      );
      return result.rows[0];
    } catch (error) {
      console.error(`Error in update employee ${id}:`, error);
      throw error;
    }
  }

  // Add other necessary methods like findByNationalId, etc.
}

module.exports = Employee;
