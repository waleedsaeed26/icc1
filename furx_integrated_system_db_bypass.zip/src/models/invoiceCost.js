const db = require("../config/database");

/**
 * Invoice Cost Model
 * Handles database operations for invoice costs and profit calculations
 */
class InvoiceCost {
  /**
   * Create a new invoice cost entry
   * @param {Object} invoiceCost - Invoice cost data
   * @returns {Promise<Object>} Created invoice cost entry
   */
  static async create(invoiceCost) {
    const query = `
      INSERT INTO invoice_costs (
        company_id, invoice_id, total_cost, total_price, 
        profit_amount, profit_percentage, calculation_date, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;
    
    const values = [
      invoiceCost.company_id,
      invoiceCost.invoice_id,
      invoiceCost.total_cost || 0,
      invoiceCost.total_price || 0,
      invoiceCost.profit_amount || 0,
      invoiceCost.profit_percentage || 0,
      invoiceCost.calculation_date || new Date(),
      invoiceCost.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating invoice cost: ${error.message}`);
    }
  }
  
  /**
   * Get all invoice costs for a company
   * @param {number} companyId - Company ID
   * @param {Date} [startDate] - Start date for filtering
   * @param {Date} [endDate] - End date for filtering
   * @returns {Promise<Array>} List of invoice costs with invoice details
   */
  static async getAllByCompany(companyId, startDate = null, endDate = null) {
    let query = `
      SELECT ic.*, i.invoice_number, i.invoice_date, i.customer_name 
      FROM invoice_costs ic
      JOIN invoices i ON ic.invoice_id = i.id
      WHERE ic.company_id = $1
    `;
    
    const values = [companyId];
    
    if (startDate) {
      query += ` AND i.invoice_date >= $${values.length + 1}`;
      values.push(startDate);
    }
    
    if (endDate) {
      query += ` AND i.invoice_date <= $${values.length + 1}`;
      values.push(endDate);
    }
    
    query += ` ORDER BY i.invoice_date DESC`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching invoice costs: ${error.message}`);
    }
  }
  
  /**
   * Get an invoice cost by ID
   * @param {number} id - Invoice cost ID
   * @returns {Promise<Object>} Invoice cost with invoice details
   */
  static async getById(id) {
    const query = `
      SELECT ic.*, i.invoice_number, i.invoice_date, i.customer_name 
      FROM invoice_costs ic
      JOIN invoices i ON ic.invoice_id = i.id
      WHERE ic.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching invoice cost: ${error.message}`);
    }
  }
  
  /**
   * Get an invoice cost by invoice ID
   * @param {number} companyId - Company ID
   * @param {number} invoiceId - Invoice ID
   * @returns {Promise<Object>} Invoice cost with invoice details
   */
  static async getByInvoiceId(companyId, invoiceId) {
    const query = `
      SELECT ic.*, i.invoice_number, i.invoice_date, i.customer_name 
      FROM invoice_costs ic
      JOIN invoices i ON ic.invoice_id = i.id
      WHERE ic.company_id = $1 AND ic.invoice_id = $2
    `;
    
    try {
      const result = await db.query(query, [companyId, invoiceId]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching invoice cost by invoice ID: ${error.message}`);
    }
  }
  
  /**
   * Update an invoice cost
   * @param {number} id - Invoice cost ID
   * @param {Object} invoiceCost - Updated invoice cost data
   * @returns {Promise<Object>} Updated invoice cost
   */
  static async update(id, invoiceCost) {
    const query = `
      UPDATE invoice_costs 
      SET 
        total_cost = $1,
        total_price = $2,
        profit_amount = $3,
        profit_percentage = $4,
        calculation_date = $5,
        notes = $6
      WHERE id = $7
      RETURNING *
    `;
    
    const values = [
      invoiceCost.total_cost,
      invoiceCost.total_price,
      invoiceCost.profit_amount,
      invoiceCost.profit_percentage,
      invoiceCost.calculation_date || new Date(),
      invoiceCost.notes,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating invoice cost: ${error.message}`);
    }
  }
  
  /**
   * Delete an invoice cost
   * @param {number} id - Invoice cost ID
   * @returns {Promise<boolean>} Success status
   */
  static async delete(id) {
    const query = `
      DELETE FROM invoice_costs 
      WHERE id = $1
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows.length > 0;
    } catch (error) {
      throw new Error(`Error deleting invoice cost: ${error.message}`);
    }
  }
  
  /**
   * Add an item to an invoice cost
   * @param {Object} item - Invoice cost item data
   * @returns {Promise<Object>} Added invoice cost item
   */
  static async addItem(item) {
    const query = `
      INSERT INTO invoice_cost_items (
        invoice_cost_id, product_id, quantity, unit_cost, 
        unit_price, total_cost, total_price, profit_amount, 
        profit_percentage, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `;
    
    const values = [
      item.invoice_cost_id,
      item.product_id,
      item.quantity || 1,
      item.unit_cost || 0,
      item.unit_price || 0,
      item.total_cost || 0,
      item.total_price || 0,
      item.profit_amount || 0,
      item.profit_percentage || 0,
      item.notes
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error adding item to invoice cost: ${error.message}`);
    }
  }
  
  /**
   * Get all items for an invoice cost
   * @param {number} invoiceCostId - Invoice cost ID
   * @returns {Promise<Array>} List of invoice cost items with product details
   */
  static async getAllItems(invoiceCostId) {
    const query = `
      SELECT ici.*, p.product_name, p.product_code 
      FROM invoice_cost_items ici
      JOIN products p ON ici.product_id = p.id
      WHERE ici.invoice_cost_id = $1
      ORDER BY ici.id
    `;
    
    try {
      const result = await db.query(query, [invoiceCostId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching invoice cost items: ${error.message}`);
    }
  }
  
  /**
   * Calculate costs and profits for an invoice
   * @param {number} companyId - Company ID
   * @param {number} invoiceId - Invoice ID
   * @returns {Promise<Object>} Calculated invoice cost
   */
  static async calculateForInvoice(companyId, invoiceId) {
    try {
      // Get invoice details
      const invoiceQuery = `
        SELECT i.*, 
          COALESCE(SUM(ii.quantity * ii.unit_price), 0) as invoice_total
        FROM invoices i
        LEFT JOIN invoice_items ii ON i.id = ii.invoice_id
        WHERE i.id = $1 AND i.company_id = $2
        GROUP BY i.id
      `;
      
      const invoiceResult = await db.query(invoiceQuery, [invoiceId, companyId]);
      const invoice = invoiceResult.rows[0];
      
      if (!invoice) {
        throw new Error(`Invoice not found`);
      }
      
      // Get invoice items
      const itemsQuery = `
        SELECT ii.*, p.id as product_id, p.product_name, p.product_code
        FROM invoice_items ii
        JOIN products p ON ii.product_id = p.id
        WHERE ii.invoice_id = $1
      `;
      
      const itemsResult = await db.query(itemsQuery, [invoiceId]);
      const invoiceItems = itemsResult.rows;
      
      // Calculate costs for each item
      let totalCost = 0;
      let totalPrice = parseFloat(invoice.invoice_total || 0);
      const costItems = [];
      
      for (const item of invoiceItems) {
        // Get product cost
        const productCostQuery = `
          SELECT * FROM product_costs
          WHERE company_id = $1 AND product_id = $2 AND is_active = true
          ORDER BY created_at DESC
          LIMIT 1
        `;
        
        const productCostResult = await db.query(productCostQuery, [companyId, item.product_id]);
        const productCost = productCostResult.rows[0];
        
        let unitCost = 0;
        if (productCost) {
          unitCost = parseFloat(productCost.total_cost || 0);
        }
        
        const quantity = parseFloat(item.quantity || 0);
        const unitPrice = parseFloat(item.unit_price || 0);
        const itemTotalCost = unitCost * quantity;
        const itemTotalPrice = unitPrice * quantity;
        const itemProfitAmount = itemTotalPrice - itemTotalCost;
        const itemProfitPercentage = itemTotalPrice > 0 ? (itemProfitAmount / itemTotalPrice * 100) : 0;
        
        totalCost += itemTotalCost;
        
        costItems.push({
          invoice_cost_id: null, // Will be set after invoice_cost is created
          product_id: item.product_id,
          quantity: quantity,
          unit_cost: unitCost,
          unit_price: unitPrice,
          total_cost: itemTotalCost,
          total_price: itemTotalPrice,
          profit_amount: itemProfitAmount,
          profit_percentage: itemProfitPercentage,
          notes: `Calculated from invoice item ID: ${item.id}`
        });
      }
      
      // Calculate overall profit
      const profitAmount = totalPrice - totalCost;
      const profitPercentage = totalPrice > 0 ? (profitAmount / totalPrice * 100) : 0;
      
      // Create or update invoice cost
      const existingCost = await this.getByInvoiceId(companyId, invoiceId);
      
      let invoiceCost;
      if (existingCost) {
        // Update existing
        invoiceCost = await this.update(existingCost.id, {
          total_cost: totalCost,
          total_price: totalPrice,
          profit_amount: profitAmount,
          profit_percentage: profitPercentage,
          calculation_date: new Date(),
          notes: `Recalculated on ${new Date().toISOString()}`
        });
        
        // Delete existing items
        const deleteItemsQuery = `DELETE FROM invoice_cost_items WHERE invoice_cost_id = $1`;
        await db.query(deleteItemsQuery, [existingCost.id]);
      } else {
        // Create new
        invoiceCost = await this.create({
          company_id: companyId,
          invoice_id: invoiceId,
          total_cost: totalCost,
          total_price: totalPrice,
          profit_amount: profitAmount,
          profit_percentage: profitPercentage,
          calculation_date: new Date(),
          notes: `Initial calculation on ${new Date().toISOString()}`
        });
      }
      
      // Add items
      for (const item of costItems) {
        item.invoice_cost_id = invoiceCost.id;
        await this.addItem(item);
      }
      
      return {
        ...invoiceCost,
        items: await this.getAllItems(invoiceCost.id)
      };
    } catch (error) {
      throw new Error(`Error calculating invoice cost: ${error.message}`);
    }
  }
  
  /**
   * Get profit summary by period
   * @param {number} companyId - Company ID
   * @param {string} period - Period type (daily, weekly, monthly, quarterly, yearly)
   * @param {Date} [startDate] - Start date for filtering
   * @param {Date} [endDate] - End date for filtering
   * @returns {Promise<Array>} Profit summary by period
   */
  static async getProfitSummaryByPeriod(companyId, period = 'monthly', startDate = null, endDate = null) {
    let periodFormat;
    switch (period) {
      case 'daily':
        periodFormat = 'YYYY-MM-DD';
        break;
      case 'weekly':
        periodFormat = 'IYYY-IW'; // ISO year and week
        break;
      case 'monthly':
        periodFormat = 'YYYY-MM';
        break;
      case 'quarterly':
        periodFormat = 'YYYY-"Q"Q';
        break;
      case 'yearly':
        periodFormat = 'YYYY';
        break;
      default:
        periodFormat = 'YYYY-MM';
    }
    
    let query = `
      SELECT 
        TO_CHAR(i.invoice_date, '${periodFormat}') as period,
        COUNT(ic.id) as invoice_count,
        SUM(ic.total_cost) as total_cost,
        SUM(ic.total_price) as total_price,
        SUM(ic.profit_amount) as total_profit,
        CASE 
          WHEN SUM(ic.total_price) > 0 
          THEN (SUM(ic.profit_amount) / SUM(ic.total_price) * 100) 
          ELSE 0 
        END as avg_profit_percentage
      FROM invoice_costs ic
      JOIN invoices i ON ic.invoice_id = i.id
      WHERE ic.company_id = $1
    `;
    
    const values = [companyId];
    
    if (startDate) {
      query += ` AND i.invoice_date >= $${values.length + 1}`;
      values.push(startDate);
    }
    
    if (endDate) {
      query += ` AND i.invoice_date <= $${values.length + 1}`;
      values.push(endDate);
    }
    
    query += `
      GROUP BY period
      ORDER BY period
    `;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching profit summary: ${error.message}`);
    }
  }
}

module.exports = InvoiceCost;
