const express = require("express");
const cors = require("cors"); // Import cors package
const app = express();
const path = require("path");
require("dotenv").config();

// Middleware
app.use(cors()); // Use cors middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// Database setup script
const setupDatabase = require("./config/setupDatabase");

// Routes will be added here
app.get("/", (req, res) => {
  res.send("FURX Integrated System API is running");
});

// API routes for companies
const companyRoutes = require("./routes/companyRoutes");
app.use("/api/companies", companyRoutes);

// API routes for employees
const employeeRoutes = require("./routes/employeeRoutes");
app.use("/api/employees", employeeRoutes);

// API routes for departments
const departmentRoutes = require("./routes/departmentRoutes");
app.use("/api/departments", departmentRoutes);

// API routes for workshops
const workshopRoutes = require("./routes/workshopRoutes");
app.use("/api/workshops", workshopRoutes);

// API routes for production items
const productionItemRoutes = require("./routes/productionItemRoutes");
app.use("/api/production-items", productionItemRoutes);

// Mock Authentication Route
app.post("/api/auth/login", (req, res) => {
  console.log("Login request received:", req.body); // Log incoming request
  const { username, password } = req.body;
  if (username === "admin" && password === "admin") {
    // Successful login
    const response = {
      success: true,
      message: "Login successful",
      token: "mock-jwt-token-for-admin", // Send a mock token
      user: {
        id: 1,
        username: "admin",
        role: "admin",
        company_id: 1, // Assign a default company ID for testing
        companies: [1, 2, 3, 4] // Mock accessible companies
      }
    };
    console.log("Sending successful login response:", response); // Log success response
    res.json(response);
  } else {
    // Failed login
    const response = {
      success: false,
      message: "Invalid username or password"
    };
    console.log("Sending failed login response:", response); // Log failure response
    res.status(401).json(response);
  }
});

// API routes for inventory
const inventoryRoutes = require("./routes/inventoryRoutes");
app.use("/api/inventory", inventoryRoutes);

// --- Cost & Pricing Routes ---
const costCenterRoutes = require("./routes/costCenterRoutes");
app.use("/api/cost-centers", costCenterRoutes);

const costAllocationRoutes = require("./routes/costAllocationRoutes");
app.use("/api/cost-allocations", costAllocationRoutes);

const historicalCostDataRoutes = require("./routes/historicalCostDataRoutes");
app.use("/api/historical-costs", historicalCostDataRoutes);

const fixedCostRoutes = require("./routes/fixedCostRoutes");
app.use("/api/fixed-costs", fixedCostRoutes);

const variableCostRoutes = require("./routes/variableCostRoutes");
app.use("/api/variable-costs", variableCostRoutes);

const materialCostRoutes = require("./routes/materialCostRoutes");
app.use("/api/material-costs", materialCostRoutes);

const laborCostRoutes = require("./routes/laborCostRoutes");
app.use("/api/labor-costs", laborCostRoutes);

const operationalCostRoutes = require("./routes/operationalCostRoutes");
app.use("/api/operational-costs", operationalCostRoutes);

const costTemplateRoutes = require("./routes/costTemplateRoutes");
app.use("/api/cost-templates", costTemplateRoutes);

const productCostRoutes = require("./routes/productCostRoutes");
app.use("/api/product-costs", productCostRoutes);

const pricingRuleRoutes = require("./routes/pricingRuleRoutes");
app.use("/api/pricing-rules", pricingRuleRoutes);
// --- End Cost & Pricing Routes ---

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: "An error occurred",
    error: process.env.NODE_ENV === "development" ? err.message : "Internal server error",
  });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
  console.log(`Server running on port ${PORT}`);

  // Setup database tables if needed
  try {
    // await setupDatabase(); // Commented out to bypass DB connection for mock login
    console.log("Database setup completed");
  } catch (error) {
    console.error("Database setup failed:", error);
  }
});

module.exports = app;

